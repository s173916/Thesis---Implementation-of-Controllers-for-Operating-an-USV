
//extern params p; 
/** \file beaglebb_i2c.h
 *  \ingroup hwmodule
 *
 *   Interface for i2c bus on Beaglebone Black
 *
 * $Rev: 59 $
 * ¤Id$
 *
 *******************************************************************/

#include <semaphore.h>

#ifndef BEAGLEBB_I2C_H
#define BEAGLEBB_I2C_H

extern int initXML(char *);
extern int periodic(int);
extern int terminate (void) ;

#define MAX_SERVO_CNT 24
#define MAX_NAME_CNT  16

/// communication variables
struct
{ /** buffer for communication */
  #define MxBL 128
  char txBuf[MxBL];
  unsigned char rxBuf[MxBL];
  /** device file descriptor */
  int ttyDev;  //File descriptors
  #define MxDL 64
  char serialDev[MxDL];
  /// stuck flag 0=not stuck, 1 = struk
  int stuck;
  /// version number 0: ID=7, 1: firmware, 2: current mode
  int version[3];
  /// serial number
  int serial;
  /// is connection lost diurinr read or write operation
  int lostConnection;
} busif;

typedef struct 
{ // status for each servo
  /// servo ID on i2c bus, 0 is no servo
  unsigned char id;
  /// servo name
  char name[MAX_NAME_CNT];
  /// alive
  int alive;
  /// pwm enabled
  // int pwmEnabled;
  /// position ref 
  int posRef;
  /// velocity ref
  int velRef;
  /// PD controller P value
  int p;
  int pdSet;
  /// PD controller D value
  int d;  
  /// current position
  int pos;
  /// current velocity
  int16_t vel;
  /// current current (force)
  int16_t current;
  /// current Back-EMF
  int16_t bemf;
  /// current supply voltage
  int16_t volt;
  /// current PWM for direction a
  int pwma;
  /// current PWM for direction a
  int pwmb;
  /// minimum allowed position
  int posMin;
  /// maximum allowed position
  int posMax;
  /// scale factor from RHD units to servo units (position)
  float scale;
  /// offsert in servo units from rhd to servo, i.e. servoValue =  rhdValue * scale + offset
  int offset;
  int lastCmd;
  int ioError;
} UServo;



/// variables for MD25 controller
struct
{ /** RHD variables for motor controller */
  int busid;
  // servo read or write variables
  /// servo ID adress on i2c bus
  int varServoID;
  // is communication with servo alive
  int varAlive;
  /** command code (single byte) to send to servo - from twi.h (two wire interface)
   * #define TWI_CMD_RESET                   0x80    128    // Reset command
   * #define TWI_CMD_CHECKED_TXN             0x81    129    // Read/Write registers with simple checksum
   * #define TWI_CMD_PWM_ENABLE              0x82    130    // Enable PWM to motors
   * #define TWI_CMD_PWM_DISABLE             0x83    131    // Disable PWM to servo motors
   * #define TWI_CMD_WRITE_ENABLE            0x84    132    // Enable write of safe read/write registers
   * #define TWI_CMD_WRITE_DISABLE           0x85    133    // Disable write of safe read/write registers
   * #define TWI_CMD_REGISTERS_SAVE          0x86    134    // Save safe read/write registers fo EEPROM
   * #define TWI_CMD_REGISTERS_RESTORE       0x87    135    // Restore safe read/write registers from EEPROM
   * #define TWI_CMD_REGISTERS_DEFAULT       0x88    136    // Restore safe read/write registers to defaults
   * #define TWI_CMD_EEPROM_ERASE            0x89    137    // Erase the EEPROM.
   * #define TWI_CMD_VOLTAGE_READ            0x90    144    // Starts a ADC on the supply voltage channel
   * #define TWI_CMD_CURVE_MOTION_ENABLE     0x91    145    // Enable curve motion processing.
   * #define TWI_CMD_CURVE_MOTION_DISABLE    0x92    146    // Disable curve motion processing.
   * #define TWI_CMD_CURVE_MOTION_RESET      0x93    147    // Reset the curve motion buffer.
   * #define TWI_CMD_CURVE_MOTION_APPEND     0x94    148    // Append curve motion data.
   * 
  */
  int varCmd;
  /**
   * value, ig varCmd is less than 0x30, then this value (byte) is set to register */
  int varCmdVal;
  /// target position seen by robot
  int varPosRef;
  /// target velocity seen by robot
  int varVelRef;
  /// proportional gain
  int varCtrlP;
  /// differential gain
  int varCtrlD;
  /// servo current position
  int varPos;
  /// servo current velocity
//  int varVel;
  /// servo current (force)
  int varCurrent;
  /// servo back-EMF (replaces velocity)
  int varBemf;
  /// servo supply voltage
  int varVolt;
  /// servo PWM to give direction
  /// should probably be converted to signed value
  int varPWMa;
  int varPWMb;
  /// debug servo bank read and display
  int varBank[6];
  int varBankIdx; // servo index variable
  int debugServoIdxOld, debugServoIdx; // servo index values
  // servo version bytes
  int varServoVersion;
  int varIoError;
  int varIoTime;
  // pthread_mutex_t mLock; // pthread_mutex_lock
  sem_t mLock;
  //
  UServo servos[MAX_SERVO_CNT];
  //
  int servosCnt;

} oservo;



#endif


/** \file appareo.c
 *  \ingroup hwmodule
 *  \brief Hardware abstraction layer for Appareo radar ZeroMQ communication
 *
 *  This liberary implements the hardware abstraction layer
 *  for communicating using ethernet on the Appareo radar
 * 
 *  Inspired by hakocan.h
 * 
 *  \author Jesper H. Christensen, DTU
 *   
 *  $Rev: 1 $
 *  $Date: 2016-07-13 12:30:45 +0100 (Wed, 13 July 2016) $
 *  
 */

#ifndef APPAREO_H
  #define APPAREO_H

	extern int initXML(char *);
	extern int periodic(int);
  extern int terminate(void);


#endif


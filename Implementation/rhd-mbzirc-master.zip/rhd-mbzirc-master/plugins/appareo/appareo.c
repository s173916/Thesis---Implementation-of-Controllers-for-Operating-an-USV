/** \file appareo.c
 *  \ingroup hwmodule
 *  \brief Hardware abstraction layer for Appareo radar ZeroMQ communication
 *
 *  This liberary implements the hardware abstraction layer
 *  for communicating using ethernet on the Appareo radar
 * 
 * 
 *  \author Jesper H. Christensen, DTU
 *   
 *  $Rev: 1 $
 *  $Date: 2016-07-13 12:30:45 +0100 (Wed, 13 July 2016) $
 *  
 */
/***************************************************************************
 *                  Copyright 2016 Jesper Haahr Christensen                *
 *                       jehchr@elektro.dtu.dk                             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License as        *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
/************************** Library version  ***************************/
#define APPAREOVERSION 		"0.1"
/************************** Version control information ***************************/
#define REVISION         "$Rev: 1 $:"
#define DATE             "$Date: 2016-07-13 12:30:45 +0100 (Wed, 13 July 2016) $:"
/**********************************************************************************/

#include <sched.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
//#include <sys/types.h>
//#include <sys/stat.h>
#include <fcntl.h>
//#include <termios.h>
#include <stdlib.h>
//#include <errno.h>
//#include <sys/ioctl.h>
#include <signal.h>
//#include <linux/serial.h>
//#include <sys/time.h>
#include <time.h>
#include <sys/mman.h>
#include <expat.h>
#include <sys/stat.h>

#include <rhd.h>
#include <database.h>
#include <globalfunc.h>

#include "appareo.h"
#include "zhelpers.h"

/******** Global variables *************/
///Index pointers for the variable database
int iheartbeatcounter;

//PThread definitions
pthread_t appareorx_thread1;
pthread_t appareorx_thread2;
pthread_t appareorx_thread3;
pthread_t logHandler_thread;
pthread_attr_t attr;

//#define APPAREO_IP   "localhost"
#define APPAREO_PORT "50290"
#define APPAREO_IP   "192.168.68.93"
#define MAX_FILE_SIZE 500000             // max file size for log files in bytes
#define STORAGE_DIR "/mnt/logdisk1/"    // directory to store log files when they exceed MAX_FILE_SIZE
#define USER_PASSWORD_AUT "grenen"


///Flag to indicate if Appareo is running or not
static volatile int appareoRunning = -1;

// Log flag
int logRunning = 0;

FILE *file_fft;
char log_name_fft[64];
FILE *file_raw;
char log_name_raw[64];

//Function prototypes
int initAppareo(void);
void *appareorx_task1(void *);
void *appareorx_task2(void *);
void *appareorx_task3(void *);
void *logHandler_task(void *);

/** \brief Initialization of the Appareo ZeroMQ socket
 *
 * All buffers are initilized and database variables are created.
 * Finally, the RX Thread is spawned
 *
 */
int initAppareo(void)
{

  // ZeroMQ version reporting
  int major, minor, patch;
  zmq_version (&major, &minor, &patch);
  printf ("Appareo: Current ZeroMQ version is %d.%d.%d\n", major, minor, patch);
  
  // Clean up log buffer folder 
  cleanLogFolder();

  // Get time stamp for log files
  time_t rawtime;
  struct tm *info;
  char buffer[80];
  
  time(&rawtime);
  info = localtime(&rawtime);
  
  strftime(buffer,80,"%Y%m%d_%H%M%S", info);
    
  // Create FFT log file
  sprintf(log_name_fft, "APPAREO_fft_%s.csv", buffer);
  file_fft = fopen(log_name_fft, "a+");
  if (file_fft == NULL)
  {
    printf("Appareo: failed creating logfile");
    return -1;
  }
  
  // Write headers to file
  fprintf(file_fft,"time(s), type(up/down), fft_data\n");
  
  // Close fft log
  fclose(file_fft);
  
  // Create raw data log file
  sprintf(log_name_raw, "APPAREO_raw_%s.csv", buffer);
  file_raw = fopen(log_name_raw, "a+");
  if (file_raw == NULL)
  {
    printf("Appareo: failed creating logfile");
    return -1;
  }
  
  // Write headers to file
  fprintf(file_raw,"time(s), raw_data\n");
  
  // Close raw data log file
  fclose(file_raw);

    
  //Create ZMQ RX Threads
  pthread_attr_init(&attr);
  pthread_attr_setinheritsched(&attr, PTHREAD_INHERIT_SCHED);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

  if (pthread_create(&appareorx_thread1, &attr, appareorx_task1, 0)) 
  {
    perror("   Appareo: failed creating appareorx_task1 (raw data)\n");
    return -1;
  }
  
  if (pthread_create(&appareorx_thread2, &attr, appareorx_task2, 0)) 
  {
    perror("   Appareo: failed creating appareorx_task2 (FFT data)\n");
    return -1;
  }
  if (pthread_create(&appareorx_thread3, &attr, appareorx_task3, 0)) 
  {
    perror("   Appareo: failed creating appareorx_task3 (heartbeat)\n");
    return -1;
  }
  
  // Create the loghandler task
  if (pthread_create(&logHandler_thread, &attr, logHandler_task, 0)) 
  {
    perror("   Appareo: failed creating logHandler_task\n");
    return -1;
  }
        
  //Create database variables (if everyting works)
  iheartbeatcounter = createVariable('r',1,"Ray_heartbeat");
      
  return 1;
}

/** \brief Entry-point for Appareo RX Thread
 *
 * Responsible for reading and logging Appareo raw data
 */
void *appareorx_task1(void *not_used)
{
  int frame = 0;
  int i = 0;
  int log = 0;
  struct stat st;
  
  // Connect to Appereo RPi3 server

  printf("Appareo: Subscribing to raw data from RPi3 server\n");
  void *context   = zmq_ctx_new();
  void *subscriber = zmq_socket(context,ZMQ_SUB);
  char publisher[32] = {0};
  sprintf(publisher,"tcp://%s:%s",APPAREO_IP, APPAREO_PORT);
  int rc = zmq_connect(subscriber,publisher);
  assert(rc == 0);

  // subscribe to all data 
  char *filter = "ray.";
  rc = zmq_setsockopt(subscriber,ZMQ_SUBSCRIBE, filter, strlen(filter));
  assert(rc == 0);
  
  fprintf(stderr, "   Appareo: appareorx_task1 (raw data) running (1030)\n");

  if (signal(SIGPIPE, SIG_IGN) == SIG_ERR)
    fprintf(stderr, "signal: can't ignore SIGPIPE.\n");
        
  //Wait to make sure variables are created
  while (appareoRunning < 0) usleep(100000);
  
  struct timeval stamp;
  
  while(appareoRunning)
  { 
    while (1)
    {
      zmq_msg_t message;
      zmq_msg_init (&message);
      zmq_msg_recv (&message, subscriber,0);
                  
      //  Process the message frame
      int size = zmq_msg_size(&message);
      char *string = malloc(size + 1);
      memcpy(string, zmq_msg_data(&message), size);
      
      switch (frame)
      {
        case 0:
          if (strcmp(string, "ray.rawdata") == 0)
          {
            frame = 1;
            
            // Get wheter or not logging should be done on this run
            log = logRunning;
                       
            if (log)
            {
              file_raw = fopen(log_name_raw, "a+");
              if (file_raw == NULL)
              {
                printf("Appareo: failed opening raw data logfile");
                return -1;
              }
              
              gettimeofday(&stamp,NULL);
              fprintf(file_raw,"%ld.%06ld, ",stamp.tv_sec,stamp.tv_usec);
            }
            zmq_msg_close (&message);
            
            string[size] = 0;
          }
          break;
          
        case 1:
          zmq_msg_close (&message);
          string[size] = 0;
                  
          if (log)
          {
            for ( i = 0; i < size; i+=2)
            {
              fprintf(file_raw, "%d, ", (int16_t) ((string[i] & 0xff) +((string[i+1] & 0xff)<<8)));
            }

            fprintf(file_raw, "\n");
            fclose(file_raw);
          }
          frame = 2;
          break;
          
        default:
          break;
      }
      free(string);
      
      // reset frame and get log file size
      if (frame > 1)
      {
        int file = open(log_name_raw,O_RDONLY);
        fstat(file,&st);
        close(file);
        
        frame = 0;
        
        // create new log file if previous is too large and move old one
        if (st.st_size/1000 > MAX_FILE_SIZE)
        {
          printf("Appareo: Moving raw data log file to new location\n");
          // Move log file
          char log_dir[80];
          sprintf(log_dir, "%s%s",STORAGE_DIR,log_name_raw);
          
          rename(log_name_raw,log_dir);
          
          // Generate new with time stamp
          time_t rawtime;
          struct tm *info;
          char buffer[80];
          
          time(&rawtime);
          info = localtime(&rawtime);
          
          strftime(buffer,80,"%Y%m%d_%H%M%S", info);
            
          // Create FFT log file
          sprintf(log_name_raw, "APPAREO_raw_%s.csv", buffer);
          file_raw = fopen(log_name_raw, "a+");
          if (file_raw == NULL)
          {
            printf("Appareo: failed creating logfile");
            return -1;
          }
          
          // Write headers to file
          fprintf(file_raw,"time(s), raw_data\n");
          
          // Close fft log
          fclose(file_raw);
        }
        
        break;
      } 
    }                               
  }
 
  fclose(file_raw);
  
  zmq_close (subscriber);
  zmq_ctx_destroy (context);              

  //Finish thread
  fprintf(stderr,"Appareo: Ending raw data RX Thread!\n");
  appareoRunning = -1;
  pthread_exit(NULL);
}

/** \brief Entry-point for Appareo RX Thread
 *
 * Responsible for reading and logging Appareo FFT data
 */
void *appareorx_task2(void *not_used)
{
  int frame = 0;
  int i = 0;
  int log = 0;
  struct stat st;
  
  // Connect to Appereo RPi3 server

  printf("Appareo: Subscribing to FFT data from RPi3 server\n");
  void *context   = zmq_ctx_new();
  void *subscriber = zmq_socket(context,ZMQ_SUB);
  char publisher[32] = {0};
  sprintf(publisher,"tcp://%s:%s",APPAREO_IP, APPAREO_PORT);
  int rc = zmq_connect(subscriber,publisher);
  assert(rc == 0);

  // subscribe to all data 
  char *filter = "ray.";
  rc = zmq_setsockopt(subscriber,ZMQ_SUBSCRIBE, filter, strlen(filter));
  assert(rc == 0);
  
  union {
    float f;
    unsigned char c[4];
  } getFloat;
  
  fprintf(stderr, "   Appareo: appareorx_task2 (FFT data) running (1030)\n");

  if (signal(SIGPIPE, SIG_IGN) == SIG_ERR)
    fprintf(stderr, "signal: can't ignore SIGPIPE.\n");
        
  //Wait to make sure variables are created
  while (appareoRunning < 0) usleep(100000);
  
  struct timeval stamp;

  while(appareoRunning)
  { 
    while (1)
    {
      zmq_msg_t message;
      zmq_msg_init (&message);
      zmq_msg_recv (&message, subscriber,0);
      
      //  Process the message frame
      int size = zmq_msg_size(&message);
      char *string = malloc(size + 1);
      memcpy(string, zmq_msg_data(&message), size);
      
      switch (frame)
      {
        case 0:
          if (strcmp(string, "ray.fft.data") == 0)
          {
            frame = 1;
            
            // Get wheter or not logging should be done on this run
            log = logRunning;

            if (log)
            {
              file_fft = fopen(log_name_fft, "a+");
              if (file_fft == NULL)
              {
                printf("Appareo: failed opening FFT logfile");
                return -1;
              }
              
              gettimeofday(&stamp,NULL);
              fprintf(file_fft,"%ld.%06ld, ",stamp.tv_sec,stamp.tv_usec);
            
              fprintf(file_fft,"1, ");
            }
            
            zmq_msg_close (&message);
            
            string[size] = 0;
          }
          break;
          
        case 1:
          zmq_msg_close (&message);
          string[size] = 0;
                  
          if (log)
          {
            for (i = 0; i<size; i+=4)
            {
              getFloat.c[0] = string[i]; 
              getFloat.c[1] = string[i+1];
              getFloat.c[2] = string[i+2];
              getFloat.c[3] = string[i+3];
              fprintf(file_fft,"%f, ", getFloat.f);
            }

            fprintf(file_fft, "\n%ld.%06ld, 0, ", stamp.tv_sec,stamp.tv_usec);
          }
                  
          frame = 2;
          break;
          
        case 2:
          zmq_msg_close (&message);
          string[size] = 0;
                  
          if (log)
          {
            for (i = 0; i<size; i+=4)
            {
              getFloat.c[0] = string[i]; 
              getFloat.c[1] = string[i+1];
              getFloat.c[2] = string[i+2];
              getFloat.c[3] = string[i+3];
              fprintf(file_fft,"%f, ", getFloat.f);
            }

            fprintf(file_fft, "\n");
            fclose(file_fft);
          }
          frame = 3;
          break;                   
          
        default:
          break;
      }
      free(string);
      
      // reset frame and get log file size
      if (frame > 2)
      {
        int file = open(log_name_fft,O_RDONLY);
        fstat(file,&st);
        close(file);

        frame = 0;
        
        // create new log file if previous is too large and move old one
        if (st.st_size/1000 > MAX_FILE_SIZE)
        {
          printf("Appareo: Moving FFT log file to new location\n");
          // Move log file
          char log_dir[80];
          sprintf(log_dir, "%s%s",STORAGE_DIR,log_name_fft);
          rename(log_name_fft,log_dir);
          
          // Generate new with time stamp
          time_t rawtime;
          struct tm *info;
          char buffer[80];
          
          time(&rawtime);
          info = localtime(&rawtime);
          
          strftime(buffer,80,"%Y%m%d_%H%M%S", info);
            
          // Create FFT log file
          sprintf(log_name_fft, "APPAREO_fft_%s.csv", buffer);
          file_fft = fopen(log_name_fft, "a+");
          if (file_fft == NULL)
          {
            printf("Appareo: failed creating logfile");
            return -1;
          }
          
          // Write headers to file
          fprintf(file_fft,"time(s), type(up/down), fft_data\n");
          
          // Close fft log
          fclose(file_fft);
        }
                
        break;
      }      
    }                                
  }
 
  fclose(file_fft);
  
  zmq_close (subscriber);
  zmq_ctx_destroy (context);              

  //Finish thread
  fprintf(stderr,"Appareo: Ending FFT RX Thread!\n");
  appareoRunning = -1;
  pthread_exit(NULL);
}

/** \brief Entry-point for Appareo RX Thread
 *
 * Responsible for counting Appareo heartbeat
 */
void *appareorx_task3(void *not_used)
{
  int frame = 0;
  int heartbeatcounter = 0;
     
  // Connect to Appereo RPi3 server

  printf("Appareo: Subscribing to heartbeat from RPi3 server\n");
  void *context   = zmq_ctx_new();
  void *subscriber = zmq_socket(context,ZMQ_SUB);
  char publisher[32] = {0};
  sprintf(publisher,"tcp://%s:%s",APPAREO_IP, APPAREO_PORT);
  int rc = zmq_connect(subscriber,publisher);
  assert(rc == 0);

  // subscribe to all data
  char *filter = "ray.";
  rc = zmq_setsockopt(subscriber,ZMQ_SUBSCRIBE, filter, strlen(filter));
  assert(rc == 0);
  
  fprintf(stderr, "   Appareo: appareorx_task3 (heartbeat) running (1030)\n");

  if (signal(SIGPIPE, SIG_IGN) == SIG_ERR)
    fprintf(stderr, "signal: can't ignore SIGPIPE.\n");
        
  //Wait to make sure variables are created
  while (appareoRunning < 0) usleep(100000);
  
  while(appareoRunning)
  { 
    while (1)
    {
      zmq_msg_t message;
      zmq_msg_init (&message);
      zmq_msg_recv (&message, subscriber,0);
      
      //  Process the message frame
      int size = zmq_msg_size(&message);
      char *string = malloc(size + 1);
      memcpy(string, zmq_msg_data(&message), size);
      
      switch (frame)
      {
        case 0:
          if (strcmp(string, "ray.heartbeat") == 0)
          {
            frame = 1;

            zmq_msg_close (&message);
            
            string[size] = 0;
            
            setArray(iheartbeatcounter,1,&heartbeatcounter);
            
            heartbeatcounter++;
            
            
          }
          break;
        
        default:
          break;
      }
      free(string);
      if (frame > 0)
      {
        frame = 0;
        break;
      } 
    }
                                
  }
  
  zmq_close (subscriber);
  zmq_ctx_destroy (context);              

  //Finish thread
  fprintf(stderr,"Appareo: Ending heartbeat RX Thread!\n");

  appareoRunning = -1;
  pthread_exit(NULL);
}


/**
 * @brief the log handler thread makes sure that incoming data
 * is logged only when "LOG" is pressed in the AGCO GUI.
 * 
 * @param not_used ...
 * @return void*
 */
void* logHandler_task(void* not_used)
{
  while (appareoRunning)
  {
    int i,j;
    symTableElement * syms;
    int symsCnt;
    char c = 'w';
    
    int k;
    
     // write symbol list - read then write
    syms = getSymbolTable(c);
    symsCnt = getSymtableSize(c);
    for (i = 0; i < symsCnt; i++)
    {
      //for (k = 0; k < syms->length; k++)
      char *symname = syms->name;
      if (strcmp(symname, "rhdloginterval") == 0)
      {
        
        if (syms->data[0] > 0)
          logRunning = 1;
        else
          logRunning = 0;
      }
      
      syms++;
    }
    usleep(1000);
  }    
}


/**
 * @brief This checks for any old log files in the buffer folder, 
 * and moves them to the STORAGE_DIR
 * 
 * returns 1 if success
 * 
 * @param  none
 * @return int
 */
int cleanLogFolder(void)
{

  // move old log files to STORAGE_DIR
  printf("Appareo: Moving old log files, if any, to '%s'\n", STORAGE_DIR);
  char str[128] = {0};
  
  sprintf(str, "echo %s | sudo -S mv APPAREO_* %s", USER_PASSWORD_AUT,STORAGE_DIR);
  int i = system(str);
  if (i==0)
  {
    printf("Appareo: Could not move log file: %s\n",log_name_raw);
    return 0;
  }
  
  return 1;
  
}

// extern int terminate(void)
// {
//   // move current log files to STORAGE_DIR
//   printf("Appareo: Moving log files to '%s'\n", STORAGE_DIR);
//   char str[128] = {0};
//   
//   sprintf(str, "echo %s | sudo -S mv %s %s%s", USER_PASSWORD_AUT,log_name_raw,STORAGE_DIR,log_name_raw );
//   int i = system(str);
//   if (i==0)
//   {
//     printf("Appareo: Could not move log file: %s\n",log_name_raw);
//   }
//   sprintf(str, "echo %s | sudo -S mv %s %s%s", USER_PASSWORD_AUT,log_name_fft,STORAGE_DIR,log_name_fft );
//   i = system(str);
//   if (i==0)
//   {
//     printf("Appareo: Could not move log file: %s\n",log_name_fft);
//   }
//   
// }


/************************** XML Initialization **************************/
///Struct for shared parse data
typedef struct  
{
	int depth;
	char skip;
	char enable;
	char found;
}parseInfo;

//Parsing functions
void XMLCALL appareoStartTag(void *, const char *, const char **);
void XMLCALL appareoEndTag(void *, const char *);


/** \brief Initialize the Appareo HAL
 *
 * Reads the XML file and sets up the Appareo settings
 * 
 * Finally the rx thread is started and the server 
 * is ready to accept connections
 * 
 * \param[in] *char filename
 * Filename of the XML file
 * 
 * \returns int status
 * Status of the initialization process. Negative on error.
 */
extern int initXML(char *filename) 
{
	parseInfo xmlParse; 
	char *xmlBuf = NULL;
	int xmlFilelength;
	int done = 0;
	int len;
	FILE *fp;

	//Print initialization message
	//Find revision number from SVN Revision
	char *i,versionString[20] = REVISION, tempString[10];
	i = strrchr(versionString,'$');
	strncpy(tempString,versionString+6,(i-versionString-6));
	tempString[(i-versionString-6)] = 0;
	printf("Appareo: Initializing Appareo ZeroMQ driver %s.%s\n",APPAREOVERSION,tempString);


	/* Initialize Expat parser*/
	XML_Parser parser = XML_ParserCreate(NULL);
	if (! parser) {
		fprintf(stderr, "Appareo: Couldn't allocate memory for XML parser\n");
		return -1;
	}

	//Setup element handlers
	XML_SetElementHandler(parser, appareoStartTag, appareoEndTag);
	//Setup shared data
	memset(&xmlParse,0,sizeof(parseInfo));
	XML_SetUserData(parser,&xmlParse);

	//Open and read the XML file
	fp = fopen(filename,"r");
	if(fp == NULL)
	{
		printf("Appareo: Error reading: %s\n",filename);
		return -1;//fclose(fs);
	}
	//Get the length of the file
	fseek(fp,0,SEEK_END);
	xmlFilelength = ftell(fp); //Get position
	fseek(fp,0,SEEK_SET); //Return to start of file

	//Allocate text buffer
	xmlBuf = realloc(xmlBuf,xmlFilelength+10); //Allocate memory
	if (xmlBuf == NULL) {
		fprintf(stderr, "   Couldn't allocate memory for XML File buffer\n");
		return -1;
	}
	memset(xmlBuf,0,xmlFilelength);
	len = fread(xmlBuf, 1, xmlFilelength, fp);
	fclose(fp);

	//Start parsing the XML file
	if (XML_Parse(parser, xmlBuf, len, done) == XML_STATUS_ERROR) 
	{
		fprintf(stderr, "Appareo: XML Parse error at line %d: %s\n",
				(int)XML_GetCurrentLineNumber(parser),
				XML_ErrorString(XML_GetErrorCode(parser)));
		return -1;
	}
	XML_ParserFree(parser);
	free(xmlBuf);

	//Print error, if no XML tag found
	if (xmlParse.found <= 0) {
		printf("   Error: No <appareo> XML tag found in plugins section\n");
		return -1;
	}

	//Start appareo thread after init
	if (xmlParse.enable) appareoRunning = initAppareo();


	return appareoRunning;
}

///Handle XML Start tags
void XMLCALL
appareoStartTag(void *data, const char *el, const char **attr)
{
  int i;
  parseInfo *info = (parseInfo *) data;
  info->depth++;

  //Check for the right 1., 2. and 3. level tags
  if (!info->skip) {
    if (((info->depth == 1) && (strcmp("rhd",el) != 0)) ||
        ((info->depth == 2) && (strcmp("plugins",el) != 0)) ||
 				((info->depth == 3) && (strcmp("appareo",el) != 0))) {
      info->skip = info->depth;
      return;
    } else if (info->depth == 3) info->found = 1;
  } else return;

  //Branch to parse the elements of the XML file.
  if (!strcmp("appareo",el)) {
    for(i = 0; attr[i]; i+=2) if ((strcmp("enable",attr[i]) == 0) && (strcmp("true",attr[i+1]) == 0)) {
      info->enable = 1; 
    }
    if (!info->enable) {
      printf("   Appareo: Use of Appareo disabled in configuration\n"); 
      info->skip = info->depth;
    }
  } else if (strcmp("controlcan",el) == 0) {
    //Check for the correct depth for this tag
    if(info->depth != 4) {
      printf("Error: Wrong depth for the %s tag\n",el);
    }
//     for(i = 0; attr[i]; i+=2) {
//        if (strcmp("port",attr[i]) == 0) strncpy(canDevString,attr[i+1],63);
//        if (strcmp("port1",attr[i]) == 0) strncpy(canDevString1,attr[i+1],63); 
//     }
//     printf("   HakoCan: Using Control CAN-port %s  %s\n",canDevString,canDevString1);
  }  

}

///Handle XML End tags
void XMLCALL
appareoEndTag(void *data, const char *el)
{
	parseInfo *info = (parseInfo *) data;
	info->depth--;

	if (info->depth < info->skip) info->skip = 0;
}


/** \file canusbems.c
 *  \ingroup hwmodule
 *  \brief General Hardware abstraction layer for communication using CAN-BUS.
 *
 *  This library inplements the hardware abstraction layer
 *  for communicating using CAN-BUS on the all modules.
 * 
 *  At the present state only a simple homing command is implemeted.
 *  This is only used to test communication of various CAN I/O-boards.
 *
 *  \author Jan Lorenz Svensen 
 *  \editor Jesper Haahr Christensen
 *  
 *  $Rev: 2 $
 *  $Date: 2016-07-19 08:51:03 +0200 (Tue, 19 July 2016) $
 *  
 */
/************************** Library version  ***************************/
#define CANUSBEMSVERSION 		"0.2"
/************************** Version control information ***************************/
 #define REVISION         "$Rev: 2 $:"
 #define DATE             "$Date: 2016-07-19 08:51:03 +0200 (Tue, 19 July 2016) $:"
/**********************************************************************************/

#include <sched.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <linux/serial.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <expat.h>
#include <net/if.h>
#include <math.h>

#include <linux/can.h>
#include <linux/can/raw.h>
#include <linux/can/error.h>

//CAN-Driver definitions, placed in include folder
#include <rhd.h>
#include <database.h>
#include <globalfunc.h>

#include "canusbems.h"

/******** Global variables *************/
///Index pointers for the variable database
int idata0log,idata1log,idata2log, ilogchange, idata, idataW, idataSend, idata1, idataW1, idataSend1, idata2, idataW2, idataSend2;

//PThread definitions
pthread_t canrx_thread, canrx_thread1, canrx_thread2;
pthread_attr_t attr;

///Number of CAN-messages to be send to CAN-bus in every cycle
#define CANTXBUFSIZE 4
///Number of CAN-messages to be received from the CAN-bus in every cycle
#define CANRXBUFSIZE 3
#define DFLTENGSP 50

#define BLOCK_MAX 200

#define USER_PASSWORD_AUT "grenen"

///CAN port device identification string
char ifname[64];
char ifname1[64];
char ifname2[64];
///CAN port device baudrate
char can_speed[64];
char can_speed1[64];
char can_speed2[64];
///log file name and address
char log_name[64];
char log_name1[64];
char log_name2[64];
char log_addr[64];
char log_addr1[64];
char log_addr2[64];
// on/off parameters for data logging
int data0log; 
int data1log;
int data2log;
// sensor type
char sensor_type[64];
char sensor1_type[64];
char sensor2_type[64];
// log file pointers
FILE * fs, * fs1, * fs2;
///CAN port pointer
 int s, s1, s2;
// CAN port configuration parameters     
	struct sockaddr_can addr;
    struct can_filter rfilter[1];
    //struct can_filter rfilter[4];
    struct can_frame frame,rxframe,rxframe1,rxframe2;
    int nbytes, i;
    struct ifreq ifr;
    int ifindex;
	struct timeval tv;
	struct tm date;

///Flag to indicate if CanUsb is running or not    
static volatile int CanUsbRunning = -1;

//Function prototypes
int initCanUsb(void);
void *canrx_task(void *);
void *canrx_task1(void *);
void *canrx_task2(void *);

/** \brief Initialization of the CAN-bus and all rx/tx buffers
 *
 * All buffers are initiliazed and database variables are created.
 * Finally, the RX Thread is spawned
 *
 */
int initCanUsb(void){
    int i=-1;
    char str[128] = {0};
    FILE *fp;
    char path[1035];

    // set-up of the can-bus dictated in the config file. 
    if(!(ifname[0]==0)){
      // initiate USB/CAN Port: EMS
	sprintf(str, "ip link show %s up", ifname);
	i = system(str);
	fp = popen(str, "r");
	if(fgets(path, sizeof(path)-1, fp) == NULL && !(fp==NULL)){ // if the CAN port given in ifname, is not initiated, initiate it, else skip section
	    //Execute linux system commands
	    printf("   Initializing CAN-bus device: '%s'\r\n", ifname);
	    
	    if(!system(NULL))
	    {
		puts("Terminal not ready");
		exit(EXIT_FAILURE);
	    }
	    //Check is CAN-2-USB convervter is connected
	    if(i==0){//initializing the can-bus from EMS 
	       
		i=0;
		i += system ("modprobe can");
		i += system ("modprobe can-dev");
		i += system ("modprobe ems_usb");
		sprintf(str, "echo %s | sudo -S ip link set %s up type can bitrate %s", USER_PASSWORD_AUT, ifname, can_speed);
		i += system(str);
		if(i==0)
		{
		    printf("   CAN-bus interface '%s' connected successfully\r\n", ifname);
		}
		else
		{	  
		    printf("Error during setup of '%s'", ifname);
		    printf("'\r\n");
		}
	    }
	    else{      
		printf("   CAN-bus interface '%s' NOT found!\r\n", ifname);
		//puts(str);
		exit(-1);
	    }
	}
	pclose(fp);
	puts("\r\n");

      // Open CAN port
	if ((s = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) {
                perror("socket");
                return 1;
        }
      
      // 
      // set-up of access filter on the canport, such that only messages fullfilling: 
      //      receivec.can_id & mask == can_id & mask
      // can be received.
      //
      /*
        rfilter[0].can_id   = 0x123;       //0b0001.0010.0011
        rfilter[0].can_mask = CAN_SFF_MASK;//0b0111.1111.1111
        
        //set-up of access to the desired can-bus
        rfilter[1].can_id   = 0x460; //0A0: 0b0000.1010.0000 accepts all can_id on the form 0x0XY, where Y is arbritary
        rfilter[1].can_mask = 0x460; //080: 0b0000.1000.0000  and X is between 8 to F inclusive.
        
        rfilter[2].can_id   = 0x80123456;   //0b1000.0000.0001.0010.0011.0100.0101.0110
        rfilter[2].can_mask = 0x1FFFF000;   //0b0001.1111.1111.1111.1111.0000.0000.0000
        
        rfilter[3].can_id   = 0x80333333;   //0b1000.0000.0011.0011.0011.0011.0011.0011
        rfilter[3].can_mask = CAN_EFF_MASK; //0b0001.1111.1111.1111.1111.1111.1111.1111
        can_err_mask_t err_mask = ( CAN_ERR_TX_TIMEOUT | CAN_ERR_BUSOFF );
        //setsockopt(s, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter, sizeof(rfilter));
        */
        
      rfilter[0].can_id    = 0x463;
      rfilter[0].can_mask  = 0x460;
      
      //setsockopt(s, SOL_CAN_RAW, CAN_RAW_ERR_FILTER, &err_mask, sizeof(err_mask));
      
      setsockopt(s, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter, sizeof(rfilter));
      
      // binding canport to the ifname physical port 
        strcpy(ifr.ifr_name, ifname);
        ioctl(s, SIOCGIFINDEX, &ifr);
        ifindex = ifr.ifr_ifindex;

        addr.can_family = AF_CAN;
        addr.can_ifindex = ifindex;

        if (bind(s, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
                perror("bind");
                return 1;
        }
    }
    if(!(ifname1[0]==0)){
      // initiate USB/CAN Port: EMS
	sprintf(str, "ip link show %s up", ifname1);
	i = system(str);
	fp = popen(str, "r");
	if(fgets(path, sizeof(path)-1, fp) == NULL && !(fp==NULL)){ // if the CAN port given in ifname, is not initiated, initiate it, else skip section
	    //Execute linux system commands
	    printf("   Initializing CAN-bus device: '%s'\r\n", ifname1);
	    
	    if(!system(NULL))
	    {
		puts("Terminal not ready");
		exit(EXIT_FAILURE);
	    }
	    //Check is CAN-2-USB convervter is connected
	    if(i==0){//initializing the can-bus
		i=0;
		i += system ("modprobe can");
		i += system ("modprobe can-dev");
		i += system ("modprobe ems_usb");
		sprintf(str, "echo %s | sudo -S ip link set %s up type can bitrate %s", USER_PASSWORD_AUT, ifname1, can_speed1);
		i += system(str);
		if(i==0)
		{
		    printf("   CAN-bus interface '%s' connected successfully\r\n", ifname1);
		}
		else
		{	  
		    printf("Error during setup of '%s'", ifname1);
		    printf("'\r\n");
		}
	    }
	    else{      
		printf("   CAN-bus interface '%s' NOT found!\r\n", ifname1);
		//puts(str);
		exit(-1);
	    }
	}
	pclose(fp);
	puts("\r\n");
	
      // Open CAN port
	if ((s1 = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) {
                perror("socket");
                return 1;
        }
      // 
      // set-up of access filter on the canport, such that only messages fullfilling: 
      //      receivec.can_id & mask == can_id & mask
      // can be received.
      //
      /*
        rfilter[0].can_id   = 0x123;
        rfilter[0].can_mask = CAN_SFF_MASK;
        rfilter[1].can_id   = 0x0A0; //0b1010.0000 accepts all can_id on the form 0xXY, where Y is arbritary
        rfilter[1].can_mask = 0x080; //0b1000.0000  and X is between 8 to F inclusive
	//rfilter[1].can_id   = 0x0A0;
        //rfilter[1].can_mask = 0x0E0;
        rfilter[2].can_id   = 0x80123456;
        rfilter[2].can_mask = 0x1FFFF000;
        rfilter[3].can_id   = 0x80333333;
        rfilter[3].can_mask = CAN_EFF_MASK;
        */
      
        rfilter[0].can_id    = 0x000;
        rfilter[0].can_mask  = 0x000;
      
        setsockopt(s1, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter, sizeof(rfilter));
      
      // binding canport to the ifname physical port 
        strcpy(ifr.ifr_name, ifname1);
        ioctl(s1, SIOCGIFINDEX, &ifr);
        ifindex = ifr.ifr_ifindex;

        addr.can_family = AF_CAN;
        addr.can_ifindex = ifindex;

        if (bind(s1, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
                perror("bind");
                return 1;
        }
    }
    if(!(ifname2[0]==0)){// initiate USB/CAN Port: EMS
	sprintf(str, "ip link show %s up", ifname2);
	i = system(str);
	fp = popen(str, "r");
	if(fgets(path, sizeof(path)-1, fp) == NULL && !(fp==NULL)){ // if the CAN port given in ifname, is not initiated, initiate it, else skip section
	    //Execute linux system commands
	    printf("   Initializing CAN-bus device: '%s'\r\n", ifname2);
	    
	    if(!system(NULL))
	    {
		puts("Terminal not ready");
		exit(EXIT_FAILURE);
	    }
	    //Check is CAN-2-USB convervter is connected
	    if(i==0){//initializing the can-bus
		i=0;
		i += system ("modprobe can");
		i += system ("modprobe can-dev");
		i += system ("modprobe ems_usb");
		sprintf(str, "echo %s | sudo -S ip link set %s up type can bitrate %s", USER_PASSWORD_AUT, ifname2, can_speed2);
		i += system(str);
		if(i==0)
		{
		    printf("   CAN-bus interface '%s' connected successfully\r\n", ifname2);
		}
		else{	  
		    printf("Error during setup of '%s'", ifname2);
		    printf("'\r\n");
		}
	    }
	    else{      
		printf("   CAN-bus interface '%s' NOT found!\r\n", ifname2);
		//puts(str);
		exit(-1);
	    }
	}
	pclose(fp);
	puts("\r\n");
	
      // Open CAN port
	if ((s2 = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) {
                perror("socket");
                return 1;
        }
      // 
      // set-up of access filter on the canport, such that only messages fullfilling: 
      //      receivec.can_id & mask == can_id & mask
      // can be received.
      //
      /*
        rfilter[0].can_id   = 0x123;
        rfilter[0].can_mask = CAN_SFF_MASK;
        rfilter[1].can_id   = 0x0A0; //0b1010.0000 accepts all can_id on the form 0xXY, where Y is arbritary
        rfilter[1].can_mask = 0x080; //0b1000.0000  and X is between 8 to F inclusive
	//rfilter[1].can_id   = 0x0A0;
        //rfilter[1].can_mask = 0x0E0;
        rfilter[2].can_id   = 0x80123456;
        rfilter[2].can_mask = 0x1FFFF000;
        rfilter[3].can_id   = 0x80333333;
        rfilter[3].can_mask = CAN_EFF_MASK;
        */
      
        rfilter[0].can_id   = 0x00;
        rfilter[0].can_mask = 0x00;
      
        setsockopt(s2, SOL_CAN_RAW, CAN_RAW_FILTER, &rfilter, sizeof(rfilter));

      // binding canport to the ifname physical port 
        strcpy(ifr.ifr_name, ifname2);
        ioctl(s2, SIOCGIFINDEX, &ifr);
        ifindex = ifr.ifr_ifindex;

        addr.can_family = AF_CAN;
        addr.can_ifindex = ifindex;

        if (bind(s2, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
                perror("bind");
                return 1;
        }
    }
    
    //Create the CAN RX Threads
    if(!(ifname[0]==0)){ 
      pthread_attr_init(&attr);
      pthread_attr_setinheritsched(&attr, PTHREAD_INHERIT_SCHED);
      pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
      
    #if(1)
      if (pthread_create(&canrx_thread, &attr, canrx_task, 0)) 
      {
	  perror("   CanUSB: failed");
	  return -1;
      }
      #endif
	data0log = 0;
    }
    if(!(ifname1[0]==0)){
      pthread_attr_init(&attr);
      pthread_attr_setinheritsched(&attr, PTHREAD_INHERIT_SCHED);
      pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
      
    #if(1)
      if (pthread_create(&canrx_thread1, &attr, canrx_task1, 0)) 
      {
	  perror("   CanUSB: failed");
	  return -1;
      }
      #endif
	  data1log = 0;
    }
    if(!(ifname2[0]==0)){
      pthread_attr_init(&attr);
      pthread_attr_setinheritsched(&attr, PTHREAD_INHERIT_SCHED);
      pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
      
    #if(1)
      if (pthread_create(&canrx_thread2, &attr, canrx_task2, 0)) 
      {
	  perror("   CanUSB: failed");
	  return -1;
      }
      #endif
	  data2log = 0;
    }
    // each thread is receved for a can bus, such that the can bus define in ifname1 works with the canrx_thread1 thread
    // sensor type request messages start 
	if(strcmp(sensor_type,"headerskid")==0){
		frame.can_id = 0x336;
		frame.can_dlc = 8;
		frame.data[0] = 0x22;
		frame.data[1] = 0x00;
		frame.data[2] = 0x00;
		frame.data[3] = 0x7B; //left skid
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s, &frame, sizeof(struct can_frame));
		printf("wright: %d of %d\n",nbytes,sizeof(struct can_frame));
		frame.data[3] = 0x7C; //right skid
		nbytes = write(s, &frame, sizeof(struct can_frame));
    }else if(strcmp(sensor_type,"ultrasound")==0){
		frame.can_id = 0x306; // 0x3a6: a = getypos of jobpc of i/o pin
		frame.can_dlc = 8;
		frame.data[0] = 0x22; // 0x2b: b = 2(start sending) or 3(end sending)
		frame.data[1] = 0x00;
		frame.data[2] = 0x00; // 0x2c: c = most significant byte for message ID
		frame.data[3] = 0x00; // 0x2d: d = least significant byte for message ID
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s, &frame, sizeof(struct can_frame));
    }else if(strcmp(sensor_type,"radar")==0){
		frame.can_id = 0x306; // 0x3a6: a = getypos of jobpc of i/o pin
		frame.can_dlc = 8;
		frame.data[0] = 0x22; // 0x2b: b = 2(start sending) or 3(end sending)
		frame.data[1] = 0x00;
		frame.data[2] = 0x00; // 0x2c: c = most significant byte for message ID
		frame.data[3] = 0x00; // 0x2d: d = least significant byte for message ID
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s, &frame, sizeof(struct can_frame));
    }
	if(strcmp(sensor1_type,"headerskid")==0){
		frame.can_id = 0x336;
		frame.can_dlc = 8;
		frame.data[0] = 0x22;
		frame.data[1] = 0x00;
		frame.data[2] = 0x00;
		frame.data[3] = 0x7B; //left skid
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s1, &frame, sizeof(struct can_frame));
		frame.data[3] = 0x7C; //right skid
		nbytes = write(s1, &frame, sizeof(struct can_frame));
    }else if(strcmp(sensor1_type,"ultrasound")==0){
		frame.can_id = 0x306; // 0x3a6: a = getypos of jobpc of i/o pin
		frame.can_dlc = 8;
		frame.data[0] = 0x22; // 0x2b: b = 2(start sending) or 3(end sending)
		frame.data[1] = 0x00;
		frame.data[2] = 0x00; // 0x2c: c = most significant byte for message ID
		frame.data[3] = 0x00; // 0x2d: d = least significant byte for message ID
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s1, &frame, sizeof(struct can_frame));
    }else if(strcmp(sensor1_type,"radar")==0){
		frame.can_id = 0x306; // 0x3a6: a = getypos of jobpc of i/o pin
		frame.can_dlc = 8;
		frame.data[0] = 0x22; // 0x2b: b = 2(start sending) or 3(end sending)
		frame.data[1] = 0x00;
		frame.data[2] = 0x00; // 0x2c: c = most significant byte for message ID
		frame.data[3] = 0x00; // 0x2d: d = least significant byte for message ID
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s1, &frame, sizeof(struct can_frame));
    }
	if(strcmp(sensor2_type,"headerskid")==0){
		frame.can_id = 0x336;
		frame.can_dlc = 8;
		frame.data[0] = 0x22;
		frame.data[1] = 0x00;
		frame.data[2] = 0x00;
		frame.data[3] = 0x7B; //left skid
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s2, &frame, sizeof(struct can_frame));
		frame.data[3] = 0x7C; //right skid
		nbytes = write(s2, &frame, sizeof(struct can_frame));
    }else if(strcmp(sensor2_type,"ultrasound")==0){
		frame.can_id = 0x306; // 0x3a6: a = getypos of jobpc of i/o pin
		frame.can_dlc = 8;
		frame.data[0] = 0x22; // 0x2b: b = 2(start sending) or 3(end sending)
		frame.data[1] = 0x00;
		frame.data[2] = 0x00; // 0x2c: c = most significant byte for message ID
		frame.data[3] = 0x00; // 0x2d: d = least significant byte for message ID
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s2, &frame, sizeof(struct can_frame));
    }else if(strcmp(sensor2_type,"radar")==0){
		frame.can_id = 0x306; // 0x3a6: a = getypos of jobpc of i/o pin
		frame.can_dlc = 8;
		frame.data[0] = 0x22; // 0x2b: b = 2(start sending) or 3(end sending)
		frame.data[1] = 0x00;
		frame.data[2] = 0x00; // 0x2c: c = most significant byte for message ID
		frame.data[3] = 0x00; // 0x2d: d = least significant byte for message ID
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s2, &frame, sizeof(struct can_frame));
    }
    
    //
    //Creates database variables (if everyting works)
    //
      
      
      // general can database variables
    idata= createVariable('r',10,"data");
    idata1= createVariable('r',10,"data1");
    idata2= createVariable('r',10,"data2");
    idataW= createVariable('w',11,"dataW");
    idataW1= createVariable('w',11,"dataW1");
    idataW2= createVariable('w',11,"dataW2");
    idataSend= createVariable('w',1,"dataSend");
    idataSend1= createVariable('w',1,"dataSend1");
    idataSend2= createVariable('w',1,"dataSend2");
        idata0log= createVariable('w',1,"data0log");
        idata1log= createVariable('w',1,"data1log");
        idata2log= createVariable('w',1,"data2log");
      // can set up variables(optional)
    ilogchange= createVariable('w',1,"logchange");
    return 1;
    /* system variables used in the canrx threads and the periodic thread
    *  to handling the interaction and return of information between the rhd and the plugin.
    *  
    * Should be changed when the layout/set-up of the threads is changed to include more/less variables.  
    */
    
}

/** \brief Entry-point for Can-Bus RX Threads
 *
 * Responsible for reading and parsing all CAN-Bus messages
 *
 */
void *canrx_task(void *not_used){
  //int j;
  //char str[128] = {0};

  fprintf(stderr, "   CanUSB: Canrx_task running\n");
  if (signal(SIGPIPE, SIG_IGN) == SIG_ERR)
    fprintf(stderr, "signal: can't ignore SIGPIPE.\n");

 	//Wait to make sure variables are created
 	while (CanUsbRunning < 0) usleep(100000);

  	while (CanUsbRunning){
  	    int ret;    
            printf("ready to read data\n");
	    //receive one CAN message
	    ret = read(s, &rxframe, sizeof(struct can_frame));
	    printf("can0 is working, %x\n",rxframe.can_id);
	    if (ret<0){
		fprintf(stderr,"Error receiving message on CAN-bus\n");
		CanUsbRunning = -1; //Shutdown!
	    } 
	    else{
	      printf("data is received\n");
	    //Printout input packages (add additional parsing below)
	      
		/* Uncommet to use, read data manipulation for powercube testing
		//printf("CANRX: ID = 0x%x, %d, %d", rxframe.can_id,rxframe.data[1],rxframe.data[2]);
		if ( (rxframe.can_id & 0x1f)==29){ 
		  if (rxframe.data[1]==60){
		    setVariable (igripperpos,0,(*(float*)&rxframe.data[2])*10000);
		  }
		  else  if (rxframe.data[1]==39){
		    setVariable (istatus,0,(*(int*)&rxframe.data[2]));
		    printf("\n %x  %x  %x  %x \n",rxframe.data[5],rxframe.data[4],rxframe.data[3],rxframe.data[2]);
		    }
		  else {
		    for(j = 0; j <= rxframe.can_dlc; j++)
		      printf("can0, 0x%x", rxframe.data[j]);
		    printf("\n");
		    
		    }
		}  
		else {
		  for(j = 0; j <= rxframe.can_dlc; j++)
		    printf("can0, 0x%x", rxframe.data[j]);
		  printf("\n");
		}
		*/
		//logging & sending can data to rhd and log file
		        gettimeofday(&tv, NULL);
			if(data0log){
				
				fprintf(fs,"%ld.%06ld, %x, %d, %x, %x, %x, %x, %x, %x, %x, %x\n",tv.tv_sec,tv.tv_usec,rxframe.can_id,rxframe.can_dlc,rxframe.data[0],rxframe.data[1],rxframe.data[2],rxframe.data[3],rxframe.data[4],rxframe.data[5],rxframe.data[6],rxframe.data[7]);
			}
			
			printf("%ld.%06ld, %x, %d, %x, %x, %x, %x, %x, %x, %x, %x\n",tv.tv_sec,tv.tv_usec,rxframe.can_id,rxframe.can_dlc,rxframe.data[0],rxframe.data[1],rxframe.data[2],rxframe.data[3],rxframe.data[4],rxframe.data[5],rxframe.data[6],rxframe.data[7]);
			int array[10] = {rxframe.can_id,rxframe.can_dlc,rxframe.data[0],rxframe.data[1],rxframe.data[2],rxframe.data[3],rxframe.data[4],rxframe.data[5],rxframe.data[6],rxframe.data[7]};
			setArray (idata,10,array);
	    } 
	} //RX Loop ends
    // sensor type request messages end 
	if(strcmp(sensor_type,"headerskid")==0){
		frame.can_id = 0x336;
		frame.can_dlc = 8;
		frame.data[0] = 0x23;
		frame.data[1] = 0x00;
		frame.data[2] = 0x00;
		frame.data[3] = 0x7B; //left skid
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s, &frame, sizeof(struct can_frame));
		frame.data[3] = 0x7C; //right skid
		nbytes = write(s, &frame, sizeof(struct can_frame));
    }else if(strcmp(sensor_type,"ultrasound")==0){
		frame.can_id = 0x306; // 0x3a6: a = getypos of jobpc of i/o pin
		frame.can_dlc = 8;
		frame.data[0] = 0x23; // 0x2b: b = 2(start sending) or 3(end sending)
		frame.data[1] = 0x00;
		frame.data[2] = 0x00; // 0x2c: c = most significant byte for message ID
		frame.data[3] = 0x00; // 0x2d: d = least significant byte for message ID
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s, &frame, sizeof(struct can_frame));
    }else if(strcmp(sensor_type,"radar")==0){
		frame.can_id = 0x306; // 0x3a6: a = getypos of jobpc of i/o pin
		frame.can_dlc = 8;
		frame.data[0] = 0x23; // 0x2b: b = 2(start sending) or 3(end sending)
		frame.data[1] = 0x00;
		frame.data[2] = 0x00; // 0x2c: c = most significant byte for message ID
		frame.data[3] = 0x00; // 0x2d: d = least significant byte for message ID
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s, &frame, sizeof(struct can_frame));
    }
	
	//Finish thread
	fclose(fs);
	fprintf(stderr,"CanUSB: Ending RX Thread!\n");
	CanUsbRunning = -1;
	pthread_exit(NULL);
}
void *canrx_task1(void *not_used){
  //int j;
  //char str[128] = {0};

  fprintf(stderr, "   CanUSB: Canrx_task1 running\n");
  if (signal(SIGPIPE, SIG_IGN) == SIG_ERR)
    fprintf(stderr, "signal: can't ignore SIGPIPE.\n");

 	//Wait to make sure variables are created
 	while (CanUsbRunning < 0) usleep(100000);

  	while (CanUsbRunning){
  	    int ret;    
     
	    //receive one CAN message
	    ret = read(s1, &rxframe1, sizeof(struct can_frame));
	    //printf("can1 is working %x\n",rxframe1.can_id);
	    if (ret<0){
		fprintf(stderr,"Error receiving message on CAN-bus\n");
		CanUsbRunning = -1; //Shutdown!
	    } 
	    else{
		//logging & sending can data to rhd and log file
		if(data1log){
			gettimeofday(&tv, NULL);
			fprintf(fs1,"%ld.%06ld, %x, %d, %x, %x, %x, %x, %x, %x, %x, %x\n",tv.tv_sec,tv.tv_usec,rxframe1.can_id,rxframe1.can_dlc,rxframe1.data[0],rxframe1.data[1],rxframe1.data[2],rxframe1.data[3],rxframe1.data[4],rxframe1.data[5],rxframe1.data[6],rxframe1.data[7]);
		}	
		int array[10] = {rxframe1.can_id,rxframe1.can_dlc,rxframe1.data[0],rxframe1.data[1],rxframe1.data[2],rxframe1.data[3],rxframe1.data[4],rxframe1.data[5],rxframe1.data[6],rxframe1.data[7]};
		setArray (idata1,10,array);
	    } 
 	} //RX Loop ends
 	// sensor type request messages end 
	if(strcmp(sensor1_type,"headerskid")==0){
		frame.can_id = 0x336;
		frame.can_dlc = 8;
		frame.data[0] = 0x23;
		frame.data[1] = 0x00;
		frame.data[2] = 0x00;
		frame.data[3] = 0x7B; //left skid
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s, &frame, sizeof(struct can_frame));
		frame.data[3] = 0x7C; //right skid
		nbytes = write(s1, &frame, sizeof(struct can_frame));
    }else if(strcmp(sensor1_type,"ultrasound")==0){
		frame.can_id = 0x306; // 0x3a6: a = getypos of jobpc of i/o pin
		frame.can_dlc = 8;
		frame.data[0] = 0x23; // 0x2b: b = 2(start sending) or 3(end sending)
		frame.data[1] = 0x00;
		frame.data[2] = 0x00; // 0x2c: c = most significant byte for message ID
		frame.data[3] = 0x00; // 0x2d: d = least significant byte for message ID
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s1, &frame, sizeof(struct can_frame));
    }else if(strcmp(sensor1_type,"radar")==0){
		frame.can_id = 0x306; // 0x3a6: a = getypos of jobpc of i/o pin
		frame.can_dlc = 8;
		frame.data[0] = 0x23; // 0x2b: b = 2(start sending) or 3(end sending)
		frame.data[1] = 0x00;
		frame.data[2] = 0x00; // 0x2c: c = most significant byte for message ID
		frame.data[3] = 0x00; // 0x2d: d = least significant byte for message ID
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s1, &frame, sizeof(struct can_frame));
    }
	
 	fclose(fs1);
  	//Finish thread
  	fprintf(stderr,"CanUSB: Ending RX Thread1!\n");
  	CanUsbRunning = -1;
  	pthread_exit(NULL);
}
void *canrx_task2(void *not_used){
  //int j;
  //char str[128] = {0};

  fprintf(stderr, "   CanUSB: Canrx_task2 running\n");
  if (signal(SIGPIPE, SIG_IGN) == SIG_ERR)
    fprintf(stderr, "signal: can't ignore SIGPIPE.\n");

 	//Wait to make sure variables are created
 	while (CanUsbRunning < 0) usleep(100000);

  	while (CanUsbRunning){
  	    int ret;    

	    //receive one CAN message
	    ret = read(s2, &rxframe2, sizeof(struct can_frame));
	    if (ret<0){
		fprintf(stderr,"Error receiving message on CAN-bus\n");
		CanUsbRunning = -1; //Shutdown!
	    } 
	    else{
		//logging & sending can data to rhd and log file
		if(data2log){
			gettimeofday(&tv, NULL);
			fprintf(fs,"%ld.%06ld, %x, %d, %x, %x, %x, %x, %x, %x, %x, %x\n",tv.tv_sec,tv.tv_usec,rxframe2.can_id,rxframe2.can_dlc,rxframe2.data[0],rxframe2.data[1],rxframe2.data[2],rxframe2.data[3],rxframe2.data[4],rxframe2.data[5],rxframe2.data[6],rxframe2.data[7]);
		}
		int array[10] = {rxframe2.can_id,rxframe2.can_dlc,rxframe2.data[0],rxframe2.data[1],rxframe2.data[2],rxframe2.data[3],rxframe2.data[4],rxframe2.data[5],rxframe2.data[6],rxframe2.data[7]};
		setArray (idata2,10,array);
	    } 
 	} //RX Loop ends
 	// sensor type request messages end 
	if(strcmp(sensor2_type,"headerskid")==0){
		frame.can_id = 0x336;
		frame.can_dlc = 8;
		frame.data[0] = 0x23;
		frame.data[1] = 0x00;
		frame.data[2] = 0x00;
		frame.data[3] = 0x7B; //left skid
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s, &frame, sizeof(struct can_frame));
		frame.data[3] = 0x7C; //right skid
		nbytes = write(s2, &frame, sizeof(struct can_frame));
    }else if(strcmp(sensor2_type,"ultrasound")==0){
		frame.can_id = 0x306; // 0x3a6: a = getypos of jobpc of i/o pin
		frame.can_dlc = 8;
		frame.data[0] = 0x23; // 0x2b: b = 2(start sending) or 3(end sending)
		frame.data[1] = 0x00;
		frame.data[2] = 0x00; // 0x2c: c = most significant byte for message ID
		frame.data[3] = 0x00; // 0x2d: d = least significant byte for message ID
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s2, &frame, sizeof(struct can_frame));
    }else if(strcmp(sensor2_type,"radar")==0){
		frame.can_id = 0x306; // 0x3a6: a = getypos of jobpc of i/o pin
		frame.can_dlc = 8;
		frame.data[0] = 0x23; // 0x2b: b = 2(start sending) or 3(end sending)
		frame.data[1] = 0x00;
		frame.data[2] = 0x00; // 0x2c: c = most significant byte for message ID
		frame.data[3] = 0x00; // 0x2d: d = least significant byte for message ID
		frame.data[4] = 0x00;
		frame.data[5] = 0x00;
		frame.data[6] = 0x00; 
		frame.data[7] = 0x00;
		printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
		nbytes = write(s2, &frame, sizeof(struct can_frame));
    }
	
 	fclose(fs2);
  	//Finish thread
  	fprintf(stderr,"CanUSB: Ending RX Thread2!\n");
  	CanUsbRunning = -1;
  	pthread_exit(NULL);
}

/** \brief Transmit messages to the CAN bus
 *
 * Periodic function to transmit variables and
 * requests to the can-bus
 *
 */
extern int periodic(int tick){ 
  char strlog[128] = {0};
  int i;
  
  //Just return if CAN isn't running
  if (CanUsbRunning < 0) return -1;
  
/* POWERCUBE COMMANDS UNCOMMENT TO USE
  union { float a;
  	  unsigned char  b[4];
	 }conv;
 
  // These are examples of variable commands taken from the powercube plugin
  // these are used for testing that the plugin works
  if(isUpdated('w', ipowercubetest)){//homing position of powercube gripper
    printf("-->  Powercube: Trying to send home\n");
     frame.can_id  = 29 + 0xE0;
     frame.can_dlc = 1;
     frame.data[0] = 0x01;

     nbytes = write(s, &frame, sizeof(struct can_frame));
    printf("-->  Powercube: Send done\n");
  }
  if(isUpdated('w', ireset)){
     frame.can_id  = 29 + 0xE0;
     frame.can_dlc = 1;
     frame.data[0] = 0x00;
     nbytes = write(s, &frame, sizeof(struct can_frame));
   }
  if(isUpdated('w', igripper)){  
    printf("-->  Powercube: Trying to send position\n");
     conv.a=getWriteVariable(igripper,0)*0.0001;
     frame.can_id  = 29 + 0xE0;
     frame.can_dlc = 6;
     frame.data[0] = 0x0b;
     frame.data[1] = 0x04;
     frame.data[2] = conv.b[0];
     frame.data[3] = conv.b[1];
     frame.data[4] = conv.b[2];
     frame.data[5] = conv.b[3];
 
     nbytes = write(s, &frame, sizeof(struct can_frame));
   }
  if(isUpdated('w', igrippercur)){   
    printf("-->  Powercube: Trying to send current\n");
     conv.a=getWriteVariable(igrippercur,0)*0.001;
     frame.can_id  = 29 + 0xE0;
     frame.can_dlc = 6;
     frame.data[0] = 0x0b;
     frame.data[1] = 0x08;
     frame.data[2] = conv.b[0];
     frame.data[3] = conv.b[1];
     frame.data[4] = conv.b[2];
     frame.data[5] = conv.b[3];
 
     nbytes = write(s, &frame, sizeof(struct can_frame));
   }
  if(isUpdated('w', igrippervel)){ 
    printf("-->  Powercube: Trying to send velocity\n");
     conv.a=getWriteVariable(igrippervel,0)*0.0001;
     frame.can_id  = 29 + 0xE0;
     frame.can_dlc = 6;
     frame.data[0] = 0x08;
     frame.data[1] = 0x4f;
     frame.data[2] = conv.b[0];
     frame.data[3] = conv.b[1];
     frame.data[4] = conv.b[2];
     frame.data[5] = conv.b[3];
 
     nbytes = write(s, &frame, sizeof(struct can_frame));
   }
  if(isUpdated('w', igripperacc)){
    printf("-->  Powercube: Trying to send acceleration\n");
     conv.a=getWriteVariable(igripperacc,0)*0.0001;
     frame.can_id  = 29 + 0xE0;
     frame.can_dlc = 6;
     frame.data[0] = 0x08;
     frame.data[1] = 0x50;
     frame.data[2] = conv.b[0];
     frame.data[3] = conv.b[1];
     frame.data[4] = conv.b[2];
     frame.data[5] = conv.b[3];
 
     nbytes = write(s, &frame, sizeof(struct can_frame));
   }
   #if(1)
     frame.can_id  = 29 + 0xC0; //0xdd, 29=0x1d
     frame.can_dlc = 2;
     frame.data[0] = 0x0a;
     frame.data[1] = 60;
     nbytes = write(s, &frame, sizeof(struct can_frame));
     
     frame.can_id  = 29 + 0xC0; //0xdd, 29=0x1d
     frame.can_dlc = 2;
     frame.data[0] = 0x0a;
     frame.data[1] = 60;
     nbytes = write(s1, &frame, sizeof(struct can_frame));
     if (isUpdated('w', igs)){
       frame.can_id  = 29 + 0xC0;
       frame.can_dlc = 2;
       frame.data[0] = 0x0a;
       frame.data[1] = 39;
       nbytes = write(s, &frame, sizeof(struct can_frame));
     }
  #endif
*/
  //
  if(isUpdated('w',idataSend)){
    int scale = getWriteVariable(idataW,10); // used to scale the data, for the case of float and double
    frame.can_id = getWriteVariable(idataW,0);
    frame.can_dlc = getWriteVariable(idataW,1);
    frame.data[0] = getWriteVariable(idataW,2);
    frame.data[1] = getWriteVariable(idataW,3);
    // may need some scaling for the access to floats and double
    frame.data[2] = getWriteVariable(idataW,4)*((int) pow(10,scale));
    frame.data[3] = getWriteVariable(idataW,5)*((int) pow(10,scale));
    frame.data[4] = getWriteVariable(idataW,6)*((int) pow(10,scale));
    frame.data[5] = getWriteVariable(idataW,7)*((int) pow(10,scale));
    frame.data[6] = getWriteVariable(idataW,8)*((int) pow(10,scale));
    frame.data[7] = getWriteVariable(idataW,9)*((int) pow(10,scale));
    printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
    nbytes = write(s, &frame, sizeof(struct can_frame));
  }
  if(isUpdated('w',idataSend1)){
    int scale = getWriteVariable(idataW1,10); // used to scale the data, for the case of float and double
    frame.can_id = getWriteVariable(idataW1,0);
    frame.can_dlc = getWriteVariable(idataW1,1);
    frame.data[0] = getWriteVariable(idataW1,2);
    frame.data[1] = getWriteVariable(idataW1,3);
    // may need some scaling for the access to floats and double
    frame.data[2] = getWriteVariable(idataW1,4)*((int) pow(10,scale));
    frame.data[3] = getWriteVariable(idataW1,5)*((int) pow(10,scale));
    frame.data[4] = getWriteVariable(idataW1,6)*((int) pow(10,scale));
    frame.data[5] = getWriteVariable(idataW1,7)*((int) pow(10,scale));
    frame.data[6] = getWriteVariable(idataW1,8)*((int) pow(10,scale));
    frame.data[7] = getWriteVariable(idataW1,9)*((int) pow(10,scale));
    printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
    nbytes = write(s1, &frame, sizeof(struct can_frame));
  }
  if(isUpdated('w',idataSend2)){
    
    int scale = getWriteVariable(idataW2,10); // used to scale the data, for the case of float and double
    frame.can_id = getWriteVariable(idataW2,0);
    frame.can_dlc = getWriteVariable(idataW2,1);
    frame.data[0] = getWriteVariable(idataW2,2);
    frame.data[1] = getWriteVariable(idataW2,3);
    // may need some scaling for the access to floats and double
    frame.data[2] = getWriteVariable(idataW2,4)*((int) pow(10,scale));
    frame.data[3] = getWriteVariable(idataW2,5)*((int) pow(10,scale));
    frame.data[4] = getWriteVariable(idataW2,6)*((int) pow(10,scale));
    frame.data[5] = getWriteVariable(idataW2,7)*((int) pow(10,scale));
    frame.data[6] = getWriteVariable(idataW2,8)*((int) pow(10,scale));
    frame.data[7] = getWriteVariable(idataW2,9)*((int) pow(10,scale));
    printf("\n Sending message to can_id:, %x, data size: %d\n",frame.can_id,frame.can_dlc);
    nbytes = write(s2, &frame, sizeof(struct can_frame));
  }
  // optional commands for design and running

  if(isUpdated('w',idata0log)){ // turning datalogging on can0 on/off
    int datalog = getWriteVariable(idata0log,0);
	//Wait to make sure variables are created

	if(datalog==0){
	  printf("stops logging data\n");
	   data0log	= 0;
	   usleep(100000);
	   fclose(fs);
	}else{
	   printf("starts logging data\n");
	   gettimeofday(&tv, NULL);
	   //printf("test file opens\n");
	   time_t now = tv.tv_sec;
	   date = *localtime(&now);
	   char strdate[64];
	   //printf("test file opens\n");
           sprintf(strdate, "_%02d%02d%02d_%02d%02d%02d.csv", date.tm_year+1900,date.tm_mon+1,date.tm_mday,date.tm_hour,date.tm_min,date.tm_sec);
	   strcpy(log_name,"");
	   //printf("test file opens%s\n",log_name);
	   strcat(strcat(strcat(log_name,"CAN0_"),sensor_type),strdate);
	   //printf("test file opens\n");
	   fs = fopen(strcat(strcat(strcat(strlog,log_addr),"/"),log_name), "a");
           if(fs == NULL){
                  printf("Couldn't open file:%s\n",log_name);
		  data0log = 0;
		  goto nofile;
           }else{
		   data0log = 1;
	   }
	   fprintf(fs,"time(s.mus), can_id, can_dlc, data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7]\n");
	   nofile: ;
	}
  }
  if(isUpdated('w',idata1log)){ // turning datalogging on can0 on/off
    int datalog = getWriteVariable(idata1log,0);
	//Wait to make sure variables are created
	if(datalog==0){
	   data1log = 0;
	   usleep(100000);
	   fclose(fs1);
	}else{
	   gettimeofday(&tv, NULL);
	   time_t now = tv.tv_sec;
	   date = *localtime(&now);
	   char strdate[64];
           sprintf(strdate, "_%02d%02d%02d_%02d%02d%02d", date.tm_year+1900, date.tm_mon+1, date.tm_mday, date.tm_hour, date.tm_min,date.tm_sec);
           strcpy(log_name,"");
	   strcat(strcat(strcat(log_name1,"CAN1_"),sensor1_type),strdate);
	   fs1 = fopen(strcat(strcat(strcat(strlog,log_addr1),"/"),log_name1), "a");
       if(fs1 == NULL){
          printf("Couldn't open file:%s\n",log_name);
		  data1log = 0;
		  goto nofile1;
       }else{
		   data1log = 1;
	   }
	   fprintf(fs1,"time(s.mus), can_id, can_dlc, data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7]\n");
	   nofile1: ;
	}
  }
  if(isUpdated('w',idata2log)){ // turning datalogging on can0 on/off
    int datalog = getWriteVariable(idata2log,0);
	//Wait to make sure variables are created
	if(datalog==0){
	   data2log = 0;
	   usleep(100000);
	   fclose(fs2);
	}else{
	   gettimeofday(&tv, NULL);
	   time_t now = tv.tv_sec;
	   date = *localtime(&now);
	   char strdate[64];
           sprintf(strdate, "_%02d%02d%02d_%02d%02d%02d", date.tm_year+1900,date.tm_mon+1,date.tm_mday,date.tm_hour, date.tm_min, date.tm_sec);
           strcpy(log_name,"");
	   strcat(strcat(strcat(log_name2,"CAN2_"),sensor2_type),strdate);
	   fs2 = fopen(strcat(strcat(strcat(strlog,log_addr2),"/"),log_name2), "a");
       if(fs2 == NULL){
          printf("Couldn't open file:%s\n",log_name);
		  data2log = 0;
		  goto nofile2;
       }else{
		   data2log = 1;
	   }
	   fprintf(fs,"time(s.mus), can_id, can_dlc, data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7]\n");
	   nofile2: ;
	}
  }
  if(isUpdated('w',ilogchange)){ // changing log file name while system is running
    int log_i = getWriteVariable(ilogchange,0);
    printf("enter the file address for the log file:  ");
    i=-1;
    while(i<0){
      i = scanf("%s",strlog);
    }
    if(log_i == 0){
       sprintf(log_addr,"%s",strlog);
    }
    else if(log_i == 1){
       sprintf(log_addr1,"%s",strlog);
    }
    else if(log_i == 2){
       sprintf(log_addr2,"%s",strlog);
    }
    else{
       printf("Wrong index: the index should be between 0-2, corresponding to can port of the logfile\n\n");
       goto wrongindex;
    }  
  }
  wrongindex: ;
  return 1;
}

/************************** XML Initialization **************************/
///Struct for shared parse data
typedef struct {
    	int depth;
    	char skip;
	char enable;
	char found;
}parseInfo;

//Parsing functions
void XMLCALL CanUsbStartTag(void *, const char *, const char **);
void XMLCALL CanUsbEndTag(void *, const char *);

/** \brief Initialize the Crossbow HAL
 *
 * Reads the XML file and sets up the Crossbow settings
 * 
 * Finally the rx thread is started and the server 
 * is ready to accept connections
 * 
 * \param[in] *char filename
 * Filename of the XML file
 * 
 * \returns int status
 * Status of the initialization process. Negative on error.
 */
extern int initXML(char *filename){

	parseInfo xmlParse; 
	char *xmlBuf = NULL;
	int xmlFilelength;
	int done = 0;
	int len;
	FILE *fp;

	//Print initialization message
	//Find revision number from SVN Revision
	char *i,versionString[20] = REVISION, tempString[10];
	i = strrchr(versionString,'$');
	strncpy(tempString,versionString+6,(i-versionString-6));
	tempString[(i-versionString-6)] = 0;
	printf("CanUsbEMS: Initializing CanUsb CAN-Bus driver %s.%s\n",CANUSBEMSVERSION,tempString);


	/* Initialize Expat parser*/
	XML_Parser parser = XML_ParserCreate(NULL);
	if (! parser) {
		fprintf(stderr, "CanUSB: Couldn't allocate memory for XML parser\n");
		return -1;
	}

   	//Setup element handlers
	XML_SetElementHandler(parser, CanUsbStartTag, CanUsbEndTag);
	
   	//Setup shared data
   	memset(&xmlParse,0,sizeof(parseInfo));
   	XML_SetUserData(parser,&xmlParse);

	//Open and read the XML file
  	fp = fopen(filename,"r");
  	if(fp == NULL)
  	{
  		printf("CanUSB: Error reading: %s\n",filename);
  		return -1;
  	}
  	//Get the length of the file
	fseek(fp,0,SEEK_END);
	xmlFilelength = ftell(fp); //Get position
	fseek(fp,0,SEEK_SET); //Return to start of file

	//Allocate text buffer
	xmlBuf = realloc(xmlBuf,xmlFilelength+10); //Allocate memory
	if (xmlBuf == NULL) {
		fprintf(stderr, "   Couldn't allocate memory for XML File buffer\n");
		return -1;
	}
	memset(xmlBuf,0,xmlFilelength);
	len = fread(xmlBuf, 1, xmlFilelength, fp);
	fclose(fp);

	//Start parsing the XML file
	if (XML_Parse(parser, xmlBuf, len, done) == XML_STATUS_ERROR) 
	{
		fprintf(stderr, "CanUSB: XML Parse error at line %d: %s\n",
        			(int)XML_GetCurrentLineNumber(parser),
        			XML_ErrorString(XML_GetErrorCode(parser)));
    		return -1;
  	}
  	
  	XML_ParserFree(parser);
	free(xmlBuf);

	//Print error, if no XML tag found
	if (xmlParse.found <= 0) {
		printf("   Error: No <CanUsbEMS> XML tag found in plugins section\n");
		return -1;
	}

	//Start crossbow thread after init
	if (xmlParse.enable) CanUsbRunning = initCanUsb();


	return CanUsbRunning;
}
///Handle XML Start tags(sets can port definitions from the xml file)
void XMLCALL
CanUsbStartTag(void *data, const char *el, const char **attr){
  int i;
  parseInfo *info = (parseInfo *) data;
  info->depth++;

  //Check for the right 1., 2. and 3. level tags
  if (!info->skip) {
    if (((info->depth == 1) && (strcmp("rhd",el) != 0)) ||
        ((info->depth == 2) && (strcmp("plugins",el) != 0)) ||
 				((info->depth == 3) && (strcmp("canusb",el) != 0))) {
      info->skip = info->depth;
      return;
    } else if (info->depth == 3) info->found = 1;
  } else return;

  //Branch to parse the elements of the XML file.
  if (!strcmp("canusb",el)) 
  {
    for(i = 0; attr[i]; i+=2) if ((strcmp("enable",attr[i]) == 0) && (strcmp("true",attr[i+1]) == 0)) 
    {
      info->enable = 1; 
    }
    if (!info->enable) {
      printf("   CanUSB: Use of CanUSB disabled in configuration\n"); 
      info->skip = info->depth;
    }
  } else if (strcmp("controlcan",el) == 0) {
    //Check for the correct depth for this tag
    if(info->depth != 4) {
      printf("Error: Wrong depth for the %s tag\n",el);
    }
    //
    //initializes the desired canport variables/tags
    //
    for(i = 0; attr[i]; i+=2) {
      //sets up the first can port (can0)
       if (strcmp("port",attr[i]) == 0){ strncpy(ifname,attr[i+1],63);}
       if (strcmp("baudrate",attr[i]) == 0){ strncpy(can_speed,attr[i+1],63);}
       if (strcmp("sensor",attr[i]) == 0){ strncpy(sensor_type,attr[i+1],63);}
       if (strcmp("logaddr",attr[i]) == 0){ strncpy(log_addr,attr[i+1],63);}
      //sets up the second can port (can1) 
       if (strcmp("port1",attr[i]) == 0){ strncpy(ifname1,attr[i+1],63);}
       if (strcmp("baudrate1",attr[i]) == 0){ strncpy(can_speed1,attr[i+1],63);}
       if (strcmp("sensor1",attr[i]) == 0){ strncpy(sensor1_type,attr[i+1],63);}
       if (strcmp("logaddr1",attr[i]) == 0){ strncpy(log_addr1,attr[i+1],63);}
      //sets up the third can port (can2) 
       if (strcmp("port2",attr[i]) == 0){ strncpy(ifname2,attr[i+1],63);}
       if (strcmp("baudrate2",attr[i]) == 0){ strncpy(can_speed2,attr[i+1],63);}
       if (strcmp("sensor2",attr[i]) == 0){ strncpy(sensor2_type,attr[i+1],63);}
	   if (strcmp("logaddr2",attr[i]) == 0){ strncpy(log_addr2,attr[i+1],63);}
    }
    // default logging address
    if(strcmp(log_addr,"")==0){strncpy(log_addr,getcwd(log_addr, sizeof(log_addr)),63);}
    if(strcmp(log_addr1,"")==0){strncpy(log_addr1,getcwd(log_addr1, sizeof(log_addr1)),63);}
    if(strcmp(log_addr2,"")==0){strncpy(log_addr2,getcwd(log_addr2, sizeof(log_addr2)),63);}
    
    if(!(strcmp(ifname,"")==0) && (strcmp("port",attr[0]) == 0)){
      printf("   CanUSB: Using CAN-port %s, baudrate %s\n 		    sensor: %s\n 		    log address:%s\n",ifname,can_speed,sensor_type,log_addr);
    }
    if(!(strcmp(ifname1,"")==0) && (strcmp("port1",attr[0]) == 0)){
      printf("   CanUSB: Using CAN-port %s, baudrate %s\n 		    sensor: %s\n 		    log address:%s\n",ifname1,can_speed1,sensor1_type,log_addr1);
    }
    if(!(strcmp(ifname2,"")==0) && (strcmp("port2",attr[0]) == 0)){
      printf("   CanUSB: Using CAN-port %s, baudrate %s\n 		    sensor: %s\n 		    log address:%s\n",ifname2,can_speed2,sensor2_type,log_addr2);      
    }
  }  

}
///Handle XML End tags
void XMLCALL
CanUsbEndTag(void *data, const char *el){
	parseInfo *info = (parseInfo *) data;
	info->depth--;

	if (info->depth < info->skip) info->skip = 0;
}
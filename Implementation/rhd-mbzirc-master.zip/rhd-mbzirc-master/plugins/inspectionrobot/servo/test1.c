/*
 * test1.c
 *
 * Created: 15-01-2014 17:05:52
 *  Author: markushatg
 */ 

/*
#include <avr/io.h>

int main(void)
{
    while(1)
    {
        //TODO:: Please write your application code 
    }
}
*/
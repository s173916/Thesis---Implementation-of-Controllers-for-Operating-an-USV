/** @file 	EDSKDecode.h
 *	@brief	Function prototypes for the EDSKDecode library
 *
 *	This contains the prototypes for the EDSKDecode library
 *
 *	@author	Visscher Eric	
 *	@author	Linzberger David
 *	@bug	No known bugs.
 */

#ifndef __EDSKDecode_H__
#define __EDSKDecode_H__

#include <stdint.h>

/**	@brief	Decode a message form an input stream
 *	
 *	param[in]  au8_Msg[]		The message to decode. May be shorter than the
 *								buffer size but then must be terminated by a byte
 *								value lower than 0x20.
 *	param[in]  s32_MsgLen		The size of the message data buffer.
 *	param[out] as32_DebugData[]	The data buffer to store the decoded data to.
 *								Must be large enough to hold all expected data.
 *								Since the decoder does not know about the original data
 *								types that are sent through the comm line, the decoder
 *								decodes all values as int32_t. It is up to the application
 *								to restore the original data type (eg. by cast).
 *	param[in]  s32_DebDataLen	The size of the debug data buffer
 *	param[in]  s32_VarCnt		The number of data values to expect (for each list).
 *								A zero value means that the check is omitted for the
 *								corresponding message.
 *
 *	return Not zero when message was decoded successfully
 */
int DecodeMessage(
	const uint8_t  au8_Msg[],
	const int32_t  s32_MsgLen,
	int32_t  as32_DebugData[],
	const int32_t  s32_DebDataLen,
	const int32_t  s32_VarCnt
);

#endif /* __EDSKDecode_H__ */

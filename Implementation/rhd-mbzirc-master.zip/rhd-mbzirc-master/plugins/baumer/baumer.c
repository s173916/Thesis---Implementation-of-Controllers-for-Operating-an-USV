/** \file baumer.c
 *  \ingroup hwmodule
 *  \brief Serial Baumer Module
 *
 *  Baumer Module for RHD. 
 * 
 *  Based on IMU by Dan Hermann
 *
 *  \author Jesper Haahr Christensen
 *  $Rev: 862 $
 *  $Date: 2016-08-12 11:03:02 +0200 (Fri, 12 Aug 2016) $
 */
 /**************************************************************************
 *                  Copyright 2016 Jesper Haahr Christensen                *
 *                       jehchr@elektro.dtu.dk                             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License as        *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
/***************************** Plugin version  *****************************/
#define BAUMERVERSION 	      "1.0"
/*********************** Version control information ***********************/
 #define REVISION         "$Rev: 862 $"
 #define DATE             "$Date: 2016-08-12 11:03:02 +0200 (Fri, 12 Aug 2016) $"
 #define ID               "$Id: baumer.c 862 2016-08-12 09:03:02Z jehchr $"
/***************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <netdb.h>
#include <fcntl.h>
#include <string.h>
#include <pthread.h>
#include <signal.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <errno.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <linux/serial.h>
#include <expat.h>
#include <math.h>

#include <database.h>
#include "baumer.h"
#include "EDSKDecode.h"

// Definitions
#define STORAGE_DIR "/mnt/logdisk1/"    // directory to store log files when they exceed MAX_FILE_SIZE
#define USER_PASSWORD_AUT "grenen"


//Definitions
char insDevStringDecl[64];   ///String to hold INS device(s)
int  baudrate = 0;
int fd = 0;
static volatile char running = 0;
FILE *file_fft;
char log_name_fft[64];
FILE *file_encrypted;
char log_name_encrypted[64];
// Log flag
int logRunning = 0;

/// database indexes
// uint32_t itimestamp, idist, igain, idistances;
// uint16_t itemp;

// Threads are being defined
pthread_t ins_thread_read;
pthread_t logHandler_thread;

//Function prototypes
int initINS(void);
int set_serial(int fd, int baud);
int secureWrite(int fd, const void *buf, ssize_t txLen);
int secureRecv(int fd, void *buf, ssize_t txLen);
void *ins_task_read(void *);
void baumer_send(char *msg);
void *logHandler_task(void *);

/** \brief Initialize Baumer module
 * 
 * \returns int status
 * Status of the server thread - negative on error.
 */
int initINS(void) {     
        
  printf("   Baumer: Opening on %s\n", insDevStringDecl);
  
  // open port
  fd = open(insDevStringDecl, O_RDWR | O_NONBLOCK);
  if (fd < 0)
  {
    fprintf(stderr, "   Baumer: Error opening %s\n", insDevStringDecl);
    return -1;
  }
  
  // set baudrate
  if (set_serial(fd, baudrate) == -1)
  {
    fprintf(stderr,"   Baumer: Can't set Baumer serial port parameters\n");
    return -1;
  }

    
  running = 1;
  
  // Create variable database
//   itimestamp =  createVariable('r',1,"baumer_timestamp");
//   itemp =       createVariable('r',1,"baumer_temp");
//   idist=        createVariable('r',1,"baumer_distance");
//   igain =       createVariable('r',1,"baumer_gain");
//   idistances =  createVariable('r',4,"baumer_distances");
  
  // Clean up log buffer folder 
  cleanLogFolder();

  // Get time stamp for log files
  time_t rawtime;
  struct tm *info;
  char buffer[80];
  
  time(&rawtime);
  info = localtime(&rawtime);
  
  strftime(buffer,80,"%Y%m%d_%H%M%S", info);
    
  // Create FFT log file
  sprintf(log_name_fft, "BAUMER_fft_%s.csv", buffer);
  file_fft = fopen(log_name_fft, "a+");
  if (file_fft == NULL)
  {
    printf("Baumer: failed creating logfile");
    return -1;
  }
  
  // Write headers to file
  fprintf(file_fft,"timestamp, temp, distance, gain, fft(1), fft(2), fft(3), fft(4), fft(5), fft(6), fft(7), fft(8), fft(9), fft(10), fft(11), fft(12), fft(13), fft(14), fft(15), fft(16), fft(17), fft(18), fft(19), fft(20),fft(21), fft(22), fft(23), fft(24), fft(25), fft(26), fft(27), fft(28), fft(29), fft(30), fft(31),fft(32), fft(33), fft(34), fft(35), fft(36), fft(37), fft(38), fft(39), fft(40), fft(41), fft(42),fft(43), fft(44), fft(45), fft(46), fft(47), fft(48), fft(49), fft(50), distance(1), distance(2),distance(3), distance(4), valid_dist\n");
  
  // Close fft log
  fclose(file_fft);
  
  // Create ecrypted data log file
  sprintf(log_name_encrypted, "BAUMER_encr_%s.csv", buffer);
  file_encrypted = fopen(log_name_encrypted, "a+");
  if (file_encrypted == NULL)
  {
    printf("Baumer: failed creating logfile");
    return -1;
  }
  
  // Write headers to file
  fprintf(file_encrypted,"Encrypted data from Baumer sensor\n");
  
  // Close raw data log file
  fclose(file_encrypted);

  // Initialization and starting of threads
  pthread_attr_t attr;
  pthread_attr_init(&attr);
  pthread_attr_setinheritsched(&attr, PTHREAD_INHERIT_SCHED);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

  if (pthread_create(&ins_thread_read, &attr, ins_task_read, 0))
  {
    perror("   Baumer: Can't start Baumer read thread");
    return -1;
  }
  // Create the loghandler task
  if (pthread_create(&logHandler_thread, &attr, logHandler_task, 0)) 
  {
    perror("   Baumer: failed creating logHandler_task\n");
    return -1;
  }
  
  // Ask radar for continous FFT data
  char *msg = "GET3\r";
  baumer_send(msg);
    
  return 1;
}

/** \brief Initialize Shut down Baumer rx thread
 * 
 * \returns int status
 * Status of the server thread - negative on error.
 */
int shutdownINS(void) {

  running = 0;
  
  pthread_join(ins_thread_read,NULL);

  return 1;
}
  

/** \brief Baumer RX thread.
 */
void *ins_task_read(void *not_used) {
  
  char buffer[15000] = {0};
  int DebugData[15000];
  int newDataFlag = 0;
  int i = 0, d=0, j=0;
  float *f1;

  
  //Recieve from Baumer
  printf("   Baumer: Receive thread started\n");

  while (running < 0) usleep(100000);
  
  while(running)
  {
    
    if (fd != -1)
    {
      
      int rx_length = read(fd, &buffer[i], 1);
      
      if (rx_length < 0)
      {
        // error
      }
      else if (rx_length == 0)
      {
        // no data waiting
      }
      else
      {
    
        if (buffer[i] == 0x0A)
        {
          buffer[i+1] = '\0';
          i = 0;
          
          // decode data
          int ret = DecodeMessage((unsigned char *)buffer,strlen( buffer),DebugData,15000,0);

          if (logRunning && ret != 0)
          {
            file_encrypted = fopen(log_name_encrypted, "a+");
            if (file_encrypted == NULL)
            {
              printf("Baumer: failed opening encrypted data logfile");
              return -1;
            }
            for (i = 0; i <= strlen(buffer); i++)
            {
              fprintf(file_encrypted, "%hhx ", buffer[i]);
            }
            fprintf(file_encrypted, "\n");
            fclose(file_encrypted);
          }
          
          if( ret != 0 && logRunning)
          { // decode successful - open log file
            file_fft = fopen(log_name_fft, "a+");
            if (file_fft == NULL)
            {
              printf("Baumer: failed opening fft data logfile");
              return -1;
            }
            for( i = 0; i < 59; i++ )
            {
              if( i == 0 )
              { // Timestamp
                //sprintf( bout, "%d\t%d\n", i, (unsigned int)DebugData[i] );
                fprintf(file_fft,"%d, ", (unsigned int)DebugData[i]);
              }
              else if( i == 1 )
              { // Temperature
                //sprintf( bout, "%d\t%d\n", i, (short)DebugData[i] );
                fprintf(file_fft, "%d, ", (short)DebugData[i]);
              }
              else if( i == 2 )
              { // Distance
                //sprintf( bout, "%d\t%d\n", i, (unsigned int)DebugData[i] );
                fprintf(file_fft,"%d, ", (unsigned int)DebugData[i]);
              }
              else if( i == 3 )
              { // Gain
                //sprintf( bout, "%d\t%d\n", i, (unsigned int)DebugData[i] );
                fprintf(file_fft, "%d, ", (unsigned int)DebugData[i]);
              }
              else if( i >= 4 && i <= 53 )
              { // FFT Data
                f1 = (float *)&DebugData[i];
                //sprintf( bout, "%d\t%f\n", i, *f1 );
                fprintf(file_fft, "%f, ", *f1);
              }
              else if( i >= 54 && i <= 57 )
              { // Distances
                //sprintf( bout, "%d\t%d\n", i, (unsigned int)DebugData[i] );
                fprintf(file_fft,"%d, ", (unsigned int)DebugData[i]);
                printf("%d ", (unsigned int)DebugData[i]);
              }
              else
              { // Number of valid distances
                //sprintf( bout, "%d\t%d\n", i, (unsigned char)DebugData[i] );
                fprintf(file_fft,"%d\n", (unsigned char)DebugData[i]);
                printf("\n");
              }
            }
            fclose(file_fft);
          }
          else { // could not decode
            
          }
        }
        else
        {
          i++;
        }
      }
    }
  usleep(10);       
  } //Ending Baumer loop
  fprintf(stderr,"   Baumer: Shutdown Baumer read task\n");
  pthread_exit(0);
}

/**
 * @brief the log handler thread makes sure that incoming data
 * is logged only when "LOG" is pressed in the AGCO GUI.
 * 
 * @param not_used ...
 * @return void*
 */
void* logHandler_task(void* not_used)
{
  while (running)
  {
    int i,j;
    symTableElement * syms;
    int symsCnt;
    char c = 'w';
    
    int k;
    
     // write symbol list - read then write
    syms = getSymbolTable(c);
    symsCnt = getSymtableSize(c);
    for (i = 0; i < symsCnt; i++)
    {
      //for (k = 0; k < syms->length; k++)
      char *symname = syms->name;
      if (strcmp(symname, "rhdloginterval") == 0)
      {
        
        if (syms->data[0] > 0)
          logRunning = 1;
        else
          logRunning = 0;
      }
      
      syms++;
    }
    usleep(1000);
  }    
}

/**
 * @brief This checks for any old log files in the buffer folder, 
 * and moves them to the STORAGE_DIR
 * 
 * returns 1 if success
 * 
 * @param  none
 * @return int
 */
int cleanLogFolder(void)
{

  // move old log files to STORAGE_DIR
  printf("Baumer: Moving old log files, if any, to '%s'\n", STORAGE_DIR);
  char str[128] = {0};
  
  sprintf(str, "echo %s | sudo -S mv BAUMER_* %s", USER_PASSWORD_AUT,STORAGE_DIR);
  int i = system(str);
  if (i==0)
  {
    printf("Baumer: Could not move log file(s)");
    return 0;
  }
  
  return 1;
  
}

void baumer_send(char *msg)
{
  //printf("Sending msg to baumer: %s", msg);
  secureWrite(fd,msg,strlen(msg));
}



/************************** XML Initialization **************************/
///Struct for shared parse data
typedef struct  {
    int depth;
    char skip;
    char enable;
    char found;
  }parseInfo;

//Parsing functions
void XMLCALL insStartTag(void *, const char *, const char **);
void XMLCALL insEndTag(void *, const char *);

/** \brief Initialize the Baumer
 *
 * Reads the XML file and sets up the INS settings
 * 
 * Finally the rx threads is started and the driver 
 * is ready to read data
 * 
 * \param[in] *char filename
 * Filename of the XML file
 * 
 * \returns int status
 * Status of the initialization process. Negative on error.
 */
int initXML(char *filename) {

  parseInfo xmlParse; 
  char *xmlBuf = NULL;
  int xmlFilelength;
  int done = 0;
  int len;
  FILE *fp;

  //Print initialization message
  //Find revision number from SVN Revision
  char *i,versionString[20] = REVISION, tempString[10];
  i = strrchr(versionString,'$');
  strncpy(tempString,versionString+6,(i-versionString-6));
  tempString[(i-versionString-6)] = 0;
  printf("   Baumer: Initializing Serial Baumer %s\n",BAUMERVERSION);


   /* Initialize Expat parser*/
   XML_Parser parser = XML_ParserCreate(NULL);
   if (! parser) {
    fprintf(stderr, "   Baumer: Couldn't allocate memory for XML parser\n");
    return -1;
   }

   //Setup element handlers
   XML_SetElementHandler(parser, insStartTag, insEndTag);
   //Setup shared data
   memset(&xmlParse,0,sizeof(parseInfo));
   XML_SetUserData(parser,&xmlParse);

  //Open and read the XML file
  fp = fopen(filename,"r");
  if(fp == NULL)
  {
    printf("   Baumer: Error reading: %s\n",filename);
    return -1;
  }
  //Get the length of the file
	fseek(fp,0,SEEK_END);
	xmlFilelength = ftell(fp); //Get position
	fseek(fp,0,SEEK_SET); //Return to start of file

	//Allocate text buffer
	xmlBuf = realloc(xmlBuf,xmlFilelength+10); //Allocate memory
	if (xmlBuf == NULL) {
		fprintf(stderr, "   Couldn't allocate memory for XML File buffer\n");
		return -1;
	}
	memset(xmlBuf,0,xmlFilelength);
  len = fread(xmlBuf, 1, xmlFilelength, fp);
  fclose(fp);

  //Start parsing the XML file
  if (XML_Parse(parser, xmlBuf, len, done) == XML_STATUS_ERROR) {
    fprintf(stderr, "Baumer: XML Parse error at line %d: %s\n",
            (int)XML_GetCurrentLineNumber(parser),
            XML_ErrorString(XML_GetErrorCode(parser)));
    return -1;
  }
  XML_ParserFree(parser);
	free(xmlBuf);

	//Print error, if no XML tag found
	if (xmlParse.found <= 0) {
		printf("   Error: No <baumer> XML tag found in plugins section\n");
		return -1;
	}
  printf("   Baumer: XML enable: %i\r\n", xmlParse.enable);
  //Start crossbow thread after init
  if (xmlParse.enable) done = initINS();
  printf("   Baumer: XML done: %i\r\n", done);

 return done;
}

void XMLCALL
insStartTag(void *data, const char *el, const char **attr)
{
  int i;
  parseInfo *info = (parseInfo *) data;
  info->depth++;

  //Check for the right 1., 2. and 3. level tags
  if (!info->skip) {
    if (((info->depth == 1) && (strcmp("rhd",el) != 0)) ||
        ((info->depth == 2) && (strcmp("plugins",el) != 0)) ||
 				((info->depth == 3) && (strcmp("baumer",el) != 0))) {
      info->skip = info->depth;
      return;
    } else if (info->depth == 3) info->found = 1;
  } else return;

  //Branch to parse the elements of the XML file.
  if (!strcmp("baumer",el)) {
    //Check for the correct depth for this tag
    for(i = 0; attr[i]; i+=2) if ((strcmp("enable",attr[i]) == 0) && (strcmp("true",attr[i+1]) == 0)) {
      info->enable = 1; 
    }
    if (!info->enable) {
      printf("   Baumer: Use of Baumer disabled in configuration\n"); 
      info->skip = info->depth;
    }
  } else if (strcmp("serial",el) == 0) {
    //Check for the correct depth for this tag
    if(info->depth != 4) {
      printf("Error: Wrong depth for the %s tag\n",el);
    }
    for(i = 0; attr[i]; i+=2) if (strcmp("port",attr[i]) == 0) strncpy(insDevStringDecl,attr[i+1],63); 
    for(i = 0; attr[i]; i+=2) if (strcmp("baudrate",attr[i]) == 0) baudrate = atoi(attr[i+1]); 
    printf("   Baumer: Serial port(s) '%s' at %d baud\n", insDevStringDecl, baudrate);
  }
}

void XMLCALL
insEndTag(void *data, const char *el)
{
  parseInfo *info = (parseInfo *) data;
  info->depth--;

  if (info->depth < info->skip) info->skip = 0;
}


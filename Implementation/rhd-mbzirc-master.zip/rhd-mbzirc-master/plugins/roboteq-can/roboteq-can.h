/** \file roboteq-can.h
 *  \ingroup hwmodule
 *  \brief RoboteQ mdc2460 brushed DC Motor Controller CANOpen Interface 
 *
 */

#ifndef ROBOTEQ_CAN_DOT_H
#define ROBOTEQ_CAN_DOT_H

#define RTQSTRSIZE 64

/* \brief Read settings from XML-configuration file
 */
int initXML(char *);
extern int periodic(int);
extern int terminate(void);

#endif

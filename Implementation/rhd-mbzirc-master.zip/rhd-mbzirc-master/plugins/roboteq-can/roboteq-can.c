/** \file roboteq-can.c
 *  \ingroup hwmodule
 *  \brief RoboteQ mdc2460 brushed DC Motor Controller CANOpen Interface 
 *
 * This plugin is a test for running a CANOpen networks of RoboteQ motorcontrollers.
 *
 * Open can interface with: sudo ip link set up can0 type can bitrate 250000
 *
 * It is designed for the AUT TerrainHopper autonomous vehicle.
 * 
 * Modified to new steering 10 may 2019 / jca
 * Now all 3 ROBOTEQ units run in open loop PWN (velocity) control
 * All controllers are configured with current limit, so that 
 * if limit is exceeded, then it shuts down the motor, 
 * until 0 or reverse direction is commanded.
 * Back wheels controller MDC2460 (dual driver)
 * Driver firmware version 1.8 (as of may 2019)
 * - can ID 1 (Bitrate 250k) autostart
 * - current limit 40A
 * - current trigger shutdown at 20A after 1 second (both motors)
 * - acceleration limit 100% after 1000/20000 second (1/20 second)
 * - open loop mode
 *
 * Front wheels controller MDC2460 (dual driver)
 * Driver firmware version 1.8 (as of may 2019)
 * - can ID 2 (Bitrate 250k) autostart
 * - current limit 40A
 * - current trigger shutdown at 20A after 1 second (both motors)
 * - acceleration limit 100% after 1000/20000 second (1/20 second)
 * - open loop mode
 * 
 * Steering MDC1460 (single motor driver 60V 60A)
 * Driver firmware version 1.8 (as of may 2019)
 * - can ID 3 (Bitrate 250k) autostart
 * - current limit 25A
 * - current trigger shutdown at 12A after 1 second
 * - acceleration limit 100% after 1000/4000 second (1/4 second)
 * - open loop mode
 */
/***************************** Plugin version info *****************************/
#define ID               "$Id:  $"
#define ROBOTEQ_CAN_VERSION 	      "3.00"
/***************************************************************************/

#include <stdlib.h>
#include <stdio.h>

//serial com
#include <fcntl.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <net/if.h>
#include <pthread.h>
#include <string.h>
#include <linux/serial.h>
#include <expat.h>
#include <unistd.h>
# include <errno.h>
#include <math.h>

//RHD Core headers
#include <rhd.h>
#include <database.h>
#include <globalfunc.h>

//Socket CAN headers
#include <linux/can.h>
#include <linux/can/raw.h>

//Plugin Header
#include "roboteq-can.h"

// debug for code viewer
//#include </home/jca/mobotware/rhd/trunk/include/rhd.h>
// debug end

//Debugging flag - Enables printout
#define DEBUG 0					//!<Set to 1 to enable debug printout.
#define PLUGINNAME "roboteq-can: "

/******** Global Variables *************/
static volatile char roboteqcanRunning[2] = {0,0};	//!< used to check if the thread is running or not

int cmdspeedref = 0;
int cmdspeedrefupdated = 0;
int cmdsteeringangleref = 0;
int cmdsteeringanglerefupdated = 0;

int tmpfeedback = 0;

/******** RHD Variables *************/
int ispeedref;
int isteeringangleref;
int isteeringfeedback;
int steeringRef; // as received from MRC or joystick
/** debug steering */
int steerGainR; // actual setting
int steerGainW; // change setting temp change
int steerE;
int steerU;
int roboteq_ref;

//int iencl, iencr;

/******** CAN Variables *************/
int cansock;
struct sockaddr_can addr;
struct can_frame fr, rxfr;
struct ifreq ifr; // defined in net/if.h
char ifname[64];

int debug = 0;
FILE *logfs = NULL;
FILE * logDiff = NULL;
int lineCnt = 0, lineCnt2 = 0;;
int errorcnt = 0;
int lastOK = 0;  // error count when a message was send OK

/** encoder interface and steering */
int r_enc = -1; // index to read symbol table to get steering encoder value
int r_enc_magnet = -1; // index to read symbol table to get steering encoder valid
int r_steer_angle = -1; // index to steer angle read variable
int r_steer_OK = -1; // index to steer OK flag
int batteryVoltage = -1; // index to battery voltage
int imotorAmps = -1; // index to motor current
int motorAmps[5] = {0}; // measured current (Amps*10)

int steer_angle = 0;   // steer value signed value 0 is forward - degrees * 10
int steer_OK = 0;
int r_enc_valid = 0;   // is encoder reading valid
int sampleTimeus = 10000; // set from rhdconfig
float sampleTime = 0.01;
float steer_PE = 0; // old value of steer
float steer_I  = 0; // old value of integrator
int steerULimit = 700; // max control value for roboteq controller (handles up to +/- 1000)
int steerIdle = 0;     // count to see if steering is active
float steer_gain[3] = {12.0, 0.01/0.86, 0.0}; // gain in steer P-controller
float steer_angle_min = -20.0; // min angle in degrees (set in rhdconfig)
float steer_angle_max =  20.0; // max angle in degrees (set in rhdconfig)
int steer_vel = 0; // steer value send to steer motor
int steer_vel_updated = 0;
int iCanActive = -1; // index to RHD can active variable
int canActive[3] = {0,0,0}; // can active
//Function Prototype
int init_roboteqcan(void);
int shutdown_roboteqcan(void);

void *roboteqcan_task_read(void *);
void *roboteqcan_task_write(void *);

void sendspeed(int node, int channel, int speed);
int readfeedback(int node, int *res);
void askForMotorCurrent(int node, int motor);
void askForBatteryVoltage(int node);


// Threads are being defined
pthread_t roboteqcan_thread;			//!<Main thread for plugin
pthread_attr_t attr;			//!<??

/** \brief Get index to encoder values from read-table 
 * */
int getSteeringMeasurementRef()
{
  int err = 0;
  symTableElement *rtab = getSymtable('r');
  int rtSize = getSymtableSize('r');
  int i;
  
  // debug
  printf(PLUGINNAME "found %d read symbol:\n", rtSize);
  // debug end
  
  for(i = 0; i < rtSize; i++) {
    // debug
    printf(PLUGINNAME "symbol %d is (len %d) '%s'\n", i, (int)strlen(rtab[i].name), rtab[i].name);
    // debug end
    if (strcmp("rear_enc",rtab[i].name) == 0) 
    {
      r_enc = i;
    } 
    else if (strcmp("rear_magnet",rtab[i].name) == 0) 
    {
      r_enc_magnet = i;
    } 
    else if (strcmp("steeringangle",rtab[i].name) == 0) 
    {
      r_steer_angle = i;
    }
    else if (strcmp("steerok",rtab[i].name) == 0) 
    {
      r_steer_OK = i;
    }
  } 
  if (r_steer_OK < 0 || r_steer_angle < 0 || r_enc_magnet < 0 || r_enc < 0)
    err = 1;
  return err;
}

/** \brief Initialize RoboteQ-CAN plugin, settings and communication
 *
 * The com-ports are opened, the echo from the RoboteQ-CAN stopped, variables in rhd is initialized and the thread is started.
 *
 * \returns int status
 * Status of the server thread - negative on error.
 */
int init_roboteqcan(void)
{
  int flags;
  char fsname[64];
  struct timeval tv;
  int err;
  
  printf(PLUGINNAME "init start\n");
  //*************Left controller************************//
  
  if((cansock = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) 
  {
    perror(PLUGINNAME "Error while opening socket");
    return -1;
  }
  
  strcpy(ifr.ifr_name, ifname);
  ioctl(cansock, SIOCGIFINDEX, &ifr);
  
  addr.can_family  = AF_CAN;
  addr.can_ifindex = ifr.ifr_ifindex;

  printf(PLUGINNAME "%s at index %d\n", ifname, ifr.ifr_ifindex);
  
  flags = fcntl(cansock, F_GETFL, 0);
      fcntl(cansock, F_SETFL, flags | O_NONBLOCK);
  
  if(bind(cansock, (struct sockaddr *) &addr, sizeof(addr)) < 0) 
  {
    perror(PLUGINNAME "Error in socket bind");
    return -1;
  }	

  /****** Create database variables if all is ok **************/
  steerGainR = createVariable('r', 3, "steerGain");
  steerGainW = createVariable('w', 1, "steerGain");
  ispeedref  = createVariable('w', 1, "speedref");
  batteryVoltage = createVariable('r', 1, "batteryvolt");
    imotorAmps = createVariable('r', 5, "motorCurrent");
  iCanActive = createVariable('r', 3, "canIdActive");
  isteeringangleref = createVariable('w', 1, "steeringangleref");
  isteeringfeedback = createVariable('r', 1, "steeringActual");
  steeringRef = createVariable('r', 1, "steeringRef");
  steerE = createVariable('r', 1, "steerE");
  steerU = createVariable('r', 1, "steerU");
  roboteq_ref = createVariable('r', 5, "roboteqRef");
  
  //iencr = createVariable('r', 1, "encr");
  //iencl = createVariable('r', 1, "encl");

  // Initialization and starting of threads
  pthread_attr_init(&attr);
  pthread_attr_setinheritsched(&attr, PTHREAD_INHERIT_SCHED);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
  
  if (debug)
  {
    gettimeofday(&tv, NULL);
    sprintf(fsname, "roboteq-can-%lf.log", tv.tv_sec + 1e-6 * tv.tv_usec);
    //logfs = fopen(fsname, "w");
    sprintf(fsname, "roboteq-soft_differential-%lf.log", tv.tv_sec + 1e-6 * tv.tv_usec);
    logDiff = fopen(fsname, "w");
  }
  //
  // start threads
  roboteqcanRunning[0] = 1;
  roboteqcanRunning[1] = 1;
  if(pthread_create(&roboteqcan_thread, &attr, roboteqcan_task_read, 0))
  {
      perror("RoboteQ-CAN: Can't start read thread");
      return -1;
  }
  if(pthread_create(&roboteqcan_thread, &attr, roboteqcan_task_write, 0))
  {
    perror("RoboteQ-CAN: Can't start write thread");
    return -1;
  }
  // get variable index for encoder readings and validity
  // returns 1 if needed variables are not found
  err = getSteeringMeasurementRef();
  if (err == 1)
    return -1;
  else
    return 1;
}

/** \brief Initialize Shut down server thread
 *
 * \returns int status
 * Status of the server thread - negative on error.
 */
int shutdown_roboteqcan(void) 
{
  roboteqcanRunning[0] = 0;
  roboteqcanRunning[1] = 0;
  while((roboteqcanRunning[0] == 0) && (roboteqcanRunning[1] == 0))
    usleep(1000);
  if(logfs != NULL)
    fclose(logfs);
  if(logDiff != NULL)
    fclose(logDiff);
  if(cansock >= 0)
  {
    close(cansock);
    cansock = -1;
  }
  return 1;
}

/** \brief RoboteQ-CAN thread.
 * 
 * The RoboteQ-CAN only runs very shortly for each speed command therefore the speed is sent to the RoboteQ-CAN in this thread every time the loop is running.
 * 
 */
void *roboteqcan_task_write(void *not_used) {
  #ifdef DEBUG
  printf("RoboteQ-CAN write Plugin thread Running\n");
  #endif

  int sleepTime = 500; // us
  int loop = 0;
  int velRef[4] = {0};
  while(roboteqcanRunning[0])
  {
    if(cmdspeedrefupdated)
    { // Send same speed to both motors of node 0x02 (front wheels)
      if (cmdsteeringangleref != 0)
      { // turning so velocity may be different
        float theta = (float)cmdsteeringangleref / 10.0 * M_PI / 180.0;
        float ttheta = tan(theta);
        const float baseFront = 0.55; // between king-pins
        const float frontExtra = 0.1; // extra to front wheel
        const float baseRear = 0.82;  // between rear wheels
        const float steerBase = 0.94; // between axles
        float v1 = cmdspeedref; // outer rear
        float sbtt = fabs(steerBase/ttheta);
        float br2 = baseRear/2.0;
        float bf2 = baseFront/2.0;
        float br2i = 1.0/(sbtt + br2);
        float v2 = v1 * (sbtt - br2) * br2i; // inner rear
        float v3 = v1 * (hypot(steerBase, sbtt + bf2) + frontExtra) * br2i; // outer front
        float v4 = v1 * (hypot(steerBase, sbtt - bf2) - frontExtra) * br2i; // inner front
        if (cmdsteeringangleref > 0)
        { // turning left - ref is rear right
          velRef[0] = (int)v1;
          velRef[1] = (int)v2;
          velRef[2] = (int)v4; // left and right is opposite on front
          velRef[3] = (int)v3;
        }
        else
        { // turning right - left rear is ref
          velRef[0] = (int)v2;
          velRef[1] = (int)v1;
          velRef[2] = (int)v3;
          velRef[3] = (int)v4;
        }
        if (logDiff != NULL)
        {
          struct timeval tv;
          if (lineCnt2 == 0)
          {
            fprintf(logDiff, "%% " PLUGINNAME "software differential - terrainhopper\n");
            fprintf(logDiff, "%% format:\n");
            fprintf(logDiff, "%% 1: timestamp\n");
            fprintf(logDiff, "%% 2: steering angle ref (degrees)\n");
            fprintf(logDiff, "%% 3: steering angle actual (degrees)\n");
            fprintf(logDiff, "%% 4: steering angle ref (rad)\n");
            fprintf(logDiff, "%% 5: v1 speedRef (rear outher)\n");
            fprintf(logDiff, "%% 6: sbtt\n");
            fprintf(logDiff, "%% 7..9: v2 (rear inner), v3 (front outher), v4 (front inner)\n");
          }
          lineCnt2++;
          gettimeofday(&tv, NULL);
          fprintf(logDiff, "%ld.%06ld %g %g %g  %g %g  %g %g %g\n", tv.tv_sec, tv.tv_usec, 
                  cmdsteeringangleref/10.0, steer_angle/10.0, theta,
                  v1, sbtt, v2, v3, v4
          );
        }
        
      }
      else
      { // going straight same power (PWM) to all
        int i;
        for (i = 0; i < 4; i++)
          velRef[i] = cmdspeedref;
      }
      sendspeed(0x01, 0x01, -velRef[0]); // rear right
      sendspeed(0x01, 0x02, -velRef[1]); // rear left          
      sendspeed(0x02, 0x01, -velRef[2]); // front left
      sendspeed(0x02, 0x02, -velRef[3]); // front right
      cmdspeedrefupdated = 0;
    }
    // mostly debug - value send to roboteq controller
    // forward drive is positive command value (in RHD)
    setVariable(roboteq_ref, 0, -velRef[0]);
    setVariable(roboteq_ref, 1, -velRef[1]);
    setVariable(roboteq_ref, 2, -velRef[2]);
    setVariable(roboteq_ref, 3, -velRef[3]);
    
    if(steer_vel_updated)
    { // send 
      sendspeed(0x03, 0x01, steer_vel);
      steer_vel_updated = 0;
    }
    // mostly debug - value send to roboteq controller
    setVariable(roboteq_ref, 4, steer_vel);
    // ask for status from motor controllers
    switch (loop % 100)
    {
      case 0:  askForBatteryVoltage(0x01);  break;
      case 3:  askForMotorCurrent(0x01, 1); break; // rear right
      case 23: askForMotorCurrent(0x01, 2); break; // rear left
      case 43: askForMotorCurrent(0x02, 1); break; // front left
      case 63: askForMotorCurrent(0x02, 2); break; // front right
      case 83: askForMotorCurrent(0x03, 1); break; // steer motor
      default:   break;
    }
    //sleep so the loop is not using all the calculation power
    usleep(sleepTime);
    loop++;
  }

  if(cansock >= 0)
  {
    close(cansock);
  }
  
  fprintf(stderr,PLUGINNAME "Shutdown RoboteQ-CAN write task\n");
  roboteqcanRunning[0] = -1;
  pthread_exit(0);
}

/////////////////////////////////////////////////////

void *roboteqcan_task_read(void *not_used) 
{ // always have a read waiting
  #ifdef DEBUG
  printf(PLUGINNAME "read Plugin thread Running\n");
  #endif
  
  int sleepTime = 500; // us
  int loop = 0;
  int ret;
  while(roboteqcanRunning[1])
  {
    ret = read(cansock, &rxfr, sizeof(struct can_frame));
    if (ret > 0) 
    { // analyze the reply
      int canid = rxfr.can_id & 0x07;
      if (canid > 0 && canid <= 3)
        canActive[canid - 1]++;
      // combine result
      int value = (rxfr.data[4]) | (0xFF00 & (rxfr.data[5] << 8));
      if(value > 32768)
        // convert to signed 16 bit
        value = value - 0xFFFF;
      if (rxfr.data[1] == 0x0D && rxfr.data[2] == 0x21 && rxfr.data[3] == 0x02)
      { // is this a current reply
        // battery voltage (*10)
        setVariable(batteryVoltage, 0, value);
//         printf("#roboteq (ID:%x) Voltage %x, data: %x %x %x %x %x %x\n", 
//                canid, value, 
//                rxfr.data[0], rxfr.data[1], 
//                rxfr.data[2], rxfr.data[3], 
//                rxfr.data[4], rxfr.data[5]);    
      }
      else if (rxfr.data[1] == 0x00 && rxfr.data[2] == 0x21)
      { // current measurement
        // get motor number
        int m = rxfr.data[3];
        // combine
        value = (rxfr.data[4]) | (0xFF00 & (rxfr.data[5] << 8));
        if(value > 32768)
          // convert to signed 16 bit
          value = value - 0xFFFF;
        // is this a current reply
        // get motor index
        int ma = (canid - 1) * 2 + m - 1;
        if (ma >= 0 && ma < 6)
        { // set so that forward drive match with positive current
          if (ma == 5)
            // steering
            setVariable( imotorAmps, ma, value);
          else
            setVariable( imotorAmps, ma, -value);
          motorAmps[ma] = value;
        }
        // debug
//         printf("#roboteq (ID:%x) m=%d current %x, data: %x %x %x %x %x %x\n", 
//                 canid, m, value, 
//                 rxfr.data[0], rxfr.data[1], 
//                 rxfr.data[2], rxfr.data[3], 
//                 rxfr.data[4], rxfr.data[5]);
      }
//       else
//       { // message ignored 
//         // probably feedback from speed setting changed
//         printf("#roboteq (ID:%x) other data: %x %x %x %x %x %x\n", 
//                canid,  
//                rxfr.data[0], rxfr.data[1], 
//                rxfr.data[2], rxfr.data[3], 
//                rxfr.data[4], rxfr.data[5]);
//       }
    }
    //sleep so the loop is not using all the calculation power
    usleep(sleepTime);
    loop++;
  }
  fprintf(stderr,PLUGINNAME "Shutdown RoboteQ-CAN read task\n");
  roboteqcanRunning[1] = -1;
  pthread_exit(0);
}


/** \brief is called form the rhd every sample
 * 
 *  Reads the values that is written to the plugin variables.
 * 
 * 
 * */
extern int periodic(int tick)
{
    // Check if variables are updated
    if(isUpdated('w', ispeedref))
    {
      cmdspeedref = getWriteVariable(ispeedref, 0);
      cmdspeedrefupdated = 1;
    }

    if(isUpdated('w', isteeringangleref))
    {
      cmdsteeringangleref = getWriteVariable(isteeringangleref, 0); // degrees*10
      cmdsteeringanglerefupdated = 1;
    }
    // idle detect 
    if (cmdsteeringangleref == 0)
      steerIdle ++;
    else
      steerIdle = 0;
    // get steering measurements
    // - get symbol table pointer 
    symTableElement *st = getSymtable('r');
    // steering encoder is number 3 in this array 1=valid
    r_enc_valid = st[r_enc_magnet].data[2];
    steer_angle = st[r_steer_angle].data[0]; // degree * 10
    steer_OK = st[r_steer_OK].data[0]; // steer angle is available
    // Read feedback from steering servo (mostly debug)
    setVariable(isteeringfeedback, 0, steer_angle );
    // do closed loop control
    if (1)
    { // steering angle error in degrees
      // limits are in degrees (from rhdconfig)
      // steer value left is positive
      struct timeval tv;
      float e, eKp;
      if (cmdsteeringangleref > steer_angle_max * 10)
        cmdsteeringangleref = steer_angle_max * 10;
      else if (cmdsteeringangleref < steer_angle_min * 10)
        cmdsteeringangleref = steer_angle_min * 10;
      setVariable(steeringRef, 0, cmdsteeringangleref );
      // control error (in degrees)
      e = (float)(cmdsteeringangleref - steer_angle )/10.0;
      // do control action
      eKp = e * steer_gain[0];
      // Lag term
      // b = 0.2 (pole frequency times zero frequency)
      // td = 0.86 (from rhdconfig   tauI)
      // T = 0.01  (sampletime)
      // u_1 = old u
      // e_1 = old e
      // u = 1/(b*T + 2*td) * (u_1 * (-b*T + 2*td) + e * (T + 2*td) + e_1 * (T - 2*td))
      const float b = 0.3;
      float u0 = 1 / (b * sampleTime + 2 * steer_gain[1]) * 
          ( // Lag filter to reduce static error
            steer_I * (2*steer_gain[1] - b * sampleTime) + 
            eKp * (sampleTime + 2 * steer_gain[1]) +
            steer_PE * (sampleTime - 2 * steer_gain[1])
          );
      // save old error value
      steer_PE = eKp;
      // trunk to int
      int u = (int)u0;
      // test for roboteq limits (saturation)
      if (steerIdle > 100)
      { // idle steer motor
        steer_I = eKp;
        u = 0;
      }
      else
      {
        if (u > steerULimit)
          u = steerULimit;
        else if (u < -steerULimit)
          u = -steerULimit;
        else
          // save old output, if not in saturation
          steer_I = u0;
      }
      // implement as new motor drive PWM        
      // positive motor value gives steer to the right
      if (steer_OK)
        // control loop is active
        steer_vel = -u;
      else
        // control loop is open - no steering, set steer speed to 0.
        steer_vel = 0;
      steer_vel_updated = 1;
      // set debug variables
      setVariable(steerE, 0, (int)(e*10));
      setVariable(steerU, 0, u);
      if (logfs != NULL)
      {
        if (lineCnt == 0)
        {
          fprintf(logfs, "%% " PLUGINNAME "steering log - terrainhopper\n");
          fprintf(logfs, "%% format:\n");
          fprintf(logfs, "%% 1: timestamp\n");
          fprintf(logfs, "%% 2: steering angle ref (degrees)\n");
          fprintf(logfs, "%% 3: actual steering angle (deg)\n");
          fprintf(logfs, "%% 4: e = r - m\n");
          fprintf(logfs, "%% 5: steer motor control value (+/-1000)\n");
          fprintf(logfs, "%% 6: main motor command\n");
          fprintf(logfs, "%% 7-11: motor current 7,8=front, 9,10=rear, 11=steer\n");
        }
        lineCnt++;
        gettimeofday(&tv, NULL);
        fprintf(logfs, "%ld.%06ld %g %g %g %d %d  %f %f %f %f %f\n", tv.tv_sec, tv.tv_usec, 
                cmdsteeringangleref/10.0, steer_angle/10.0, e, u, 
                cmdspeedref,
                motorAmps[0]/10.0, motorAmps[1]/10.0, motorAmps[2]/10.0,
                motorAmps[3]/10.0, motorAmps[4]/10.0
               );
      }
    }
    // Check if variables for steer controller is updated
    if(isUpdated('w', steerGainW))
    { // copy back to read variable
      steer_gain[0] = getWriteVariable(steerGainW, 0)/10.0;
    }
    // always tell PID parameters
    setVariable(steerGainR, 0, steer_gain[0] * 10);   // Kp
    setVariable(steerGainR, 1, steer_gain[1] * 1000); // tau_I
    setVariable(steerGainR, 2, steer_gain[2] * 1000); // tau_D (not used)
    //
    // can active variables
    int i;
    for (i = 0; i < 3; i++)
      setVariable(iCanActive, i, canActive[i]);    
    //
    return 1;
}

/**
 * Do actual CAN communication */

void sendspeed(int node, int channel, int speed)
{
  int len;
//   struct timeval tv;
//  int ew = 0;
//  int er = 0;
  
  // Build CAN frame
  fr.can_id = 0x600 + node;
  fr.can_dlc = 8;
  fr.data[0] = 0x20;  // Specifier: 0x20 = "command" / 0x40 = "query"
  fr.data[1] = 0x00;  // LSB of object dictionary index
  fr.data[2] = 0x20;  // MSB of object dictionary index, 0x2000 = "GO cmd"
  fr.data[3] = channel;
  fr.data[4] = (0xFF & speed);
  fr.data[5] = (0xFF00 & speed) >> 8;
  fr.data[6] = 0x00;
  fr.data[7] = 0x00;
  
  # ifdef DEBUG
  //printf("can_id: 0x%04X\n", fr.can_id);
  //printf("can_dlc = %d\n", fr.can_dlc);
  //printf("can_data0 = 0x%02X\n", fr.data[0]);
  //printf("can_data1 = 0x%02X\n", fr.data[1]);
  //printf("can_data2 = 0x%02X\n", fr.data[2]);
  //printf("can_data3 = 0x%02X\n", fr.data[3]);
  //printf("can_data4 = 0x%02X\n", fr.data[4]);
  //printf("can_data5 = 0x%02X\n", fr.data[5]);
  # endif
  
  len = write(cansock, &fr, sizeof(struct can_frame));

  if(len < 0)
  {
    //printf("Write ERROR: %s\n" , strerror(errno));
    //ew = errno;
    errorcnt++;
    if (errorcnt > lastOK && (errorcnt - lastOK) < 200)
      perror(PLUGINNAME "Canbus send speed");
  }
  else
    lastOK = errorcnt;
  
  # ifdef DEBUG
  //printf("Wrote %d bytes to %s\n", len, ifname);
  # endif
    
//   ret = read(cansock, &rxfr, sizeof(struct can_frame));
//   if(ret < 0)
//   {
//     //printf("No response (node = %d, channel = %d, cmd = %d)\n", node, channel, speed);
//     //printf("Read ERROR: %s\n" , strerror(errno));
//     //er = errno;
//     errorcnt++;
//   }
  /*
  else
  {
    printf("Read ID : 0x%02X\n", rxfr.can_id);
  	  
    for(j = 0; j < rxfr.can_dlc; j++)
      printf("Read %d : 0x%02X\n", j, rxfr.data[j]);
  }
  */
  
//   if((logfs != NULL) && (ret < 0 || len < 0))
//   {
//     gettimeofday(&tv, NULL);
//     fprintf(logfs, "%lf %d %d %d %d %d\n", tv.tv_sec + 1e-6 * tv.tv_usec, len, ew, ret, er, errorcnt);
//   }
}


int readfeedback(int node, int *res)
{
  int len, ret;
  
  // Build CAN frame
  fr.can_id = 0x600 + node;
  fr.can_dlc = 8;
  fr.data[0] = 0x48;  // Specifier: 0x20 = "command" / 0x4x = "query"
  fr.data[1] = 0x10;  // LSB of object dictionary index
  fr.data[2] = 0x21;  // MSB of object dictionary index, 0x2110 = "read feedback"
  fr.data[3] = 0x01;  // Return in mm ??
  fr.data[4] = 0x00;
  fr.data[5] = 0x00;
  fr.data[6] = 0x00;
  fr.data[7] = 0x00;
  
  len = write(cansock, &fr, sizeof(struct can_frame));
  if (len < 0)
    perror(PLUGINNAME "error:");
  ret = read(cansock, &rxfr, sizeof(struct can_frame));
  if(ret > 0 && rxfr.can_id == 0x583 && rxfr.data[1] == 0x10 && rxfr.data[2] == 0x21)
  {
    *res = (rxfr.data[4]) | (0xFF00 & (rxfr.data[5] << 8));
    if(*res > 32768)
      *res = *res - 0xFFFF;
    
    /*
    printf("can_data0 = 0x%02X\n", rxfr.data[0]);
    printf("can_data1 = 0x%02X\n", rxfr.data[1]);
    printf("can_data2 = 0x%02X\n", rxfr.data[2]);
    printf("can_data3 = 0x%02X\n", rxfr.data[3]);
    printf("can_data4 = 0x%02X\n", rxfr.data[4]);
    printf("can_data5 = 0x%02X\n", rxfr.data[5]);
    printf("can_data6 = 0x%02X\n", rxfr.data[6]);
    printf("can_data7 = 0x%02X\n", rxfr.data[7]);
    printf("result = %d\n", *res);
    */
    return(1);
  }
  else
    return(0);
}

/**
 * Read motor current 
 * \param node is the can bus node
 * \param motor is motor driver to browse (1 or 2)
 * sets RHD variable as appropriate */
void askForMotorCurrent(int node, int motor)
{
  int len;
  // Build CAN frame
  fr.can_id = 0x600 + node;
  fr.can_dlc = 8;
  fr.data[0] = 0x48;  // Specifier: 0x20 = "command" / 0x4x = "query"
  fr.data[1] = 0x00;  // LSB of object dictionary index
  fr.data[2] = 0x21;  // MSB of object dictionary index, 0x2110 = "read feedback"
  fr.data[3] = motor;  // Return for motor 1 or 2?
  fr.data[4] = 0x00;
  fr.data[5] = 0x00;
  fr.data[6] = 0x00;
  fr.data[7] = 0x00;
  
  len = write(cansock, &fr, sizeof(struct can_frame));
  if (len < 0)
  {
    errorcnt++;
    if (errorcnt > lastOK && (errorcnt - lastOK) < 100)
      perror(PLUGINNAME "err:");
  }
  else
    lastOK = errorcnt;
//   ret = read(cansock, &rxfr, sizeof(struct can_frame));
//   if(ret > 0)
//   { // get can ID
//     int canid = rxfr.can_id & 0x07;
//     // get motor number
//     int m = rxfr.data[3];
//     // combine
//     value = (rxfr.data[4]) | (0xFF00 & (rxfr.data[5] << 8));
//     if(value > 32768)
//       // convert to signed 16 bit
//       value = value - 0xFFFF;
//     // is this a current reply
//     if (rxfr.data[1] == 0x00 && rxfr.data[2] == 0x21)
//     { // motor current
//       // get motor index
//       int ma = (canid - 1) * 2 + m - 1;
//       if (ma >= 0 && ma < 6)
//         setVariable(motorAmps, ma, value);
//     }
//     printf("#roboteq (ID:%x) m=%d current %x, data: %x %x %x %x %x %x\n", 
//            canid, m, value, 
//            rxfr.data[0], rxfr.data[1], 
//            rxfr.data[2], rxfr.data[3], 
//            rxfr.data[4], rxfr.data[5]);
//   }
}

/**
 * \param node is can bus ID (1 (front), 2 (rear) or 3 (steer))
 * sets RHD variable as appropriate */
void askForBatteryVoltage(int node)
{
  int len;
  // Build CAN frame
  fr.can_id = 0x600 + node;
  fr.can_dlc = 8;
  fr.data[0] = 0x48;  // Specifier: 0x20 = "command" / 0x4x = "query"
  fr.data[1] = 0x0D;  // LSB of object dictionary index
  fr.data[2] = 0x21;  // MSB of object dictionary index, 0x2110 = "read feedback"
  fr.data[3] = 0x02;  // Return 1=Vint?, 2=Battery, 3=5V 
  fr.data[4] = 0x00;
  fr.data[5] = 0x00;
  fr.data[6] = 0x00;
  fr.data[7] = 0x00;
  
  len = write(cansock, &fr, sizeof(struct can_frame));
  if (len < 0)
  {
    if (errorcnt > lastOK && (errorcnt - lastOK) < 100)
      perror(PLUGINNAME "errV:");
  }
  else
    lastOK = errorcnt;
//   ret = read(cansock, &rxfr, sizeof(struct can_frame));
//   if (ret > 0) 
//   {
//     int canid = rxfr.can_id & 0x07;
//     // combine result
//     int value = (rxfr.data[4]) | (0xFF00 & (rxfr.data[5] << 8));
//     if(value > 32768)
//       // convert to signed 16 bit
//       value = value - 0xFFFF;
//     // is this a current reply
//     if (rxfr.data[1] == 0x0D && rxfr.data[2] == 0x21 && rxfr.data[3] == 0x02)
//     { // battery voltage (*10)
//         setVariable(batteryVoltage, 0, value);
//     }
//     printf("#roboteq (ID:%x) Voltage %x, data: %x %x %x %x %x %x\n", 
//            canid, value, 
//            rxfr.data[0], rxfr.data[1], 
//            rxfr.data[2], rxfr.data[3], 
//            rxfr.data[4], rxfr.data[5]);    
//   }
}


extern int terminate()
{
  return(shutdown_roboteqcan());
}



/************************** XML Initialization **************************/
///Struct for shared parse data
typedef struct  
{
  int depth;
  char skip;
  char enable;
  char found;
} parseInfo;

//Parsing functions
void XMLCALL roboteqcanStartTag(void *, const char *, const char **);
void XMLCALL roboteqcanEndTag(void *, const char *);

/** \brief Initialize the RoboteQ-CAN with settings from configuration file.
 *
 * Reads the XML file and sets up the RoboteQ-CAN settings
 *
 * Finally the initialization of the RoboteQ-CAN plugin is started.
 *
 * \param[in] *char filename
 * Filename of the XML file
 *
 * \returns int status
 * Status of the initialization process. Negative on error.
 */
int initXML(char *filename) 
{
  parseInfo xmlParse;
  char *xmlBuf = NULL;
	int xmlFilelength;
  int done = 0;
  int len;
  FILE *fp;

  printf("RoboteQ-CAN: Initializing RoboteQ-CAN Motor Controller %s\n", ROBOTEQ_CAN_VERSION);


   /* Initialize Expat parser*/
   XML_Parser parser = XML_ParserCreate(NULL);
   if (! parser) {
    fprintf(stderr, "RoboteQ-CAN: Couldn't allocate memory for XML parser\n");
    return -1;
   }

   //Setup element handlers
   XML_SetElementHandler(parser, roboteqcanStartTag, roboteqcanEndTag);
   //Setup shared data
   memset(&xmlParse,0,sizeof(parseInfo));
   XML_SetUserData(parser,&xmlParse);

  //Open and read the XML file
  fp = fopen(filename,"r");
  if(fp == NULL)
  {
    printf("RoboteQ-CAN: Error reading: %s\n",filename);
    return -1;
  }
  //Get the length of the file
	fseek(fp,0,SEEK_END);
	xmlFilelength = ftell(fp); //Get position
	fseek(fp,0,SEEK_SET); //Return to start of file

	//Allocate text buffer
	xmlBuf = realloc(xmlBuf,xmlFilelength+10); //Allocate memory
	if (xmlBuf == NULL) {
		fprintf(stderr, "   Couldn't allocate memory for XML File buffer\n");
		return -1;
	}
	memset(xmlBuf,0,xmlFilelength);
  len = fread(xmlBuf, 1, xmlFilelength, fp);
  fclose(fp);

  //Start parsing the XML file
  if (XML_Parse(parser, xmlBuf, len, done) == XML_STATUS_ERROR) {
    fprintf(stderr, "RoboteQ-CAN: XML Parse error at line %d: %s\n",
            (int)XML_GetCurrentLineNumber(parser),
            XML_ErrorString(XML_GetErrorCode(parser)));
    return -1;
  }
  XML_ParserFree(parser);
  free(xmlBuf);

  //Print error, if no XML tag found
  if (xmlParse.found <= 0) {
    printf("   Error: No <roboteqcan> XML tag found in plugins section\n");
    return -1;
  }

  //Start roboteqcan thread after init
  printf("RoboteQ-CAN: starting thread\n");
  if (xmlParse.enable) 
    done = init_roboteqcan();
  printf("RoboteQ-CAN: init finished\n");
 return done;
}

void XMLCALL
roboteqcanStartTag(void *data, const char *el, const char **attr)
{
  int i;
  parseInfo *info = (parseInfo *) data;
  info->depth++;

  if (!info->skip) 
  {
    if (((info->depth == 1) && (strcmp("rhd",el) != 0)) ||
      ((info->depth == 2) && ((strcmp("plugins",el) != 0) && (strcmp("sheduler",el) != 0))) ||
      ((info->depth == 3) && ((strcmp("roboteqcan",el) != 0) && (strcmp("period",el) != 0)))) 
    { // not interesting
//       printf("roboteq skiping %s (depth%d)\n", el, info->depth);
      info->skip = info->depth;
      return;
    }
    else if (info->depth == 3) 
      info->found = 1;
    
  } 
  else 
    return;
  
//   printf("roboteq using %s (depth%d) (attr0=%s)\n", el, info->depth, attr[0]);
  
  if (strcmp("period",el) == 0) 
  { // this should be the scheduler sample time
    for(i = 0; attr[i]; i+=2) 
    { // get sample time for steer controller
      if (strcmp("value",attr[i]) == 0) 
      {
        sampleTimeus = strtof(attr[i+1], NULL);
        sampleTime = sampleTimeus * 1e-6;
        printf(PLUGINNAME " found sample time %dus = %f\n", sampleTimeus, sampleTime);
        break;
      }
    }
  }
    //Branch to parse the elements of the XML file.
  if (strcmp("roboteqcan",el) == 0) 
  {
    //Check for the correct depth for this tag
    for(i = 0; attr[i]; i+=2) if ((strcmp("enable",attr[i]) == 0) && (strcmp("true",attr[i+1]) == 0)) {
      info->enable = 1;
    }
    if (!info->enable) {
      printf("RoboteQ-CAN: Use of roboteqcan disabled in configuration\n");
      info->skip = info->depth;
    }
    for(i = 0; attr[i]; i+=2) 
    {
      if (strcmp("steerGain",attr[i]) == 0)  
      {
        steer_gain[0] = strtof(attr[i+1], NULL);
      }
      if (strcmp("steerTauI",attr[i]) == 0)  
      {
        steer_gain[1] = strtof(attr[i+1], NULL);
      }
      if (strcmp("steerTauD",attr[i]) == 0)  
      {
        steer_gain[2] = strtof(attr[i+1], NULL);
      }
      else if (strcmp("steerAngleMin",attr[i]) == 0)  
      {
        steer_angle_min = strtof(attr[i+1], NULL);
      }
      else if (strcmp("steerAngleMax",attr[i]) == 0)  
      {
        steer_angle_max = strtof(attr[i+1], NULL);
      }
      else if (strcmp("debug",attr[i]) == 0)  
      {
        debug = strtol(attr[i+1], NULL, 10);
      }
    }
  } 
  else if (strcmp("can",el) == 0) 
  {
    //Check for the correct depth for this tag
    if(info->depth != 4) 
    {
      printf("Error: Wrong depth for the %s tag\n",el);
    }
    for(i = 0; attr[i]; i+=2) 
      if (strcmp("device",attr[i]) == 0)
      {
        strncpy(ifname,attr[i+1],63);printf("RoboteQ-CAN: Device is %s \n",ifname);
      }
  }
  

}

void XMLCALL
roboteqcanEndTag(void *data, const char *el)
{
  parseInfo *info = (parseInfo *) data;
  info->depth--;

  if (info->depth < info->skip) info->skip = 0;
}	


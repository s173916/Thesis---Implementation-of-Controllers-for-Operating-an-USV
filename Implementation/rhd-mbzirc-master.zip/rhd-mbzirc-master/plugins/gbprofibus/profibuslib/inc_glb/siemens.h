/* SIMATIC NET-spezifische Definitionen */

#define SIN_COMPANY_NAME    "Siemens AG\0"
#define SIN_LEGALCOPYRIGHT  "Copyright � 1999\0"
#define SIN_LEGALTRADEMARKS "Siemens AG\0"
#define SIN_PRODUCT_STR     "SIMATIC NET Software\0"

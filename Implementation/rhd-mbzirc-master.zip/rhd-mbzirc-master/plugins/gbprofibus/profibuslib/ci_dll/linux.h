extern long cp5613_available(unsigned long *plxp,
			     unsigned long *dloadp,
			     unsigned long *dpramp);


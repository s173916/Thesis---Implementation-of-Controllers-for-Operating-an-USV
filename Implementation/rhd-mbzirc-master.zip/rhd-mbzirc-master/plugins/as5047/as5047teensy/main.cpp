/***************************************************************************
 *   Copyright (C) 2014 by DTU                             *
 *   jca@elektro.dtu.dk                                                    *
 *
 *   Main function for as5047 rotaty encoder interface to Terrain-Hopper
 *   on a small 72MHz ARM processor MK20DX256.
 *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/


#define REV_ID "$Id: main.cpp 1112 2019-08-19 13:37:28Z jcan $"  

#include <WProgram.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#include <usb_serial.h>
#include <core_pins.h>
#include <HardwareSerial.h>
#include <SPI.h>
#include <IntervalTimer.h>
#include <util/parity.h>
#include <time.h>
//

// heart beat timer
IntervalTimer hbTimer;
volatile uint32_t hbTimerCnt = 0; /// heart beat timer count (control_period)
volatile uint32_t hb10us = 0;     /// heart beat timer count (10 us)
// flag for start of new control period
volatile bool startNewRead = false;
/**
 * Heart beat interrupt service routine */
void hbIsr(void);
///
// AS5047 should be able to 10MHz, but 1MHz should be sufficient
// AS5045 can do 400 kHz only.
// the rest is from the as5047 data sheet
SPISettings as5047settings(1000000, MSBFIRST, SPI_MODE1);
SPISettings as5045settings(400000, MSBFIRST, SPI_MODE1);

typedef enum {ANGLEUNC, ANGLECOM, ERRFL, DIAAGC} ASregister;
//
// total sensor update /report rate
//const int readFrq = 120; // in Hz (push data on serial connection at this rate)
const int readFrq = 120; // in Hz (push data on serial connection at this rate)
const int cyclesPerRead = 6; // number of states per read 1 battery 5 x read encoder, 1 printout
const int READ_PERIOD_10us = 100000/readFrq/cyclesPerRead; 
int sendDropped = 0;
bool usb_send_str(const char * str, bool blocking = false);
//encoder count from A,B signals (2000 per revolution)
uint32_t encCCV[4] = {0,0,0,0};
uint32_t encoder[4] = {0,0,0,0};

// encoder is 14 bit, and used as mask
const int32_t fullRotation = 1 << 14;
// converted to encoder count with more that one rotation
const int32_t encoderOutMask = (1 << 16) - 1;

const int RX_BUF_SIZE = 100;
char usbRxBuf[RX_BUF_SIZE];
int usbRxBufCnt = 0;
bool getFreshData = false;
bool streamData = false;
///////////////////////////////

/** encoder A and B pins */
#define FRONT_LEFT_A 0
#define FRONT_LEFT_B 1

#define REAR_RIGHT_CS 9
#define REAR_LEFT_CS 15
#define STEER_CS 20
#define FRONT_LEFT_CS 21

#define BATT_SENSE_PIN 23
#define BATT_SENSE_A 9
#define STEER_POT_PIN 23
#define STEER_POT_A 5
#define EMERG_STOP_PIN 22
#define EMERG_STOP_A 8


/** encoder interrupt routine */
void encoderRearLeftA()
{ // encoder A change
  uint8_t  a = digitalRead(FRONT_LEFT_A);
  // read other channel for direction
  if (a == 0)
    encCCV[0] = digitalRead(FRONT_LEFT_B);
  else
    encCCV[0] = digitalRead(FRONT_LEFT_B) == 0;
  // count in the right direction
  if (encCCV[0])
    encoder[0]--;
  else
    encoder[0]++;
}

/** encoder interrupt routine */
void encoderRearLeftB()
{ // encoder A change
  uint8_t  a = digitalRead(FRONT_LEFT_A);
  // read other channel for direction
  if (a == 0)
    encCCV[0] = digitalRead(FRONT_LEFT_B);
  else
    encCCV[0] = digitalRead(FRONT_LEFT_B) == 0;
  // count in the right direction
  if (encCCV[0])
    encoder[0]--;
  else
    encoder[0]++;
}


void initialization()
{ // INITIALIZATION
  pinMode(LED_BUILTIN, OUTPUT);
  // init USB connection (parameter is not used - always 12MB/s
  Serial.begin(115200);  // USB
  // init motor control
  // set PWM resolution
  analogWriteResolution(12);
  analogReadResolution(12);
  // init AD converter - internal 1.2V reference voltage
  analogReference(INTERNAL1V2);
  // more pins
  pinMode(EMERG_STOP_PIN,INPUT); // emergency stop (A8)
  pinMode(BATT_SENSE_PIN,INPUT); // battery voltage (A9)
  pinMode(REAR_RIGHT_CS, OUTPUT); // chip select encoder 1
  pinMode(REAR_LEFT_CS, OUTPUT); // chip select encoder 2
  pinMode(STEER_CS, OUTPUT); // chip select steer encoder (as5045)
  pinMode(FRONT_LEFT_CS, OUTPUT); // chip select front left encoder
  //
  pinMode(A5,INPUT); // steering pot arm
  // start 10us timer (heartbeat timer)
  hbTimer.begin(hbIsr, (unsigned int)  10); // heartbeat timer, value in usec
  //
  // Initialization of MPU9150
  digitalWriteFast(LED_BUILTIN,1);  
  digitalWriteFast(LED_BUILTIN,0);

  // set SPI pins to use
  SPI.setMOSI(7);
  SPI.setMISO(8);
  SPI.setSCK(14); 
  // initialize SPI registers
  SPI.begin();
  
  // use interrupt to decode A and B signale
//   attachInterrupt(REAR_LEFT_A, encoderRearLeftA, CHANGE);
//   attachInterrupt(REAR_LEFT_B, encoderRearLeftB, CHANGE);
  
}



/**
 * Read this register from this chip 
 * \param CSn is the digital pin connected to chip enable on device
 * \param thisRegister is the command register send to the SPI device
 * \param bytesToRead is number of bytes to read 1 to 4
 * \returns an unsigned 32 bit value */

uint32_t readRegister(int CSn, uint16_t thisRegister, int bytesToRead ) {
  byte inByte = 0;   // incoming byte from the SPI
  uint32_t result = 0;   // result to return
  byte lowbyte = thisRegister & 0b0000000011111111;
  byte highbyte = (thisRegister >> 8);
  SPI.beginTransaction(as5047settings);
  digitalWrite(CSn, LOW);
  SPI.transfer(highbyte);
  result = SPI.transfer(lowbyte);
  digitalWrite(CSn, HIGH);
  delayMicroseconds(10);
  digitalWrite(CSn, LOW);
  bytesToRead--;
  while (bytesToRead-- > 0) {
    // shift the first byte MSB left, then get the second byte:
    result = result << 8;
    inByte = SPI.transfer(0x00);
    // combine the byte with the previous one:
    result = result | inByte;
  }
  // take the chip select high to de-select:
  digitalWrite(CSn, HIGH);
  // return the result:
  return(result);
}

/**
 * read one of the main as5047 registers
 * \param CSn chip enable pin on teensy
 * \param reg is enumerated value to read
 * \returns 16 bit register value */
uint16_t readEncoder(int CSn, ASregister reg)
{
//   uint16_t data_register = 0x3FFF;
//   uint16_t uncor_data_register = 0x3FFE;
//   uint16_t err_register = 0x0001;
//   uint16_t diag_register = 0x3FFC;
  uint16_t result = 0;
  // registers with precomputed parity
  uint16_t errfl_p = 0x4001;
  uint16_t angleunc_p = 0x7FFE;
  uint16_t anglecom_p = 0xFFFF;
  uint16_t diaagc_p = 0xFFFC;
  uint16_t mask_results = 0b0011111111111111; // this grabs the returned data without the read/write or parity bits.
  //
  switch (reg)
  {
    case ANGLEUNC:
      result = readRegister(CSn, anglecom_p, 3);
      break;
    case ANGLECOM:
      result = readRegister(CSn, angleunc_p, 3);
      break;
    case ERRFL:
      result = readRegister(CSn, errfl_p, 3);
      break;
    case DIAAGC:
      result = readRegister(CSn, diaagc_p, 3);
      break;
  }
  result = result & mask_results; //   and masking out the resulting parity and read/write bits
  return result;
}

int helpLine = -1;
void sendHelp()
{
  const int MHL = 22;
  const char * helptext[MHL] = {"Terrainhopper encoders\r\n",
                              "commands: \r\n", REV_ID "\r\n",
                              "  get      Get one measurement (stops streaming)\r\n",
                              "  stream   Start streaming\r\n",
                              "  stream=0 Stop streaming\r\n",
                              "  help     This message\r\n",
                              "Measurements\r\n",
                              " enc n1 n3 n4 n5 n6 n7 n8 n9 n10\r\n",
                              "     n1 = message serial\r\n",
                              "     n3 = Encoder 1 value (rear left)\r\n",
                              "     n4 = encoder 1 magnet distance - see AS5047 manual\r\n",
                              "     n5 = Encoder 2 value (rear right)\r\n",
                              "     n6 = encoder 2 magnet distance - see AS5047 manual\r\n",
                              "     n7 = Encoder 3 value (steering)\r\n",
                              "     n8 = encoder 3 OK (ocf & not cof & not lin - AS5045)\r\n",
                              "     n9 = Encoder 1 timing (in units of 10us)\r\n",
                              "     n10 = Encoder 2 timing (in units of 10us)\r\n",
                              "     n11 = debug value (length of last received cmd?)\r\n",
                              ""  };
  if (helpLine >= 0 and helpLine < MHL)
  {
    usb_send_str(helptext[helpLine], true);
  }
  helpLine++;
  if (helpLine >= MHL)
    helpLine = -1;
}


void receivedCharFromUSB(uint8_t n)
{ // got another character from usb host (command)
  if (n >= ' ')
  { // add character to buffer
    usbRxBuf[usbRxBufCnt] = n;
    if (usbRxBufCnt < RX_BUF_SIZE - 1)
      usbRxBuf[++usbRxBufCnt] = '\0';
    else
    {
      usbRxBufCnt = 0;
      usbRxBuf[usbRxBufCnt] = '\0';
    }
//     const int MSL = 30;
//     char s[MSL];
//     snprintf(s, MSL, "%c", n);
//     usb_send_str("# got char\n");
  }
  if (n == '\n')
  { // got command (if not overflow)
//     usb_send_str("# got new line\n");
    if (usbRxBufCnt > 0)
    {
      usbRxBuf[usbRxBufCnt] = '\0';
      if (strncmp(usbRxBuf, "get", 3) == 0)
      { // get data from sensor now
        getFreshData = true;
        streamData = false;
      }
      else if (strncmp(usbRxBuf, "stream", 6) == 0)
      { // get data from sensor now
        char * p1 = &usbRxBuf[6];
        int v = 1;
        if (*p1 >= ' ')
          v = strtol(p1, NULL, 10);
        streamData = (v == 1);
      }
      else if (usbRxBuf[0] == 'h')
      { // get data from sensor now
        helpLine++;
      }
    }
   
   // flush remaining input
    usbRxBufCnt = 0;
  }
}

int incomingChars = 0;
const int MDL = 100;
char dds[MDL];

void handleIncoming()
{
  int n = 0, m;
  // get number of available chars in USB buffer
    m = usb_serial_available();
    if (m > 20)
      // limit to no more than 20 chars in one 1ms cycle
      m = 20;
    // 
    if (m > 0)
    { // get characters
//       const int MSL = 100;
//       char s[MSL];
      for (int i = 0; i < m; i++)
      { // get pending characters
        n = usb_serial_getchar();
        if (n < 0)
          break;
        if (incomingChars < MDL)
          dds[incomingChars] = n; 
        incomingChars++;
        if (n == '\n' or (n >= ' ' and n < 0x80))
        { // there is data from USB, so it is active
          // command arriving from USB
          receivedCharFromUSB(n);
          break;
        }
      }
//       snprintf(s, MSL, "# got %d (0x%x), rxCnt=%d, '%s'\n", m, n, usbRxBufCnt, usbRxBuf);
//       usb_send_str(s);
    }
}


uint8_t emergSw = 0;
uint16_t batVoltInt;
uint16_t steering_value = 0;
// voltage divider using 27k and 1.2k, ref voltage 1.2V and max ADC is 14 bit
static const float batVoltIntToFloat = 1.2 / (1 << 12) * (27.0 + 1.2)/1.2;
float batVolt = 0;


void readPotentiometerAndVoltage()
{ // read pin values
  // potentiometer setting
  steering_value = analogRead(A5); // need to be balanced
  // battery voltage
  batVoltInt = analogRead(A9);
  batVolt = batVoltInt *  batVoltIntToFloat;
  // emergency switch
  emergSw = digitalReadFast(EMERG_STOP_PIN);
}


uint16_t s1pos = 0, s1diag;
uint16_t s2pos = 0, s2diag;
uint16_t s1posLast = 0;
uint16_t s2posLast = 0;
uint32_t enc1 = 0; // full encoder value (more than one rotation)
uint32_t enc2 = 0; 
uint32_t enc3 = 0; 
int s1Mag = -1;
int s2Mag = -1;
uint32_t e1t = 0, e2t = 0;


void readEncoder1()
{ //          timing1 = hb10us;
  //v1 = readEncoder(CS1, ANGLEUNC);
  s1pos = readEncoder(REAR_LEFT_CS, ANGLECOM);
  //v3 = readEncoder(CS1, ERRFL);
  s1diag = readEncoder(REAR_LEFT_CS, DIAAGC);
  s1Mag = s1diag & 0xff;
  //          t1 = hb10us - timing1;
  {
    int32_t difEnc = s1pos - s1posLast;
    s1posLast = s1pos;
    if (difEnc > (fullRotation / 2))
      // negative overflow - from low to high value
      enc1 += difEnc - fullRotation;
    else if (difEnc < -(fullRotation / 2))
      // positive overflow - from high to low value
      enc1 += difEnc + fullRotation;
    else
      // no overflow
      enc1 += difEnc;          
  }
  // limit number of bits
  enc1 &= encoderOutMask;
  e1t = hb10us;
}

void readEncoder2()
{
  s2pos = readEncoder(REAR_RIGHT_CS, ANGLECOM);
  s2diag = readEncoder(REAR_RIGHT_CS, DIAAGC);
  s2Mag = s2diag & 0xff;
  //          t2 = hb10us - timing1;
  {
    int32_t difEnc = s2pos - s2posLast;
    s2posLast = s2pos;
    if (difEnc > (fullRotation / 2))
      // negative overflow - from low to high value
      enc2 += difEnc - fullRotation;
    else if (difEnc < -(fullRotation / 2))
      // positive overflow - from high to low value
      enc2 += difEnc + fullRotation;
    else
      // no overflow
      enc2 += difEnc;          
  }
  // limit number of bits
  enc2 &= encoderOutMask;
  e2t = hb10us;
}


// steer debug
// bool mag_inc = 4;
// bool mag_dec = 5;
bool enc3_OK = 0;
// int ms = 0;
// int ms2;


void readSteerEncoder()
{
  bool ocf = 1;
  bool cof = 2;
  bool lin = 3;
  //
  //ms2 = hb10us / 100;
  SPI.beginTransaction(as5045settings);
  digitalWrite(STEER_CS, LOW);
  delayMicroseconds(25);
  uint8_t b0 = SPI.transfer(0x00);
  delayMicroseconds(3);
  uint8_t b1 = SPI.transfer(0x00);
  delayMicroseconds(3);
  uint8_t b2 = SPI.transfer(0x00);
  delayMicroseconds(5);
  digitalWrite(STEER_CS, HIGH);
  enc3 = (b0 << 4) + (b1 >> 4);
  ocf = (b1 & 0x08) != 0;
  cof = (b1 & 0x04) != 0;
  lin = (b1 & 0x02) != 0;
//   mag_inc = (b1 & 0x01) != 0;
//   mag_dec = (b2 & 0x80) != 0;
  enc3_OK = ocf and not cof and not lin;
  if (not enc3_OK)
  { // OK result should give:
    // ocf = 1 initialized OK
    // cof = 0 not overflow
    // min = 0 no liniarity error
    // min_inc = 0 no change (OK)
    // min_dec = 0 no change (OK)
    // for debug only
    const int MSL = 255;
    char s[MSL];
    snprintf(s, MSL, "# as5045 err: %02x %02x %02x = %6lu ocf %d cof %d lin %d\r\n",
             b0, b1, b2, enc3, ocf, cof, lin);
    usb_send_str(s, false);
  }
  //
  //            t1 = hb10us - timing1;
  // limit number of bits
}

int sendSerial = 0;
int msgLength = 0;

bool sendMeasurement()
{
  const int MSL = 150;
  char s[MSL];
  bool sendOK;
  //
  if (true)
  {
    snprintf(s, MSL, "enc %d %ld %d %ld %d %ld %d %lu %lu %d\r\n", 
            sendSerial % 100, 
             enc1, s1Mag, enc2, s2Mag, enc3, enc3_OK, e1t, e2t, incomingChars
    );
  }
  else
  {
    if (incomingChars < MDL)
      dds[incomingChars] = '\0';
    else
      dds[MDL - 1] = '\0';
    snprintf(s, MSL, "dds %d:%s", incomingChars, dds);
  }
  incomingChars = 0;
  sendOK = usb_send_str(s);
  if (not sendOK) 
    sendDropped++;
  msgLength = strlen(s);
  sendSerial++;    
  if (sendOK and sendDropped > 0)
  {
    snprintf(s, MSL, "# dropped %d msgs\n", sendDropped);
    sendOK = usb_send_str(s);
    if (sendOK)
      sendDropped = 0;
  }
  return sendOK;
}

// Basic command interpreter for controlling port pins
int main(void)
{
  uint16_t loop = 0;
  int sensorIdx = 0;
  // init communication and ports
  initialization();
  //
  usb_send_str("# 5047 encoder v2.2 . with 5045 steering\r\n");
  usb_send_str("# " REV_ID "\n");
  // main loop
  while (1)
  { // listen to commands from USB
    handleIncoming();
    // every ms startNewRead is set to true
    if (startNewRead)
    { // time to read sensors a status message
      startNewRead = false;
      if (streamData)
      { // read from a sensor every ms
        // and send result in last slot
        switch (sensorIdx)
        {
          case 0:
            readPotentiometerAndVoltage();
            break;
          case 1:
          case 4:
            readEncoder1();
            break;
          case 2:
          case 5:
            readEncoder2();
            break;
          case 3:
            readSteerEncoder();
            break;
          default:
            sendMeasurement();
            sensorIdx = -1;
            break;
        }
        sensorIdx++;
      }
      if (loop % 10 == 0 and helpLine >= 0)
        // send one line every 100ms
        sendHelp();
      // show that main loop is running (every second)
      if (loop % (readFrq * cyclesPerRead) == 0)
        digitalWrite(LED_BUILTIN, HIGH);
      if (loop % (readFrq * cyclesPerRead) == (readFrq * cyclesPerRead / 10))
      {
        // debug
        if (false)
        {
          const int MSL = 200;
          char s[MSL];
          snprintf(s, MSL, "# LED stm=%d, pll=%d, inc=%d, err=%d, len=%d\r\n", 
                   streamData, getFreshData, incomingChars, sendDropped, msgLength);
          usb_send_str(s);
        }
        // debug end
        digitalWrite(LED_BUILTIN, LOW);
        
      }
      loop++;
    }
    if (getFreshData)
    { // poll mode read all and send result
      getFreshData = false;
      readEncoder1();
      readEncoder2();
      readPotentiometerAndVoltage();
      readSteerEncoder();
      sendMeasurement();
    }
  }
}

/**
 * Heartbeat interrupt routine
 * schedules data collection and control loop timing.
 * */
void hbIsr(void)
{ // called every 10 microsecond
  // as basis for all timing
  hb10us++;
  if (hb10us % READ_PERIOD_10us  == 0)
  { // 1ms timing - main control period start
//     time += 1e-5 * CONTROL_PERIOD_10us; 
    hbTimerCnt++;
    startNewRead = true;
    //
  } 
}

bool usb_send_str(const char * str, bool blocking) //, bool toUSB, bool toWifi)
{
  int n = strlen(str);
  bool okSend = true;
  // this may give a timeout, and the rest is not send!
  // this happends especially often on lenovo PCs, but they are especially slow in data transfer.
  if (not blocking)
  { // surplus characters will be skipped
    unsigned int m = usb_serial_write_buffer_free();
    if (m > strlen(str))
    { // space in buffer to send (max 64 bytes)
      usb_serial_write(str, n);
    }
    else
    {
      okSend = false;
    }
  }
  else
  { // ensure all is send (like log data)
    int k = n, m;
    const char * p1 = str;
    // send as much as possible at a time
    while (k > 0 /*and usbWriteFullCnt < usbWriteFullLimit*/)
    {
      m = usb_serial_write_buffer_free();
      if (m > 0)
      {
        if (m > k)
          m = k;
        usb_serial_write(p1, m);
        k = k - m;
        if (k <= 0)
        {
          okSend = false;
          break;
        }
        p1 += m;
      }
    }
  }
  // serial connection (serial3) has the next number after wifi
  return okSend;
}


// boolean calc_even_parity(uint16_t inbyte) {
// //   uint16_t paritymask = 0b1000000000000000;
//   uint16_t datamask   = 0b0011111111111111;
//   uint16_t data = inbyte | datamask;
//   int x = 13;
//   boolean calculated_parity = 0;
//   while(x)
//     calculated_parity = calculated_parity ^ ( (data << (13-x)) >> x--); // this is stunningly opaque.
//     return calculated_parity;
// }
// 
// boolean check_parity (uint16_t inbyte) {    // not currently using this routine
//   uint16_t parity_bit_value = inbyte & 0b1000000000000000;
//   uint16_t data_value = inbyte | 0b0011111111111111;
//   if (calc_even_parity(data_value) == parity_bit_value)
//     return 0;
//   else
//     return 1;
// }
// 



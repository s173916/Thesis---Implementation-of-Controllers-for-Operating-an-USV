/** \file roboteq-irobot.c
 *  \ingroup hwmodule
 *  \brief RoboteQ mdc2460 brushed DC Motor Controller CANOpen Interface 
 *
 * This plugin is a test for running a CANOpen networks of RoboteQ motorcontrollers.
 *
 * Open can interface with: sudo ip link set up can0 type can bitrate 250000
 *
 * It is designed for the AUT IRobot ATRV-JR autonomous vehicle.
 */
/***************************** Plugin version  *****************************/
 #define ROBOTEQ_IROBOT_VERSION 	      "0.00"
/***************************************************************************/

#include <stdlib.h>
#include <stdio.h>

//serial com
#include <fcntl.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <net/if.h>
#include <pthread.h>
#include <string.h>
#include <linux/serial.h>
#include <expat.h>
#include <unistd.h>
# include <errno.h>

//RHD Core headers
#include <rhd.h>
#include <database.h>
#include <globalfunc.h>

//Socket CAN headers
#include <linux/can.h>
#include <linux/can/raw.h>

//Plugin Header
#include "roboteq-irobot.h"

//Debugging flag - Enables printout
#define DEBUG 0					//!<Set to 1 to enable debug printout.

/******** Global Variables *************/
static volatile char roboteqirobotRunning = 0;	//!< used to check if the thread is running or not

int cmdspeedl = 0;
int cmdspeedlupdated = 0;
int cmdspeedr = 0;
int cmdspeedrupdated = 0;

int tmpencl = 0;
int tmpencr = 0;

/******** RHD Variables *************/
int ispeedl;
int ispeedr;
int iencl;
int iencr;

/******** CAN Variables *************/
int cansock;
struct sockaddr_can addr;
struct can_frame fr, rxfr;
struct ifreq ifr;
char ifname[64];

FILE *logfs;
int errorcnt = 0;

//Function Prototype
int init_roboteqirobot(void);
int shutdown_roboteqirobot(void);

void *roboteqirobot_task(void *);
void *roboteqirobot_reader(void *);

void sendspeed(int node, int channel, int speed);
void readencoders(int node);

// Threads are being defined
pthread_t roboteqirobot_thread, roboteqirobot_reader_thread;			//!<Main thread for plugin
pthread_attr_t attr;			//!<??


/** \brief Initialize RoboteQ-IROBOT plugin, settings and communication
 *
 * The com-ports are opened, the echo from the RoboteQ-IROBOT stopped, variables in rhd is initialized and the thread is started.
 *
 * \returns int status
 * Status of the server thread - negative on error.
 */
int init_roboteqirobot(void)
{
        //char fsname[64];
        //struct timeval tv;
        
        printf("RoboteQ-IROBOT: init start\n");
	//*************Left controller************************//
	
	if((cansock = socket(PF_CAN, SOCK_RAW, CAN_RAW)) < 0) 
	{
	  perror("RoboteQ-IROBOT: Error while opening socket");
	  return -1;
	}
	
	strcpy(ifr.ifr_name, ifname);
	ioctl(cansock, SIOCGIFINDEX, &ifr);
	
	addr.can_family  = AF_CAN;
	addr.can_ifindex = ifr.ifr_ifindex;

	printf("RoboteQ-IROBOT: %s at index %d\n", ifname, ifr.ifr_ifindex);
	
	if(bind(cansock, (struct sockaddr *) &addr, sizeof(addr)) < 0) 
	{
	  perror("RoboteQ-IROBOT: Error in socket bind");
	  return -1;
	}	

	/****** Create database variables if all is ok **************/
        ispeedl		  = createVariable('w', 1, "speedl");
        ispeedr 	  = createVariable('w', 1, "speedr");
        
        //isteeringfeedback = createVariable('r', 1, "steeringfeedback");
	iencr = createVariable('r', 1, "encr");
    	iencl = createVariable('r', 1, "encl");

	// Initialization and starting of threads
	pthread_attr_init(&attr);
	pthread_attr_setinheritsched(&attr, PTHREAD_INHERIT_SCHED);
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	
	/*
	gettimeofday(&tv, NULL);
	sprintf(fsname, "roboteq-irobot-%lf.log", tv.tv_sec + 1e-6 * tv.tv_usec);
	logfs = fopen(fsname, "w");
	*/
        roboteqirobotRunning = 1;
	if(pthread_create(&roboteqirobot_thread, &attr, roboteqirobot_task, 0))
	{
		perror("RoboteQ-IROBOT: Can't start thread");
		return -1;
	}

    	if(pthread_create(&roboteqirobot_reader_thread, &attr, roboteqirobot_reader, 0))
	{
		perror("RoboteQ-IROBOT: Can't start reader thread");
		return -1;
	}
	
	return(1);
}

/** \brief Initialize Shut down server thread
 *
 * \returns int status
 * Status of the server thread - negative on error.
 */
int shutdown_roboteqirobot(void) 
{
  roboteqirobotRunning = 0;
  while(!(roboteqirobotRunning < 0))
    usleep(1000);
    
  if(logfs != NULL)
    fclose(logfs);

  return 1;
}

/** \brief RoboteQ-IROBOT thread.
 * 
 * The RoboteQ-IROBOT only runs very shortly for each speed command therefor the speed is sent to the RoboteQ-IROBOT in this thread every time the loop is running.
 * 
 * The resetmotors sets the encoder values to 0.
 */
void *roboteqirobot_task(void *not_used) {
	#ifdef DEBUG
	printf("RoboteQ-IROBOT Plugin Running\n");
	#endif

	int sleepTime = 500;

	while(roboteqirobotRunning)
	{
		if(cmdspeedlupdated)
		{ 
		  // Send speed to left and right motors
		  sendspeed(0x01, 0x02, cmdspeedl);
		  cmdspeedlupdated = 0;
		}
		
		if(cmdspeedrupdated)
		{ 
		  // Send speed to left and right motors
		  sendspeed(0x01, 0x01, -cmdspeedr);
		  cmdspeedrupdated = 0;
		}

		//sleep so the loop is not using all the calculation power
		usleep(sleepTime);
	}

	if(cansock >= 0)
	{
	  close(cansock);
	}
	
	fprintf(stderr,"RoboteQ-IROBOT: Shutdown RoboteQ-IROBOT task\n");
	roboteqirobotRunning = -1;
	pthread_exit(0);
}

void *roboteqirobot_reader(void *not_used)
{
  int ret;
  unsigned int tmpdat[4];

  while(roboteqirobotRunning)
  {
    ret = read(cansock, &rxfr, sizeof(struct can_frame));
    if(ret > 0 && rxfr.can_id == 0x581 && rxfr.data[1] == 0x04 && rxfr.data[2] == 0x21)
    {
      tmpdat[0] = rxfr.data[4];
      tmpdat[1] = rxfr.data[5];
      tmpdat[2] = rxfr.data[6];
      tmpdat[3] = rxfr.data[7];
    
      if(rxfr.data[3] == 0x01)
        tmpencr = ((tmpdat[0]) | (0xFF00 & (tmpdat[1] << 8)) | (0xFF0000 & (tmpdat[2] << 16)) | (0xFF000000 & (tmpdat[3] << 24)));
      else if(rxfr.data[3] == 0x02)
        tmpencl = -((tmpdat[0]) | (0xFF00 & (tmpdat[1] << 8)) | (0xFF0000 & (tmpdat[2] << 16)) | (0xFF000000 & (tmpdat[3] << 24)));

    /*
    printf("can_data0 = 0x%02X\n", rxfr.data[0]);
    printf("can_data1 = 0x%02X\n", rxfr.data[1]);
    printf("can_data2 = 0x%02X\n", rxfr.data[2]);
    printf("can_data3 = 0x%02X\n", rxfr.data[3]);
    printf("can_data4 = 0x%02X\n", rxfr.data[4]);
    printf("can_data5 = 0x%02X\n", rxfr.data[5]);
    printf("can_data6 = 0x%02X\n", rxfr.data[6]);
    printf("can_data7 = 0x%02X\n", rxfr.data[7]);
    printf("result = %d\n", *resr);
    */
    
    }
  }

  pthread_exit(0);
}

/** \brief is called form the rhd every sample
 * 
 *  Reads the values that is written to the plugin variables.
 * 
 * 
 * */
extern int periodic(int tick)
{
    // Check if variables are updated
    
    if(isUpdated('w', ispeedl))
    {
      cmdspeedl = getWriteVariable(ispeedl, 0);
      cmdspeedlupdated = 1;
    }

    if(isUpdated('w', ispeedr))
    {
      cmdspeedr = getWriteVariable(ispeedr, 0);
      cmdspeedrupdated = 1;
    }
    
    // Request encoder values
    readencoders(0x01);    

    // Set encoders
    setVariable(iencl, 0, tmpencl);
    setVariable(iencr, 0, tmpencr);
    
    return 1;
}

void sendspeed(int node, int channel, int speed)
{
  int len;
  
  // Build CAN frame
  fr.can_id = 0x600 + node;
  fr.can_dlc = 8;
  fr.data[0] = 0x20;  // Specifier: 0x20 = "command" / 0x40 = "query"
  fr.data[1] = 0x00;  // LSB of object dictionary index
  fr.data[2] = 0x20;  // MSB of object dictionary index, 0x2000 = "GO cmd"
  fr.data[3] = channel;
  fr.data[4] = (0xFF & speed);
  fr.data[5] = (0xFF00 & speed) >> 8;
  fr.data[6] = 0x00;
  fr.data[7] = 0x00;
  
  # ifdef DEBUG
  //printf("can_id: 0x%04X\n", fr.can_id);
  //printf("can_dlc = %d\n", fr.can_dlc);
  //printf("can_data0 = 0x%02X\n", fr.data[0]);
  //printf("can_data1 = 0x%02X\n", fr.data[1]);
  //printf("can_data2 = 0x%02X\n", fr.data[2]);
  //printf("can_data3 = 0x%02X\n", fr.data[3]);
  //printf("can_data4 = 0x%02X\n", fr.data[4]);
  //printf("can_data5 = 0x%02X\n", fr.data[5]);
  # endif
  
  len = write(cansock, &fr, sizeof(struct can_frame));

  if(len < 0)
  {
    //printf("Write ERROR: %s\n" , strerror(errno));
  }
  
  # ifdef DEBUG
  //printf("Wrote %d bytes to %s\n", len, ifname);
  # endif
    
  //ret = read(cansock, &rxfr, sizeof(struct can_frame));
}


void readencoders(int node)
{
  // Build CAN frame
  fr.can_id = 0x600 + node;
  fr.can_dlc = 8;
  fr.data[0] = 0x48;  // Specifier: 0x20 = "command" / 0x4x = "query"
  fr.data[1] = 0x04;  // LSB of object dictionary index
  fr.data[2] = 0x21;  // MSB of object dictionary index, 0x2110 = "read feedback"
  fr.data[3] = 0x01;  // Channel 1
  fr.data[4] = 0x00;
  fr.data[5] = 0x00;
  fr.data[6] = 0x00;
  fr.data[7] = 0x00;
  
  write(cansock, &fr, sizeof(struct can_frame));
  usleep(1000);

  fr.can_id = 0x600 + node;
  fr.can_dlc = 8;
  fr.data[0] = 0x48;  // Specifier: 0x20 = "command" / 0x4x = "query"
  fr.data[1] = 0x04;  // LSB of object dictionary index
  fr.data[2] = 0x21;  // MSB of object dictionary index, 0x2110 = "read feedback"
  fr.data[3] = 0x02;  // Channel 2
  fr.data[4] = 0x00;
  fr.data[5] = 0x00;
  fr.data[6] = 0x00;
  fr.data[7] = 0x00;
  
  write(cansock, &fr, sizeof(struct can_frame));
}


extern int terminate()
{
  return(shutdown_roboteqirobot());
}



/************************** XML Initialization **************************/
///Struct for shared parse data
typedef struct  
{
  int depth;
  char skip;
  char enable;
  char found;
} parseInfo;

//Parsing functions
void XMLCALL roboteqirobotStartTag(void *, const char *, const char **);
void XMLCALL roboteqirobotEndTag(void *, const char *);

/** \brief Initialize the RoboteQ-IROBOT with settings from configuration file.
 *
 * Reads the XML file and sets up the RoboteQ-IROBOT settings
 *
 * Finally the initialization of the RoboteQ-IROBOT plugin is started.
 *
 * \param[in] *char filename
 * Filename of the XML file
 *
 * \returns int status
 * Status of the initialization process. Negative on error.
 */
int initXML(char *filename) 
{
  parseInfo xmlParse;
  char *xmlBuf = NULL;
	int xmlFilelength;
  int done = 0;
  int len;
  FILE *fp;

  printf("RoboteQ-IROBOT: Initializing RoboteQ-IROBOT Motor Controller %s\n", ROBOTEQ_IROBOT_VERSION);


   /* Initialize Expat parser*/
   XML_Parser parser = XML_ParserCreate(NULL);
   if (! parser) {
    fprintf(stderr, "RoboteQ-IROBOT: Couldn't allocate memory for XML parser\n");
    return -1;
   }

   //Setup element handlers
   XML_SetElementHandler(parser, roboteqirobotStartTag, roboteqirobotEndTag);
   //Setup shared data
   memset(&xmlParse,0,sizeof(parseInfo));
   XML_SetUserData(parser,&xmlParse);

  //Open and read the XML file
  fp = fopen(filename,"r");
  if(fp == NULL)
  {
    printf("RoboteQ-IROBOT: Error reading: %s\n",filename);
    return -1;
  }
  //Get the length of the file
	fseek(fp,0,SEEK_END);
	xmlFilelength = ftell(fp); //Get position
	fseek(fp,0,SEEK_SET); //Return to start of file

	//Allocate text buffer
	xmlBuf = realloc(xmlBuf,xmlFilelength+10); //Allocate memory
	if (xmlBuf == NULL) {
		fprintf(stderr, "   Couldn't allocate memory for XML File buffer\n");
		return -1;
	}
	memset(xmlBuf,0,xmlFilelength);
  len = fread(xmlBuf, 1, xmlFilelength, fp);
  fclose(fp);

  //Start parsing the XML file
  if (XML_Parse(parser, xmlBuf, len, done) == XML_STATUS_ERROR) {
    fprintf(stderr, "RoboteQ-IROBOT: XML Parse error at line %d: %s\n",
            (int)XML_GetCurrentLineNumber(parser),
            XML_ErrorString(XML_GetErrorCode(parser)));
    return -1;
  }
  XML_ParserFree(parser);
  free(xmlBuf);

  //Print error, if no XML tag found
  if (xmlParse.found <= 0) {
    printf("   Error: No <roboteqirobot> XML tag found in plugins section\n");
    return -1;
  }

  //Start roboteqcan thread after init
  printf("RoboteQ-IROBOT: starting thread\n");
  if (xmlParse.enable) 
    done = init_roboteqirobot();
  printf("RoboteQ-IROBOT: init finished\n");
 return done;
}

void XMLCALL
roboteqirobotStartTag(void *data, const char *el, const char **attr)
{
  int i;
  parseInfo *info = (parseInfo *) data;
  info->depth++;

  if (!info->skip) {
    if (((info->depth == 1) && (strcmp("rhd",el) != 0)) ||
        ((info->depth == 2) && (strcmp("plugins",el) != 0)) ||
 	((info->depth == 3) && (strcmp("roboteqirobot",el) != 0))) {
      info->skip = info->depth;
      return;
    } else if (info->depth == 3) info->found = 1;
  } else return;

  //Branch to parse the elements of the XML file.
  if (!strcmp("roboteqirobot",el)) {
    //Check for the correct depth for this tag
    for(i = 0; attr[i]; i+=2) if ((strcmp("enable",attr[i]) == 0) && (strcmp("true",attr[i+1]) == 0)) {
      info->enable = 1;
    }
    if (!info->enable) {
      printf("RoboteQ-IROBOT: Use of roboteqirobot disabled in configuration\n");
      info->skip = info->depth;
    }
  } 
    else if (strcmp("can",el) == 0) {
    //Check for the correct depth for this tag
    if(info->depth != 4) {
      printf("Error: Wrong depth for the %s tag\n",el);
    }
    for(i = 0; attr[i]; i+=2) if (strcmp("device",attr[i]) == 0){strncpy(ifname,attr[i+1],63);printf("RoboteQ-IROBOT: Device is %s \n",ifname);
    }

  }
  

}

void XMLCALL
roboteqirobotEndTag(void *data, const char *el)
{
  parseInfo *info = (parseInfo *) data;
  info->depth--;

  if (info->depth < info->skip) info->skip = 0;
}	


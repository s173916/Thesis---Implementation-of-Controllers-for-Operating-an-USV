/** \file roboteq-irobot.h
 *  \ingroup hwmodule
 *  \brief RoboteQ mdc2460 brushed DC Motor Controller CANOpen Interface 
 *
 */

#ifndef ROBOTEQ_IROBOT_DOT_H
#define ROBOTEQ_IROBOT_DOT_H

#define RTQSTRSIZE 64

/* \brief Read settings from XML-configuration file
 */
int initXML(char *);
extern int periodic(int);
extern int terminate(void);

#endif

/***************************************************************************
*   Copyright (C) 2017 by DTU                             *
*   jca@elektro.dtu.dk                                                    *
*
*   Main function for small regulation control object (regbot)
*   build on Teensy,
*   intended for 31300 Linear control
*   has an IMU and a dual motor controller with current feedback.
*
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
*   This program is distributed in the hope that it will be useful,       *
*   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
*   GNU General Public License for more details.                          *
*                                                                         *
*   You should have received a copy of the GNU General Public License     *
*   along with this program; if not, write to the                         *
*   Free Software Foundation, Inc.,                                       *
*   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
***************************************************************************/

#define REV_ID "$Id: main.cpp 981 2018-10-14 10:14:15Z jcan $"

#include <malloc.h>
#include <string.h>
#include <ADC.h>
#include <core_pins.h>
#include "../teensy3/IntervalTimer.h"
#include "../teensy3/usb_serial.h"


// main heartbeat timer to service source data and control loop interval
int32_t hbTimerCnt = 0;
bool startNewCycle = false;
// command buffer
const int RX_BUF_SIZE = 60;
char usbRxBuf[RX_BUF_SIZE] = "";
int usbRxBufCnt = 0;
// main value 
bool powerOn = false;
// number of 10us interrrupts to start a control cycle
const int CONTROL_PERIOD_10us = 100;
volatile uint32_t hb10us;
// pins
const int PIN_LED_DEBUG = 13;
const int PIN_ON = 12;
const int PIN_LED_ON = 11;


IntervalTimer hbTimer;
void hbIsr ( void );
// ////////////////////////////////////////

void usb_send_str(const char * msg)
{ // surplus characters will be skipped
//   Serial.write(msg, strlen(msg));
  usb_serial_write(msg, strlen(msg));
}


void initialization()   // INITIALIZATION
{
  pinMode ( 11, OUTPUT );
  pinMode ( 12, OUTPUT );
  pinMode ( 13, OUTPUT );
  // init USB connection (parameter is not used - always 12MB/s)
  Serial.begin ( 115200 ); // USB init serial
  // start 10us timer (heartbeat timer)
  hbTimer.begin ( hbIsr, ( unsigned int ) 10 ); // heartbeat timer, value in usec
}


void handleCommand(char * command, int commandCnt)
{
  if (commandCnt >= 4)
  {
    if (strncmp(command, "power", 5) == 0)
    { // line starts with power
      if (strstr(command, "on") != NULL)
        powerOn = true;
      else if (strstr(command, "off") != NULL)
        powerOn = false;
      else
      {
        const int MSL = 60;
        char s[MSL];
        snprintf(s, MSL, "# power is %d\r\n", powerOn);
        usb_send_str(s);
      }
    }
    else if (strncmp(command, "help", 4) == 0)
    {
      usb_send_str("# 24V USB power switch\r\n");
      usb_send_str("# " REV_ID "\r\n");
      usb_send_str("# Commads:\r\n");
      usb_send_str("# power on      Turns on power\r\n");
      usb_send_str("# power off     Turns off power\r\n");
      usb_send_str("# power         Returns current status 0=off, 1=on\r\n");
      usb_send_str("# help          This help text\r\n");
    }
  }
//   const int MSL = 160;
//   char s[MSL];
//   snprintf(s, MSL, "# len=%d, buf=%s\n", commandCnt, command);
//   usb_send_str(s);
}

void handleIncoming()
{
  int n, m;
  bool gotCmd = false;
  // get number of available chars in USB buffer
//   m = Serial.available();
  m = usb_serial_available();
  if (m > 30)
  { // flush garbage
//     Serial.clear();
    usb_serial_flush_input();
    m = 0;
  }
  if (m > 0)
  { // get characters
    for (int i = 0; i < m; i++)
    { // get pending characters
      // get one character
//       n = Serial.read();
      n = usb_serial_getchar();
      if (n >= ' ')
      { // there is data from USB, 
        // put into buffer
        if (usbRxBufCnt < RX_BUF_SIZE - 1)
        {
          usbRxBuf[usbRxBufCnt++] = n;
          usbRxBuf[usbRxBufCnt] = '\0';
        }
        else
          // buffer full, drop garbage.
          usbRxBufCnt = 0;
      }
      if (usbRxBufCnt > 1 and (n == '\n' or n == '\r'))
      {
        gotCmd = true;
        break;
      }
    }
    if (gotCmd)
    { // there is a command line (newline or carriage return not included)
      if (usbRxBuf[0] != '#')
        // at times dent messages are returned to teensy,
        // but as they all start with #, then just ignore
        handleCommand(usbRxBuf, usbRxBufCnt) ;
//       usb_send_str("\r\ncmd: ");
      // clear buffer
      usbRxBufCnt = 0;
      usbRxBuf[0] = '\0';
    }
  }
}
/**
* Main loop
* primarily for initialization,
* non-real time services and
* synchronisation with heartbeat.*/
extern "C" int main ( void )
{
  initialization();
  int mainLoop = 0;
  bool powerIsOn = false;
  // write buffer
//   const int MSL = 62;
//   char s[MSL];
  // turn on debug LED
  digitalWriteFast ( PIN_LED_DEBUG, 1 );
  digitalWriteFast ( PIN_LED_ON, 0 );
  digitalWriteFast ( PIN_ON, 0 );
  // wait a bit - to allow usb to connect in order to see init errors
  delay ( 300 ); // ms
  usb_send_str("#24V USB power switch - " REV_ID "\r\n");
  while ( true ) 
  { // main loop
    // get data from USB
    handleIncoming();
    if ( startNewCycle ) // start of new control cycle
    { // 1ms has passed
      if (powerIsOn != powerOn)
      {
        if (powerOn)
          digitalWriteFast ( PIN_ON, 1);
        else
          digitalWriteFast ( PIN_ON, 0);
        powerIsOn = powerOn;
      }
      if (hbTimerCnt % 1000 == 0)
      { // turn ON LED on
        digitalWriteFast ( PIN_LED_DEBUG, 1 );
        digitalWriteFast ( PIN_LED_ON, 1);
//         snprintf(s, MSL, "# 1 sec passed, power is %d\r\n", powerOn);
//         usb_send_str(s);
      }
      if (powerOn)
      { // long blink (0.9 sec)
        if (hbTimerCnt % 1000 == 900)
        {
          digitalWriteFast ( PIN_LED_ON, 0);
        }
      }
      else
      { // short blink (0.01 sec)
        if (hbTimerCnt % 1000 == 10)
        {
          digitalWriteFast ( PIN_LED_ON, 0);
        }
      }
      if (hbTimerCnt % 1000 == 100)
      {
        digitalWriteFast ( PIN_LED_DEBUG, 0);
      }
      //
      startNewCycle = false;
    }
    mainLoop++;
  }
  return 0;
}

/**
* Heartbeat interrupt routine
* schedules data collection and control loop timing.
* */
void hbIsr ( void ) // called every 10 microsecond
{
  // as basis for all timing
  hb10us++;
  if ( hb10us % CONTROL_PERIOD_10us == 0 ) // 1ms timing - main control period start
  {
    hbTimerCnt++;
    startNewCycle = true;
  }
}

/////////////////////////////////////////////////////////////////


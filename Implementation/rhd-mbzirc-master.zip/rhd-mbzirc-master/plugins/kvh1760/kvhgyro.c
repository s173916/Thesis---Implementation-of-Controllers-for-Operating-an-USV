/** \file cruizcore.h
 *  \ingroup hwmodule
 *  \brief Driver for the Microinfinity CruizCore Gyro module
 *
 *  This driver interfaces the Microinfinity CruizCore XG1010
 *
 *  Interface to the hardware is rather simplistic, so data is directly
 *  forwarded from the gyro and only calibration reset is avaliable in
 *  the opposite direction
 *
 *  \author Anders Billesø Beck
 *  $Rev: 481 $
 *  $Date: 2011-07-02 06:52:23 +0200 (Sat, 02 Jul 2011) $
 *
 */
/***************************************************************************
 *                  Copyright 2010 Anders Billesø Beck, DTU / DTI          *
 *                       anbb@teknologisk.dk                               *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License as        *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU Lesser General Public License for more details.                   *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
/************************** Library version  ***************************/
#define VERSION   	      "1.0"
/************************** Version control information ***************************/
 #define REVISION         "$Rev: 481 $:"
 #define DATE             "$Date: 2011-07-02 06:52:23 +0200 (Sat, 02 Jul 2011) $:"
/**********************************************************************************/

#include <sched.h>
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <linux/serial.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <arpa/inet.h>
#include <expat.h>
#include <math.h>

//RHD Core headers
#include <rhd.h>
#include <database.h>
#include <globalfunc.h>

#include "kvhgyro.h"

#define KVHGAIN 4.888e-5

/******** Global variables *************/
int iReset, iRate, iPos,iPos1,iOffset;
int sDev = 0;  //File descriptors
char serialDev[64];
int baudrate;
volatile int cruizRunning = -1;
volatile double dpos=0,dpos1=0,doffset=0;
pthread_t rxThread;
pthread_attr_t attr;

const char debug = 0;
volatile unsigned char buf[50];


/******** Function prototypes *************/
int initgyro(void);
void *rxtask(void *);

int init_serial(int portfd, speed_t baudrate)
{
  struct termios ntio;
  struct serial_struct xtty;
  
  if(tcgetattr(portfd, &ntio) < 0) 
  {
    fprintf(stderr, "Unable to get terminal attributes\n");
    return(1);
  }
  
  cfsetispeed(&ntio, baudrate);
  cfsetospeed(&ntio, baudrate);
  
  // 8Odd1
  ntio.c_cflag |= PARODD;
  ntio.c_cflag &= ~PARENB;
  ntio.c_cflag &= ~CSTOPB;
  ntio.c_cflag &= ~CSIZE;
  ntio.c_cflag |= CS8;
  
  // no flow control
  ntio.c_cflag &= ~CRTSCTS;

  //toptions.c_cflag &= ~HUPCL; // disable hang-up-on-close to avoid reset
  ntio.c_cflag |= CREAD | CLOCAL;  // turn on READ & ignore ctrl lines
  ntio.c_iflag &= ~(IXON | IXOFF | IXANY | ICRNL); // turn off s/w flow ctrl

  ntio.c_lflag &= ~(ICANON | IEXTEN | ECHO | ECHOE | ECHOK | ISIG | ECHOCTL | ECHOKE); // make raw
  ntio.c_oflag &= ~OPOST; // make raw

  // see: http://unixwiz.net/techtips/termios-vmin-vtime.html
  ntio.c_cc[VMIN]  = 0;
  ntio.c_cc[VTIME] = 100;
  
  tcsetattr(portfd, TCSANOW, &ntio);
  if(tcsetattr(portfd, TCSAFLUSH, &ntio) < 0) 
  {
     fprintf(stderr, "Unable to set terminal attributes\n");
     return(2);
  }
  
  if(ioctl(portfd, TIOCGSERIAL, &xtty) < 0)
  {
    printf("Error: could not get comm ioctl\n"); 
    return(3); 
  }
  //printf("=> %d\n", xtty.baud_base);              // Baud base frequency 24 MHz for 
  xtty.custom_divisor = xtty.baud_base / 921600;  // Set custom-divisor: 24000000 / 921600 ==> Achieves 921600 baud
  xtty.flags |= ASYNC_SPD_CUST;
  if(ioctl(portfd, TIOCSSERIAL, &xtty) < 0)
  {
    printf("Error: could not set comm ioctl\n"); 
    return(4); 
  }
  
  return(0);
}



/** \brief Initialize communications and variables
 * 
 * \returns int status
 * Status of the initialization process. Negative on error.
 */
int initgyro(void) {


	//Open first serial port
  if ((sDev = open (serialDev, O_RDWR /*| O_NONBLOCK*/)) == -1) {
		fprintf(stderr,"   Can't open serial port: %s\n",serialDev);
		cruizRunning = -1;
		return -1;
  } else if (init_serial(sDev, B38400) == -1) {
		fprintf(stderr,"   Can't set serial port parameters\n");
		fprintf(stderr,"   kvhgyro is NOT running!\n");
		cruizRunning = -1;
		return -1;
  } else cruizRunning = 2;
 
	/****** Create database variables if all is ok **************/
        iRate 		= createVariable('r',1,"kvhrate");
	iPos 		= createVariable('r',1,"kvhpos");
	iPos1 		= createVariable('r',1,"kvhpos1");
	iReset      	= createVariable('w',1,"kvhreset");
	iOffset      	= createVariable('w',1,"kvhoffset");

	//Start RX thread
  pthread_attr_init(&attr);
  pthread_attr_setinheritsched(&attr, PTHREAD_INHERIT_SCHED); 
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

  if (pthread_create(&rxThread, &attr, rxtask, 0))
    {
      perror("   Can't start kvhgyro receive thread");
      cruizRunning = -1;
      return -1;
    }

	while (cruizRunning > 1) usleep(1000); //Don't proceed before threads are running

  return 1;
}


/** \brief Transmit data to rflex serial bus
 * 
 *  * \param[in] int tick
 * Tick counter from main program
 * 
 * \returns int status
 * Status of the transmission process. Negative on error.
 */
extern int periodic(int tick)
{

		//Reset module if requested
		if (isUpdated('w',iReset)) {
		   dpos=0;	
		}
		if (isUpdated('w',iOffset)) {
			doffset=getWriteVariable(iOffset,0)/1.0e9;	
		}

  return 1;
}

char syncok(void){
   if( buf[0]==0xFE && buf[1]==0x81 && buf[2]==0xff && buf[3]==0x55)
     return 1;
   else
     return 0;
 }


/** \brief Recieve thread for kvhgyro communication
 * 
 * \returns * void
 * Unused
 */
void *rxtask(void *something) {
	double timeold,time,rate;
	struct timeval tv;
	unsigned char stat,ch,tmp;
	//Set running back to 1 to indicate thread start
	
	int16_t rb,nb;
	
	cruizRunning = 1;
	printf("  KVHgyro: RX Thread started\n");

	gettimeofday(&tv, NULL); 
	timeold=tv.tv_sec + tv.tv_usec * 1e-6; 
	//Everloop that recieves 
	while (cruizRunning > 0) {
		rb=4;
    		while (rb>0){
      			nb=read(sDev, &buf[4-rb], rb);
      			rb=rb-nb;
   		}
 
    		while (!syncok()){
       			buf[0]=buf[1];
 			buf[1]=buf[2];
 			buf[2]=buf[3];
        		read(sDev, &buf[3], 1);
        		fprintf(stderr, "Sync fail %x %x %x %x \n",buf[0],buf[1],buf[2],buf[3]); 
    		}
    		gettimeofday(&tv, NULL);  
    		time=tv.tv_sec + tv.tv_usec * 1e-6; 
		 rb=32;
                 
		while (rb>0){
		  nb=read(sDev, &buf[32-rb], rb);
		  rb=rb-nb;
		}
    tmp=buf[8];
		buf[8]=buf[11];
		buf[11]=tmp;
		tmp=buf[9];
		buf[9]=buf[10];
		buf[10]=tmp;
  
		rate=*(float *)&buf[8];
    if(rate>1e-4 || rate<1e-4){
      dpos+=(rate-doffset);
    }
    timeold=time;
    setVariable(iRate , 0, 10000000*rate);
    setVariable(iPos , 0, 10000*dpos);
    		//printf("%lf %d %d\n", tv.tv_sec + tv.tv_usec * 1e-6, *(int*)buf, stat);	
	}//End of rxLoop

	//Shut down CruizCore, if recieve fails
	cruizRunning = -2;
	fprintf(stderr,"KVHgyro: RX thread terminated\n");

	return something;
}

/** \brief Shut down rFLEX driver
 * 
 * \returns int success
 *  Checksum value
 */
extern int terminate(void) {

	//rFLEX commands to shut down robot!
	if (cruizRunning > 0) {
		cruizRunning = -1;
		if (sDev) close(sDev);
		//Wait for thread to close
		while (cruizRunning > -1);	usleep(100000); //Wait 100 ms
	}

	return 1;
}




/************************** XML Initialization **************************/
///Struct for shared parse data
typedef struct  {
    int depth;
    char skip;
    char enable;
		char found;
  }parseInfo;

//Parsing functions
void XMLCALL startTag(void *, const char *, const char **);
void XMLCALL endTag(void *, const char *);

/** \brief Initialize the SMRD HAL
 *
 * Reads the XML file and sets up the SMRD settings
 * 
 * Finally the rx threads is started and the driver 
 * is ready to read data
 * 
 * \param[in] *char filename
 * Filename of the XML file
 * 
 * \returns int status
 * Status of the initialization process. Negative on error.
 */
extern int initXML(char *filename) {

  parseInfo xmlParse; 
  char *xmlBuf = NULL;
	int xmlFilelength;
  int done = 0;
  int len;
  FILE *fp;

  //Print initialization message
  //Find revision number from SVN Revision
	char *i,versionString[20] = REVISION, tempString[10];
	i = strrchr(versionString,'$');
	strncpy(tempString,versionString+6,(i-versionString-6));
	tempString[(i-versionString-6)] = 0;
  printf("KVH: Initializing kvh Gyro HAL %s.%s\n",VERSION,tempString);


   /* Initialize Expat parser*/
   XML_Parser parser = XML_ParserCreate(NULL);
   if (! parser) {
    fprintf(stderr, "   Couldn't allocate memory for XML parser\n");
    return -1;
   }

   //Setup element handlers
   XML_SetElementHandler(parser, startTag, endTag);
   //Setup shared data
   memset(&xmlParse,0,sizeof(parseInfo));
   XML_SetUserData(parser,&xmlParse);

  //Open and read the XML file
  fp = fopen(filename,"r");
  if(fp == NULL)
  {
    printf("   Error reading: %s\n",filename);
    return -1;
  }
  //Get the length of the file
	fseek(fp,0,SEEK_END);
	xmlFilelength = ftell(fp); //Get position
	fseek(fp,0,SEEK_SET); //Return to start of file

	//Allocate text buffer
	xmlBuf = realloc(xmlBuf,xmlFilelength+10); //Allocate memory
	if (xmlBuf == NULL) {
		fprintf(stderr, "   Couldn't allocate memory for XML File buffer\n");
		return -1;
	}
	memset(xmlBuf,0,xmlFilelength);
  len = fread(xmlBuf, 1, xmlFilelength, fp);
  fclose(fp);

  //Start parsing the XML file
  if (XML_Parse(parser, xmlBuf, len, done) == XML_STATUS_ERROR) {
    fprintf(stderr, "   XML Parse error at line %d: %s\n",
            (int)XML_GetCurrentLineNumber(parser),
            XML_ErrorString(XML_GetErrorCode(parser)));
    return -1;
  }
  XML_ParserFree(parser);
	free(xmlBuf);

	//Print error, if no XML tag found
	if (xmlParse.found <= 0) {
		printf("   Error: No <kvhgyro> XML tag found in plugins section\n");
		return -1;
	}

  //Initialize if XML parsed properly
  if (xmlParse.enable) done = initgyro();



 return done;
}

void XMLCALL
startTag(void *data, const char *el, const char **attr)
{
  int i;
  parseInfo *info = (parseInfo *) data;
  info->depth++;

  //Check for the right 1., 2. and 3. level tags
  if (!info->skip) {
    if (((info->depth == 1) && (strcmp("rhd",el) != 0)) ||
        ((info->depth == 2) && (strcmp("plugins",el) != 0)) ||
 				((info->depth == 3) && (strcmp("kvhgyro",el) != 0))) {
      info->skip = info->depth;
      return;
    } else if (info->depth == 3) info->found = 1;
  } else return;

  //Branch to parse the elements of the XML file.
  if (!strcmp("kvhgyro",el)) {
    //Check for the correct depth for this tag
    for(i = 0; attr[i]; i+=2) if ((strcmp("enable",attr[i]) == 0) && (strcmp("true",attr[i+1]) == 0)) {
      info->enable = 1; 
    }
    if (!info->enable) {
      printf("   Use of kvh gyro disabled in configuration\n");
      info->skip = info->depth;
    }
  } else if (strcmp("serial",el) == 0) {
    //Check for the correct depth for this tag
    if(info->depth != 4) {
      printf("Error: Wrong depth for the %s tag\n",el);
    }
    for(i = 0; attr[i]; i+=2) if (strcmp("port",attr[i]) == 0) strncpy(serialDev,attr[i+1],63);
    for(i = 0; attr[i]; i+=2) if (strcmp("baudrate",attr[i]) == 0) baudrate = atoi(attr[i+1]);  
    printf("   Serial port %s at %d baud\n",serialDev,baudrate);
  }

}

void XMLCALL
endTag(void *data, const char *el)
{
  parseInfo *info = (parseInfo *) data;
  info->depth--;

  if (info->depth < info->skip) info->skip = 0;
}

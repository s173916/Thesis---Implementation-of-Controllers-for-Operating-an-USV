/* a dummy function so that libreplace.a is never empty, even when nothing
 * needs to be replaced */
int player_dummy(void)
{
  return(0);
}


#ifndef _CONFIG_H
#define _CONFIG_H

#define PROJECT "Stage"
#define VERSION "3.2.2"
#define APIVERSION "3.2"
#define INSTALL_PREFIX "/usr/local"

/* #undef BUILD_GUI */

#endif


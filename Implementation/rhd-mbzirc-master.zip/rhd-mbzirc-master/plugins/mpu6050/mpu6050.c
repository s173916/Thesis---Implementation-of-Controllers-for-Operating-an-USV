/*
	MPU6050 Interfacing with Raspberry Pi
*/
#define PLUGINNAME "mpu6050"

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <netdb.h>
#include <fcntl.h>
#include <string.h>
#include <pthread.h>
#include <signal.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <errno.h>
#include <termios.h>
#include <sys/ioctl.h>
#include <linux/serial.h>
#include <expat.h>
#include <math.h>

#include <wiringPiI2C.h>
#include <wiringPi.h>

#include <database.h>
/* Registry Addresses*/
#define Device_Address 0x68	/*Device Address/Identifier for MPU6050*/

#define PWR_MGMT_1   0x6B
#define SMPLRT_DIV   0x19
#define CONFIG       0x1A
#define GYRO_CONFIG  0x1B
#define ACCEL_CONFIG 0x1C
#define INT_ENABLE   0x38
#define ACCEL_XOUT_H 0x3B
#define ACCEL_YOUT_H 0x3D
#define ACCEL_ZOUT_H 0x3F
#define GYRO_XOUT_H  0x43
#define GYRO_YOUT_H  0x45
#define GYRO_ZOUT_H  0x47

//Sensitivity Scale Factors
#define GYRO_SENS 16.4 //Gyroscope sensitivity scale factor
#define ACCEL_SENS 16384.0 //Accelerometer sensitivity scale factor
//Threads
pthread_t i2c_thread_read;
pthread_attr_t attr;
//Database indexes
int AccXindex, AccYindex, AccZindex, GyroXindex, GyroYindex, GyroZindex;
//Function prototypes
int initI2C_MPU6050(void);
short read_raw_data(int addr);
void *getI2CData(void * not_used);
int initMPU6050(void);
void createI2Cvariables(void);

int mpuDevice;
static volatile char mpuRunning = 0;

int AccXOffset = -88, AccYOffset = 68;
int GyroXOffset = -5100, GyroYOffset = 1300, GyroZOffset = -1950;

int initMPU6050(void){
	int result;
	if ((mpuDevice = initI2C_MPU6050()) < 0)
	{
		printf("Could not access I2C port\r\n.");
		return -1;
	}
	else {
		printf("I2C port opened!\r\n.");
		result = 1;
	}
	//Create variables to store accelerometer and gyroscope data
	pthread_attr_init(&attr);
    pthread_attr_setinheritsched(&attr, PTHREAD_INHERIT_SCHED);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	if (pthread_create(&i2c_thread_read, &attr, getI2CData, 0))
    {
      perror(PLUGINNAME "   Can't start i2c receive thread");
      result = 0;
    }
	if (result == 1)
	{ /****** Create database variables if all is ok **************/
		int waitCount = 0;
		createI2Cvariables();
		while (!mpuRunning)
		{ // wait a bit for thread to start
		usleep(20000); //Don't return before threads are running
		if (waitCount >= 50)
		{
			result = 0;
			break;
		}
		waitCount++;
		}
	}
	return result;
}

int initI2C_MPU6050(void){
	int fd;
	  /*Initializes I2C with device Address*/
	if ((fd = wiringPiI2CSetup(Device_Address)) < 0)
	{
		printf("Cannot open I2C port\r\n.");
		return -1;
	}
	wiringPiI2CWriteReg8 (fd, PWR_MGMT_1, 0x00);	/* Write to power management register */
	wiringPiI2CWriteReg8 (fd, SMPLRT_DIV, 0x04);	/* Write to sample rate divider register - 250 Hz*/
	wiringPiI2CWriteReg8 (fd, CONFIG, 0x00);		/* Write to Configuration register */
	wiringPiI2CWriteReg8 (fd, GYRO_CONFIG, 0x18);	/* Write to Gyro Configuration register */
	wiringPiI2CWriteReg8 (fd, ACCEL_CONFIG, 0x00); /* Write to accelerometer configuration register */
	wiringPiI2CWriteReg8 (fd, INT_ENABLE, 0x00);	/*Write to interrupt enable register */
	return fd;
}


void createI2Cvariables(void){
	AccXindex = createVariable('r',1,"AccX");
	AccYindex = createVariable('r',1,"AccY");
	AccZindex = createVariable('r',1,"AccZ");
	GyroXindex = createVariable('r',1,"GyroX");
	GyroYindex = createVariable('r',1,"GyroY");
	GyroZindex = createVariable('r',1,"GyroZ");
}
short read_raw_data(int addr){
	short high_byte,low_byte,value;
	high_byte = wiringPiI2CReadReg8(mpuDevice, addr);
	low_byte = wiringPiI2CReadReg8(mpuDevice, addr+1);
	value = (high_byte << 8) | low_byte;
	return value;
}

void *getI2CData(void * not_used){
	
	float Acc_x,Acc_y,Acc_z;
	float Gyro_x,Gyro_y,Gyro_z;
	float Ax=0, Ay=0, Az=0;
	float Gx=0, Gy=0, Gz=0;

	mpuRunning = 1;
	while(mpuRunning)
	{
		/*Read raw value of Accelerometer and gyroscope from MPU6050*/
		Acc_x = read_raw_data(ACCEL_XOUT_H);
		Acc_y = read_raw_data(ACCEL_YOUT_H);
		Acc_z = read_raw_data(ACCEL_ZOUT_H);
		
		Gyro_x = read_raw_data(GYRO_XOUT_H);
		Gyro_y = read_raw_data(GYRO_YOUT_H);
		Gyro_z = read_raw_data(GYRO_ZOUT_H);
		
		/* Divide raw value by sensitivity scale factor */
		Ax = Acc_x/ACCEL_SENS;
		Ay = Acc_y/ACCEL_SENS;
		Az = Acc_z/ACCEL_SENS;
		
		Gx = Gyro_x/GYRO_SENS;
		Gy = Gyro_y/GYRO_SENS;
		Gz = Gyro_z/GYRO_SENS;
		
		//printf("\n Gx=%.3f °/s\tGy=%.3f °/s\tGz=%.3f °/s\tAx=%.3f g\tAy=%.3f g\tAz=%.3f g\n",Gx,Gy,Gz,Ax,Ay,Az);
		int AccXFinal = round(Ax*1000)-AccXOffset;
		int AccYFinal = round(Ay*1000)-AccYOffset;
		int GyroXFinal = round(Gx*1000)-GyroXOffset;
		int GyroYFinal = round(Gy*1000)-GyroYOffset;
		int GyroZFinal = round(Gz*1000)-GyroZOffset;

		setVariable(AccXindex,0, AccXFinal);
		setVariable(AccYindex,0, AccYFinal);
		setVariable(AccZindex,0, round(Az*1000));
		setVariable(GyroXindex,0, GyroXFinal);
		setVariable(GyroYindex,0, GyroYFinal);
		setVariable(GyroZindex,0, GyroZFinal);
	}
	pthread_exit(0);
}

/************************** XML Initialization **************************/
///Struct for shared parse data
typedef struct  {
    int depth;
    char skip;
    char enable;
	char found;
  }parseInfo;

//Parsing functions
void XMLCALL mpuStartTag(void *, const char *, const char **);
void XMLCALL mpuEndTag(void *, const char *);

/** \brief Initialize the MPU HAL
 *
 * Reads the XML file and sets up the MPU settings
 * 
 * 
 * \param[in] *char filename
 * Filename of the XML file
 * 
 * \returns int status
 * Status of the initialization process. Negative on error.
 */
int initXML(char *filename) {

  parseInfo xmlParse; 
  char *xmlBuf = NULL;
	int xmlFilelength;
  int done = 0;
  int len;
  FILE *fp;

  //Print initialization message
  printf("MPU: Initializing I2C MPU6050 HAL\n");


   /* Initialize Expat parser*/
   XML_Parser parser = XML_ParserCreate(NULL);
   if (! parser) {
    fprintf(stderr, "MPU: Couldn't allocate memory for XML parser\n");
    return -1;
   }

   //Setup element handlers
   XML_SetElementHandler(parser, mpuStartTag, mpuEndTag);
   //Setup shared data
   memset(&xmlParse,0,sizeof(parseInfo));
   XML_SetUserData(parser,&xmlParse);

  //Open and read the XML file
  fp = fopen(filename,"r");
  if(fp == NULL)
  {
    printf("MPU: Error reading: %s\n",filename);
    return -1;
  }
  //Get the length of the file
	fseek(fp,0,SEEK_END);
	xmlFilelength = ftell(fp); //Get position
	fseek(fp,0,SEEK_SET); //Return to start of file

	//Allocate text buffer
	xmlBuf = realloc(xmlBuf,xmlFilelength+10); //Allocate memory
	if (xmlBuf == NULL) {
		fprintf(stderr, "   Couldn't allocate memory for XML File buffer\n");
		return -1;
	}
	memset(xmlBuf,0,xmlFilelength);
  len = fread(xmlBuf, 1, xmlFilelength, fp);
  fclose(fp);

  //Start parsing the XML file
  if (XML_Parse(parser, xmlBuf, len, done) == XML_STATUS_ERROR) {
    fprintf(stderr, "smrdSerial: XML Parse error at line %d: %s\n",
            (int)XML_GetCurrentLineNumber(parser),
            XML_ErrorString(XML_GetErrorCode(parser)));
    return -1;
  }
  XML_ParserFree(parser);
	free(xmlBuf);

	//Print error, if no XML tag found
	if (xmlParse.found <= 0) {
		printf("   Error: No <mpu6050> XML tag found in plugins section\n");
		return -1;
	}

  //Start crossbow thread after init
  if (xmlParse.enable) done = initMPU6050();

 return done;
}

void XMLCALL
mpuStartTag(void *data, const char *el, const char **attr)
{
  int i;
  parseInfo *info = (parseInfo *) data;
  info->depth++;

  //Check for the right 1., 2. and 3. level tags
  if (!info->skip) {
    if (((info->depth == 1) && (strcmp("rhd",el) != 0)) ||
        ((info->depth == 2) && (strcmp("plugins",el) != 0)) ||
 				((info->depth == 3) && (strcmp("mpu6050",el) != 0))) {
      info->skip = info->depth;
      return;
    } else if (info->depth == 3) info->found = 1;
  } else return;

  //Branch to parse the elements of the XML file.
  if (!strcmp("mpu6050",el)) {
    //Check for the correct depth for this tag
    for(i = 0; attr[i]; i+=2) if ((strcmp("enable",attr[i]) == 0) && (strcmp("true",attr[i+1]) == 0)) {
      info->enable = 1; 
    }
    if (!info->enable) {
      printf("   MPU: Use of MPU6050 disabled in configuration\n"); 
      info->skip = info->depth;
    }
  } 
}

void XMLCALL
mpuEndTag(void *data, const char *el)
{
  parseInfo *info = (parseInfo *) data;
  info->depth--;

  if (info->depth < info->skip) info->skip = 0;
}
Tutorial on "Ship Roll Motion Control"


Plenary talk by T. Perez and M. Blanke at the IFAC CAMS'10 conference in 2010.
#include <ros/ros.h>
#include <spin_base/spin_base.h>

int main(int argc, char* argv[]) {
    ros::init(argc,argv,"battery_poll_node");
    ros::NodeHandle nh, nh_params("~");

    std::string can_port;
    nh.param("/can_port", can_port, std::string("vcan0"));

    std::cout << "Binding to " <<  can_port << std::endl;

    SpinDevices::SpinBase::TCAN_SPtr sckt = std::make_shared<can::ThreadedSocketCANInterface>(); 
    if(!sckt->init( can_port , 0, XmlRpcSettings::create(nh_params) )) {
        ROS_FATAL("Could not bind to port: %s", can_port.c_str());
        return 1;
    }
    else {
        ROS_INFO("Successfully connected to port: %s", can_port.c_str()); 
    }

    int i = 0;
    can::Frame poll_frame;
    poll_frame.is_extended = true;
    poll_frame.dlc = 8;
    poll_frame.data.fill(0);
    ros::Rate rate(1);
    while(nh.ok()) {
        poll_frame.id = 0x18900040 | (((i++ % 4)+1) << 8);
        sckt->send(poll_frame);
        rate.sleep();
        ros::spinOnce();
    }
    return 0;
}

# CHANGELOG

## [Under development]

## [Unreleased]

## [0.1.0] - 2022-08-12

- simple implementation

#include "std_msgs/Int16.h"
#include <torqeedo_driver_ros/torqeedo_driver_ros.hpp>

namespace RosDevices {

    TorqeedoDriver::TorqeedoDriver(ros::NodeHandle nh, SpinDevices::SpinBase::TCAN_SPtr sckt):
        _nh{nh}  {

        _nh.getParam("torq_devices",_devices_params);
        for(auto& dev: _devices_params) {
            uint8_t tmp_id = int(dev.second["board_id"]);
            ROS_INFO("Adding driver for torqeedo device \'%s-%.2X\'",dev.first.c_str(),tmp_id);

            m_drivers.emplace(
                tmp_id,
                std::make_shared<SpinTorqeedo>(sckt,tmp_id)
            );

            boost::function<void(const std_msgs::Int16ConstPtr& msg)> tmp_cb = [this,&dev] (const std_msgs::Int16ConstPtr& msg) {
                int16_t out = msg->data;
                if(out > 1000 || out < -1000) ROS_WARN("Input values will be cut by lower levels. Try and keep the input in the range: [-1000,1000]");
                if(out < 30 && out > -30) ROS_WARN("Input values which are too small might not be enough to trigger an action on the motor");
                send_vel(dev.first, msg->data/4); // Lower level takes -250/250
            }; 
            _drv_controls.push_back(/**/
                    _nh.subscribe(
                        dev.first,
                        100,
                        tmp_cb
                    )/**/
            );
        }
    }

    TorqeedoDriver::~TorqeedoDriver() { }

    void TorqeedoDriver::send_vel(const std::string& key, const int16_t vel) {
        at(key)->set_thrust(vel);
        printf("thrust = %d \n", vel );
    }

    TorqeedoDriver::SpinTorqState TorqeedoDriver::get_state(const std::string& key) const {
        return at(key)->get_state(); 
    }

    const TorqeedoDriver::SpinTorqeedo_SPtr TorqeedoDriver::at(const std::string& key) const {
        if(_devices_params.hasMember(key)) {
            uint8_t tmp_id = int(_devices_params[key]["board_id"]);
            return m_drivers.find(tmp_id)->second;
        } else {
            std::stringstream error; 
            error << "No object existing with name: " << key.c_str();
            throw std::runtime_error(error.str());
        }
    }
}

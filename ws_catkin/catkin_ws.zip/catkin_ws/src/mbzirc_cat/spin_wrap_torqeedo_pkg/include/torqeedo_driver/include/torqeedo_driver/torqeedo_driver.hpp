#pragma once

#include <spin_base/spin_base.h>
#include <shared_mutex>
#include <thread>
#include <condition_variable>

namespace SpinDevices {
    struct TorqState {
        uint8_t state_byte;
        bool check_motor_board;
        bool check_motor;
        uint16_t rpm;
        uint8_t torque;
        bool fresh_msg;
    };
    class TorqeedoDriver : public SpinBase::ISpinDevice_CAN_Threaded {
    public:
        using S_TCAN_SPtr = SpinBase::TCAN_SPtr;

        TorqeedoDriver(S_TCAN_SPtr, uint8_t);
        virtual ~TorqeedoDriver() override;

        uint8_t get_id() const;
        TorqState get_state() const;

        void set_thrust(int16_t);
    private:
        static const uint32_t m_dev_type;
        uint8_t m_id;
        virtual void task() override;

        mutable std::mutex m_state_mutex;
        
        void m_state_callback(const can::Frame&);
        can::FrameListenerConstSharedPtr m_state_listener;

        TorqState m_current_state;
    };
} // SpinDevices

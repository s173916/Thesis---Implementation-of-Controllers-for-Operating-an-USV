#include <chrono>
#include <thread>
#include <torqeedo_driver/torqeedo_driver.hpp>

namespace SpinDevices {
    
    const uint32_t TorqeedoDriver::m_dev_type = 0x0A;

    TorqeedoDriver::TorqeedoDriver(S_TCAN_SPtr sckt, uint8_t id):
        SpinBase::ISpinDevice_CAN_Threaded(sckt), m_id{id} {
        uint32_t min = m_dev_type << 8;
        uint32_t max = m_dev_type << 8 | 0xFF;
        m_state_listener = createMsgListener(this,&TorqeedoDriver::m_state_callback);
    }

    TorqeedoDriver::~TorqeedoDriver() { }

    void TorqeedoDriver::task() { 
        {
            std::lock_guard<std::mutex> lk {m_state_mutex};
            m_current_state.fresh_msg = false;
        }
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    void TorqeedoDriver::m_state_callback(const can::Frame& msg) {
        uint16_t id_mask = 0xFF00;
        uint16_t id_filter = m_dev_type << 8;
        if((msg.id & id_mask) == id_filter && msg.data[0] == m_id) {
            uint8_t in_range_mask = 0xFC;
            uint8_t out_range_mask = 0xFF;
            uint8_t common_filter = 0x7F; //0x7C for in_range & 0x7F for out_range
            std::unique_lock<std::mutex> lk{m_state_mutex}; 
            //msg.data[0] is hw_address
            m_current_state.fresh_msg = true;
            m_current_state.check_motor_board = msg.data[1] == 'V';
            m_current_state.state_byte = msg.data[2];
            m_current_state.rpm = *((uint16_t*)(&(msg.data) + 3));
            m_current_state.torque = msg.data[5];
            m_current_state.check_motor = (msg.data[7] & in_range_mask) == common_filter && (msg.data[7] & out_range_mask) != common_filter;
        }
    }

    uint8_t TorqeedoDriver::get_id() const {
        return m_id;
    }

    TorqState TorqeedoDriver::get_state() const {
        std::unique_lock<std::mutex> lk{m_state_mutex};
        return m_current_state;
    }

    void TorqeedoDriver::set_thrust(int16_t value) {
        m_can_frame.dlc = 3;
        m_can_frame.id = m_dev_type << 8 | 0x02;
        m_can_frame.is_extended = true;
        m_can_frame.data[0] = m_id;
        *((int16_t*)(m_can_frame.data.data() + 1)) = value;
        can_send();
    }

} // SpinDevices

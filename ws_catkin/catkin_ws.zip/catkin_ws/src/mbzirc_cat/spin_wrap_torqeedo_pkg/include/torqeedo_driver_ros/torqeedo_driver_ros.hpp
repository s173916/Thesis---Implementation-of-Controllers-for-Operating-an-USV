#pragma once

#include <ros/ros.h>
#include <std_msgs/Int16.h>
#include <xmlrpcpp/XmlRpc.h>

#include <map>
#include <sstream>
#include <exception>
#include <memory>

#include <torqeedo_driver/torqeedo_driver.hpp>

namespace RosDevices {
    class TorqeedoDriver {
    public:

        using SpinTorqeedo = SpinDevices::TorqeedoDriver;
        using SpinTorqeedo_SPtr = std::shared_ptr<SpinTorqeedo>;
        using SpinTorqState = SpinDevices::TorqState;

        TorqeedoDriver(ros::NodeHandle, SpinDevices::SpinBase::TCAN_SPtr);
        virtual ~TorqeedoDriver();

        void send_vel(const std::string&, const int16_t);
        SpinTorqState get_state(const std::string&) const; 

    private:
        
        ros::NodeHandle _nh;
        XmlRpc::XmlRpcValue _devices_params;
        std::vector<ros::Subscriber> _drv_controls;
        std::map<uint8_t,SpinTorqeedo_SPtr> m_drivers;
        const SpinTorqeedo_SPtr at(const std::string&) const;
    };
} // RosDevices 

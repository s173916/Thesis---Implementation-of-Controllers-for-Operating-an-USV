# CHANGELOG

## [Under development]

## [Unreleased]

## [0.3.1] - 2023-01-26

- Protocol error hotfix

## [0.3.0] - 2022-10-31

### Added

- service for setting each relay
- service for setting the default state of each relay
- ROS diagnostic for each relay
- ADC values are kept in polling

## [0.2.0] - 2022-07-05

- on git!

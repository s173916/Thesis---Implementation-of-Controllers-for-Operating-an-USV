#include <ros/ros.h>
#include <XmlRpc.h>
#include <iostream>

#include "relay_driver_ros/relay_driver_ros.hpp"
#include "socketcan_interface/interface.h"

int main(int argc, char* argv[]) {

    ros::init(argc,argv,"relay_driver_node");
    ros::NodeHandle nh, nh_params("~");
    diagnostic_updater::Updater updater;

    std::string can_port;
    nh.param("/can_port", can_port, std::string("vcan0"));

    std::cout << "Binding to " <<  can_port << std::endl;

    SpinDevices::SpinBase::TCAN_SPtr sckt = std::make_shared<can::ThreadedSocketCANInterface>(); 
    if(!sckt->init( can_port , 0, XmlRpcSettings::create(nh_params) )) {
        ROS_FATAL("Could not bind to port: %s", can_port.c_str());
        return 1;
    }
    else {
        ROS_INFO("Successfully connected to port: %s", can_port.c_str()); 
    }

    RosDevices::RelayDriver relay(nh_params,sckt,true);
    updater.setHardwareID("Relay Board");
    relay.init(updater);

    ros::Rate rate(10);
    while(nh.ok()) {
        if(relay.update()) updater.update(); 
        rate.sleep();
        ros::spinOnce();
    }
    return 0;
}

#include <relay_diagnostic/state_task.hpp>
#include <sstream>
#include <mutex>

namespace RosDevices {
    namespace RelayDiagnostic {
    
        StateTask::StateTask(std::string name):
            DiagnosticTask(name) {
        }

        StateTask::StateTask(std::map<uint8_t,std::pair<std::string,bool>>&& objs, std::string name):
            DiagnosticTask(name),
            _obj_dictionary{std::move(objs)} {
        }

        StateTask::StateTask(StateTask&& in) noexcept:
            DiagnosticTask(in.getName()) {
                _state = in._state;
                in._state = diagnostic_msgs::DiagnosticStatus::ERROR;
                _obj_dictionary = std::move(in._obj_dictionary);
                //move should clear previous map
        }

        StateTask& StateTask::operator=(StateTask&& in) noexcept {
            if(this != &in) {
                _state = in._state;
                in._state = diagnostic_msgs::DiagnosticStatus::ERROR;
                _obj_dictionary = std::move(in._obj_dictionary);
                //move should clear previous map
            } 
            return *this;
        }
    
        StateTask::~StateTask() { }
    
        void StateTask::run(diagnostic_updater::DiagnosticStatusWrapper& in) {
            std::lock_guard<std::mutex> lk{_state_mut};
            std::string out_msg;
            uint8_t out_lvl;
            uint8_t mask = 0x00;
            for(auto& obj: _obj_dictionary) {
                mask |= 0x01 << obj.first;
            }
            uint8_t untracked = (_state & (~mask)); 
            uint8_t tracked = _state & mask;
            bool error_cond = untracked != 0x00;
            if(error_cond) {
                out_lvl = diagnostic_msgs::DiagnosticStatus::WARN;
                out_msg = "Untracked relay on!";
                for(uint8_t i{0}; i < untracked && i < 8; ++i) { 
                    if(untracked >> i & 0x01)  {
                        std::stringstream tmp;
                        tmp << " Relay " << i+1;
                        in.add(tmp.str(),"ON UNKNOWN");
                    }
                }
            } else {
                out_lvl = diagnostic_msgs::DiagnosticStatus::OK; 
                out_msg = "No issue detected";
            }
            for(auto& obj: _obj_dictionary) {
                std::string tmp = bool(tracked >> obj.first & 0x01) == obj.second.second ? "ON" : "OFF";
                in.add(obj.second.first, tmp);
            }
            in.summary(out_lvl,out_msg);
        }
    
        void StateTask::set_state(uint8_t state) {
            std::lock_guard<std::mutex> lk{_state_mut};
            _state = state;
        }
    
    } // RelayDiagnostic
} // RosDevices

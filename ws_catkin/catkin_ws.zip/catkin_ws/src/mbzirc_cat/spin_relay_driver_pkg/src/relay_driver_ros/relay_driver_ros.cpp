#include <relay_driver_ros/relay_driver_ros.hpp>
#include <sstream>

namespace RosDevices {
    RelayDriver::RelayDriver(ros::NodeHandle& nh, SpinDevices::SpinBase::TCAN_SPtr sckt, bool stream):
        _nh{nh},
        m_analog_stream{stream} {
            // Instantiate services
            _set_relays_srv = _nh.advertiseService("set_relays", &RelayDriver::_set_relays, this);
            _set_analog_stream_srv = nh.advertiseService("set_analog_stream", &RelayDriver::_set_analog_stream,this);
            _set_default_state_srv = nh.advertiseService("set_default_state", &RelayDriver::_set_default_state, this);
   
            // Populate objects
            _nh.getParam("devices",_devices_params);
            /**
             * Populate boards only
             */
            for(auto& dev: _devices_params) {
                uint8_t tmp_id = int(dev.second["board_id"]); //Board id of the device
                if(m_relay_boards.find(tmp_id) == m_relay_boards.end()) {
                    /**
                     * Boards only
                     */
                    ROS_INFO("Adding new board with index: 0x%.2x",tmp_id);
                    m_relay_boards.emplace(
                            tmp_id,
                            std::make_shared<SpinRelay>(sckt,0x09,tmp_id)
                    ); 
                }  
            } 
            /**
             * Populate states only
             */
            for(auto& board: m_relay_boards) {
                std::map<uint8_t,std::pair<std::string,bool>> obj_dictionary; 
                uint8_t tmp_id = board.second->get_id();
                for(auto& dev: _devices_params) {
                    if(int(dev.second["board_id"]) == tmp_id) {
                        obj_dictionary.emplace(
                            int(dev.second["relay"])-1, //config takes number but we store index
                            std::pair<std::string,bool>(dev.first,bool(dev.second["normally_open"]))
                        );
                    }
                }
                std::stringstream state_name;
                state_name << "relay_board_"<< (int)tmp_id;
                m_relay_states.emplace(
                        tmp_id,
                        SpinRelayState(std::move(obj_dictionary),state_name.str())
                );
            }
    
            // Initialize the boards
            for(auto& it: m_relay_boards) {
                if(m_analog_stream) it.second->run();
            }
    }
    
    RelayDriver::~RelayDriver() {
        for(auto& it: m_relay_boards) {
            it.second->stop();
        }
    }
    
    void RelayDriver::init(diagnostic_updater::Updater& updater) {
        for(auto& state: m_relay_states) {
            updater.add(state.second); 
        }
    }

    bool RelayDriver::update() {
        if(m_analog_stream) {
            for(auto& drv: m_relay_boards) {
                uint8_t tmp_id = drv.second->get_id();
                uint8_t tmp_state = drv.second->get_state();
                m_relay_states[tmp_id].set_state(tmp_state); 
            } 
        }
        return m_analog_stream; 
    }
     
    bool RelayDriver::compute_action(const std::string& device, bool state) {
        bool tmp_no = _devices_params[device]["normally_open"];
        return !(tmp_no ^ state);
    }
    
    bool RelayDriver::_set_relays(spin_relay_driver::set_relays::Request& req, spin_relay_driver::set_relays::Response& res) {
    
        res.success = true;
        res.message = "WARNING: Still need to provide a feedback";
        
        for(int i{0}; i < req.device.size(); ++i) {
            //Check if device exist in dictionary
            if(_devices_params.hasMember(req.device[i])) {
    
                std::string tmp_device = req.device[i];
                bool tmp_requested_state = req.state[i];
                uint8_t tmp_relay = int(_devices_params[tmp_device]["relay"])-1;
    
                ROS_INFO("Request for %s, on relay %d, to go %s", 
                        std::string(_devices_params[req.device[i]]["name"]).c_str(),
                        tmp_relay+1,
                        (tmp_requested_state?"ON":"OFF")
                );
    
                bool action = compute_action(tmp_device,tmp_requested_state);
                int tmp_board = int(_devices_params[tmp_device]["board_id"]);
                m_relay_boards[tmp_board]->set_relay(tmp_relay, action, (uint16_t)(req.duration[i])); 
    
            } else {
                ROS_ERROR("No device named: %s",req.device[i].c_str());
                res.success = false;
                res.message = "ERROR: No device named: " + req.device[i];
            }
        } 
        return true;
    }
    
    bool RelayDriver::_set_analog_stream(spin_relay_driver::set_analog_stream::Request& req, spin_relay_driver::set_analog_stream::Response& res) {
    
        res.success = true;
        res.message = "WARNING: Still need to provide a feedback";
    
        if(req.stream_state && !m_analog_stream) {
            ROS_INFO("Turning analog stream: ON");
            for(auto& it: m_relay_boards) {
                it.second->run(); 
            }
        } else if(!req.stream_state && m_analog_stream) {
            ROS_INFO("Turning analog stream: OFF");
            for(auto& it: m_relay_boards) {
                it.second->stop();
            }
        } else {
            res.message = "Analog stream already " + std::string(m_analog_stream ? "ON" : "OFF");
            res.success = false;
        }
    
        m_analog_stream = req.stream_state;
        return true;
    
    }
    
    bool RelayDriver::_set_default_state(spin_relay_driver::set_default_state::Request& req, spin_relay_driver::set_default_state::Response& res) {
    
        res.success = true;
        res.message = "WARNING: Still need to provide a feedback";
    
        std::map<int,uint8_t> out_state;
        std::vector<std::string> wrong_devices;
    
        // Compute output map
        for(int i{0}; i < req.device.size(); ++i) {
    
            if(_devices_params.hasMember(req.device[i])) {
                std::string tmp_device = req.device[i];
                int tmp_board = _devices_params[tmp_device]["board_id"];
                
                if(out_state.find(tmp_board) == out_state.end()) {// Object not found, it's a new one
                    out_state.emplace(tmp_board,0x00); 
                } 
                //Already existing object
                bool tmp_action = compute_action(tmp_device,req.state[i]);
                int tmp_relay = int(_devices_params[tmp_device]["relay"])-1;
                out_state[tmp_board] |= tmp_action << tmp_relay;
                ROS_INFO("Default state for '%s' set to: %s", tmp_device.c_str(), req.state[i]?"ON":"OFF");
    
            } else {
                ROS_ERROR("No device named: %s",req.device[i].c_str());
                wrong_devices.push_back(req.device[i]); 
                res.success = false;
            } 
    
        }
    
        // Handle of errors
        if(!res.success) {
            std::stringstream tmp_stream;
            tmp_stream << "Wrong devices: { ";
            for(auto dev : wrong_devices) {
                tmp_stream << dev;
                if(wrong_devices.back() != dev) {
                    tmp_stream << ",";
                } else tmp_stream << " }";
            }
            res.message = std::move(tmp_stream.str());
        }
    
        //send output
        for(auto it: out_state) {
            //std::cout << it.first << ": " << it.second << std::endl;
            m_relay_boards[it.first]->set_default_state(it.second);
        }
        return true;
    }
} // RosDevices

#pragma once

#include <ros/ros.h>
#include <diagnostic_updater/diagnostic_updater.h>
#include <mutex>

#include <map>

namespace RosDevices {
    namespace RelayDiagnostic {
        class StateTask : public diagnostic_updater::DiagnosticTask {
        public:
            StateTask(std::string ="relay_state");
            StateTask(std::map<uint8_t,std::pair<std::string,bool>>&&,std::string="relay_state");
            StateTask(StateTask&&) noexcept;
            StateTask(const StateTask&) = delete;
            StateTask& operator=(StateTask&&) noexcept;
            StateTask& operator=(const StateTask&) = delete;
            virtual ~StateTask();
            virtual void run(diagnostic_updater::DiagnosticStatusWrapper&) override;
            void set_state(uint8_t);
        private:
            uint8_t _state;
            std::mutex _state_mut;
            std::map<uint8_t,std::pair<std::string,bool>> _obj_dictionary;
        };
    } // RelayDiagnostic
} // RosDevices

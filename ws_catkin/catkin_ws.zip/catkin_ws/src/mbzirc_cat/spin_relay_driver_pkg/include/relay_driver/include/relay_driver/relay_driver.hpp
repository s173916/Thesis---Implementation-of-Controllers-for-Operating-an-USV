#pragma once

#include <spin_base/spin_base.h>
#include <thread>
#include <chrono>
#include <vector>
#include <shared_mutex>

namespace SpinDevices {
    struct AnalogReading {
        uint8_t channel_offset; //channels are read 3 by 3.
        std::array<uint16_t,3> data;
    };
    
    class RelayDriver : public SpinBase::ISpinDevice_CAN_Threaded {
    private:
        uint8_t m_dev_type;
        uint8_t m_id;
        virtual void task() override;

        virtual void m_frame_state_CB(const can::Frame&);
        virtual void m_frame_analog_CB(const can::Frame&);
        std::vector<can::FrameListenerConstSharedPtr> m_frame_listeners;
    
        mutable boost::shared_mutex m_analog_mutex;
        mutable boost::shared_mutex m_state_mutex;
        mutable boost::shared_mutex m_id_mutex;
    
        AnalogReading m_analog;
        uint8_t m_state;
    public:
        RelayDriver(SpinBase::TCAN_SPtr sckt, uint8_t dev_type, uint8_t id);
        virtual ~RelayDriver() override;

        AnalogReading get_analog() const;
        uint8_t get_state() const;
        uint8_t get_id() const;

        void set_relay(uint8_t,bool,uint16_t);
        void set_glob_state(uint8_t);
        void set_default_state(uint8_t);
        void set_id(uint8_t);
    };
} // SpinDevices

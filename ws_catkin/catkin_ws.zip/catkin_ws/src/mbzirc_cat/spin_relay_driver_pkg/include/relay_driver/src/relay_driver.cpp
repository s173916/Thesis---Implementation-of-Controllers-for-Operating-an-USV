#include <relay_driver/relay_driver.hpp> 

namespace SpinDevices {
    RelayDriver::RelayDriver(SpinBase::TCAN_SPtr sckt, uint8_t dev_type, uint8_t id):
        SpinBase::ISpinDevice_CAN_Threaded(sckt), m_dev_type{dev_type} {
        set_id(id); 
        can::MsgHeader hd1, hd2;
        hd1.id = 0x905;
        hd1.is_extended = true;
        hd2.id = 0x911;
        hd2.is_extended = true;
        m_frame_listeners.push_back( createMsgListener(hd1,this,&RelayDriver::m_frame_state_CB) );
        m_frame_listeners.push_back( createMsgListener(hd2,this,&RelayDriver::m_frame_analog_CB) );
    }
    
    RelayDriver::~RelayDriver() {}
    
    uint8_t RelayDriver::get_state() const {
        boost::shared_lock<boost::shared_mutex> lk{m_state_mutex};
        return m_state;
    }
    
    AnalogReading RelayDriver::get_analog() const {
        boost::shared_lock<boost::shared_mutex> lk{m_analog_mutex};
        return m_analog;
    }

    uint8_t RelayDriver::get_id() const {
        boost::shared_lock<boost::shared_mutex> lk{m_id_mutex}; 
        return m_id;
    }

    void RelayDriver::set_relay(uint8_t index, bool state, uint16_t time=0) {
        m_can_frame.id = (uint16_t)(m_dev_type << 8) | 0x06;
        m_can_frame.is_extended = true;
        m_can_frame.dlc = 5;
        m_can_frame.data[0] = get_id();
        m_can_frame.data[1] = index;
        m_can_frame.data[2] = state;
        *((uint16_t*)(m_can_frame.data.data() + 3)) = time;
        can_send();
    }

    void RelayDriver::set_glob_state(uint8_t state) {
        m_can_frame.id = (uint16_t)(m_dev_type << 8) | 0x02;
        m_can_frame.is_extended = true;
        m_can_frame.dlc = 2;
        m_can_frame.data[0] = get_id();
        m_can_frame.data[1] = state;
        can_send();
    }

    void RelayDriver::set_default_state(uint8_t state) {
        m_can_frame.id = (uint16_t)(m_dev_type << 8) | 0x0C;
        m_can_frame.is_extended = true;
        m_can_frame.dlc = 2;
        m_can_frame.data[0] = get_id();
        m_can_frame.data[1] = state;
        can_send();
    }
    void RelayDriver::set_id(uint8_t new_id) {
        boost::unique_lock<boost::shared_mutex> lk{m_id_mutex};
        m_id = new_id; 
    }
    
    void RelayDriver::task() {
        m_can_frame.id = (uint16_t)(m_dev_type << 8) | 0x10;
        m_can_frame.is_extended = true;
        m_can_frame.dlc = 2;
        m_can_frame.data[0] = get_id();
        m_can_frame.data[1] = 0x00;
        can_send();  
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
        m_can_frame.id = (uint16_t)(m_dev_type << 8) | 0x04;
        m_can_frame.is_extended = true;
        m_can_frame.dlc = 1;
        m_can_frame.data[0] = get_id();
        can_send();  
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    
    void RelayDriver::m_frame_state_CB(const can::Frame& msg) {
        /*
        auto mask = [](int n){return 0x01<<n;};
        std::cout << "\nState:" << std::endl;
        for(int i{0}; i<7;++i) {
            std::cout << "K" << i << ": "<< ((msg.data[1]&mask(i))>>i) << std::endl;
        }
        */
        boost::unique_lock<boost::shared_mutex> lk{m_state_mutex};
        m_state = msg.data[1];
    }
    
    void RelayDriver::m_frame_analog_CB(const can::Frame& msg) {
        /*
        std::cout << "\nAnalog reads in group [" << (int)msg.data[1] << ","<< (int)msg.data[1]+2<<"] are:" << std::endl; 
        for(int i{0}; i<3;++i) {
            std::cout << "AN"<<i<<" "<<*((uint16_t*)(msg.data.data() + 2)+i) << std::endl; 
        }
        */
        boost::unique_lock<boost::shared_mutex> lk{m_analog_mutex};
        m_analog.channel_offset = msg.data[1];
        m_analog.data[0] = *((uint16_t*)(msg.data.data() + 2));
        m_analog.data[1] = *((uint16_t*)(msg.data.data() + 2) + 1);
        m_analog.data[2] = *((uint16_t*)(msg.data.data() + 2) + 2);
    }
} // SpinDevices

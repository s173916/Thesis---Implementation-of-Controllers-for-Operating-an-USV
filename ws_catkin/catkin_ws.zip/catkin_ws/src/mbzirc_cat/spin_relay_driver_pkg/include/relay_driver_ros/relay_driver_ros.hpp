#pragma once

#include <memory>
#include <ros/ros.h>

#include <relay_driver/relay_driver.hpp>
#include <relay_diagnostic/state_task.hpp>
#include <diagnostic_updater/diagnostic_updater.h>

#include <spin_relay_driver/set_relays.h>
#include <spin_relay_driver/set_analog_stream.h>
#include <spin_relay_driver/set_default_state.h>

#include <xmlrpcpp/XmlRpc.h>
#include <chrono>
#include <thread>
#include <tuple>
#include <sstream>

namespace RosDevices {
    class RelayDriver {
    public:
        RelayDriver(ros::NodeHandle& nh, SpinDevices::SpinBase::TCAN_SPtr sck, bool stream = 0);
        virtual ~RelayDriver();
        void init(diagnostic_updater::Updater&);
        bool update();
    
        using SpinRelayState = RelayDiagnostic::StateTask;
        using SpinRelay = SpinDevices::RelayDriver;
        using SpinRelay_SPtr = std::shared_ptr<SpinRelay>;
    
    private:
        ros::NodeHandle _nh;
    
        ros::ServiceServer _set_relays_srv;
        ros::ServiceServer _set_analog_stream_srv;
        ros::ServiceServer _set_default_state_srv;
        bool _set_relays(spin_relay_driver::set_relays::Request& req, spin_relay_driver::set_relays::Response& res);
        bool _set_analog_stream(spin_relay_driver::set_analog_stream::Request& req, spin_relay_driver::set_analog_stream::Response& res);
        bool _set_default_state(spin_relay_driver::set_default_state::Request& req, spin_relay_driver::set_default_state::Response& res);

        std::vector<RelayDiagnostic::StateTask> _state_tasks;
    
        XmlRpc::XmlRpcValue _devices_params;
        std::map<uint8_t,SpinRelay_SPtr> m_relay_boards;
        std::map<uint8_t,SpinRelayState> m_relay_states;
    
        //Utilities
        bool compute_action(const std::string&, bool);
        std::atomic_bool m_analog_stream;
    };
} // RosDevices

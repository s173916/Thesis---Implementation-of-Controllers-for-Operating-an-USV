#include "ros/subscriber.h"
#include "socketcan_interface/interface.h"
#include "spin_base/ISpinDevice.hpp"
#include <functional>
#include <iostream>
#include <ros/ros.h>
#include <std_msgs/Float32.h>
#include <spin_base/spin_base.h>

void left_listener(SpinDevices::SpinBase::TCAN_SPtr sckt, const std_msgs::Float32ConstPtr& value) {
    int32_t out_value = (int32_t)( value->data * 500 );
    can::Frame out_frame;
    out_frame.is_extended = false;
    out_frame.id = 0x0603;
    out_frame.dlc = 8;
    *((int32_t*)out_frame.data.data()) = 0x01240023;
    *((int32_t*)(out_frame.data.data()) + 1) = out_value;
    sckt->send(out_frame);
    ROS_INFO("left_call: %d", out_value);
    if(out_value >= 45000 || out_value <= -45000) ROS_WARN("Control values should be kept between [-90,90]");
}

void right_listener(SpinDevices::SpinBase::TCAN_SPtr sckt, const std_msgs::Float32ConstPtr& value) {
    int32_t out_value = (int32_t)( value->data * 500 );
    can::Frame out_frame;
    out_frame.is_extended = false;
    out_frame.id = 0x0604;
    out_frame.dlc = 8;
    *((int32_t*)out_frame.data.data()) = 0x01240023;
    *((int32_t*)(out_frame.data.data()) + 1) = out_value;
    sckt->send(out_frame);
    ROS_INFO("right_call: %d", out_value);
    if(out_value >= 45000 || out_value <= -45000) ROS_WARN("Control values should be kept between [-90,90]");
}

int main(int argc, char* argv[]) {
    ros::init(argc,argv,"steer_node");
    ros::NodeHandle nh, nh_params("~");

    std::string can_port;
    nh.param("/can_port", can_port, std::string("vcan0"));

    std::cout << "Binding to " <<  can_port << std::endl;

    SpinDevices::SpinBase::TCAN_SPtr sckt = std::make_shared<can::ThreadedSocketCANInterface>(); 
    if(!sckt->init( can_port , 0, XmlRpcSettings::create(nh_params) )) {
        ROS_FATAL("Could not bind to port: %s", can_port.c_str());
        return 1;
    }
    else {
        ROS_INFO("Successfully connected to port: %s", can_port.c_str()); 
    }

    boost::function<void(const std_msgs::Float32ConstPtr&)> right_tmp = [&sckt](const std_msgs::Float32ConstPtr& in_val){right_listener(sckt,in_val);};
    ros::Subscriber right_sub = nh_params.subscribe("right_steer",100, right_tmp);
    boost::function<void(const std_msgs::Float32ConstPtr&)> left_tmp = [&sckt](const std_msgs::Float32ConstPtr& in_val){left_listener(sckt,in_val);};
    ros::Subscriber left_sub = nh_params.subscribe("left_steer",100, left_tmp);

    ros::Rate rate(10);
    while(nh.ok()) {
        rate.sleep();
        ros::spinOnce();
    }
    return 0;
}

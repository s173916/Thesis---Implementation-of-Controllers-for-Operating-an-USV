# README

## Prerequisites

If you don't have your own way to set up and use a can port [here](https://bitbucket.org/spinitalia/workspace/snippets/EdKag4/can-port-initialization) you can find some useful references.

## Cloning and running the actuation nodes

Run these commands in your ROS workspace, after setting up a can port:

```bash
cd src
git clone git@bitbucket.org:spinitalia/mbzirc_cat.git
cd mbzirc_cat
git submodule update --init --recursive
cd ../.. && catkin build
source devel/setup.sh
roslaunch mbzirc_cat_bringup mbzirc_cat.launch can_port:=your_preferred_can_port
```
